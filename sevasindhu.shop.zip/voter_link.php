<?php
$response_data = null;
$error_msg = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Configuration
    $apidomain = "https://www.apicentre.in";
    $api_key = "b848a41feea7e111141f76500ada5ff756d2d882a3de1348747a8803398c"; // Replace with your actual API key
    
    // Get and sanitize inputs
    $epic = trim($_POST['epic'] ?? '');
    $mobile = trim($_POST['mobile'] ?? '');

    if (!empty($epic) && !empty($mobile)) {
        // Build URL with parameters
        $url = "$apidomain/api/voter_link_instent?api_key=" . urlencode($api_key) . "&epic=" . urlencode($epic) . "&mobile=" . urlencode($mobile);

        $curl = curl_init();
        curl_setopt_array($curl, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CUSTOMREQUEST => "GET",
        ]);

        $response = curl_exec($curl);
        $curl_error = curl_error($curl);
        curl_close($curl);

        if ($curl_error) {
            $error_msg = "cURL Error: " . $curl_error;
        } else {
            $response_data = json_decode($response, true);
        }
    } else {
        $error_msg = "Please provide both Voter ID (EPIC) and Mobile Number.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voter Mobile Link Service</title>
    <!-- Bootstrap 5 CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h4 class="mb-0">Voter Mobile Link Service</h4>
                    </div>
                    <div class="card-body">
                        
                        <!-- Error Message -->
                        <?php if (!empty($error_msg)): ?>
                            <div class="alert alert-danger" role="alert">
                                <?php echo htmlspecialchars($error_msg); ?>
                            </div>
                        <?php endif; ?>

                        <!-- API Response Display -->
                        <?php if (!empty($response_data)): ?>
                            <?php if (isset($response_data['status']) && $response_data['status'] == "200"): ?>
                                <div class="alert alert-success" role="alert">
                                    <h5 class="alert-heading">Request Successful!</h5>
                                    <p><?php echo htmlspecialchars($response_data['message']); ?></p>
                                    <hr>
                                    <ul class="list-unstyled mb-0">
                                        <li><strong>EPIC:</strong> <?php echo htmlspecialchars($response_data['epic']); ?></li>
                                        <li><strong>Mobile:</strong> <?php echo htmlspecialchars($response_data['mobile']); ?></li>
                                        <li><strong>Ref ID:</strong> <?php echo htmlspecialchars($response_data['ref_id']); ?></li>
                                        <li><strong>Application No:</strong> <?php echo htmlspecialchars($response_data['application_no']); ?></li>
                                        <li><strong>Balance Left:</strong> ₹<?php echo htmlspecialchars($response_data['balance_left']); ?></li>
                                    </ul>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning" role="alert">
                                    <h5 class="alert-heading">Request Failed</h5>
                                    <p><?php echo htmlspecialchars($response_data['message'] ?? 'Unknown error occurred.'); ?></p>
                                </div>
                            <?php endif; ?>
                        <?php endif; ?>

                        <!-- Form -->
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="epic" class="form-label">Voter ID (EPIC Number)</label>
                                <input type="text" class="form-control" id="epic" name="epic" placeholder="e.g. TMM0007133" required value="<?php echo htmlspecialchars($_POST['epic'] ?? ''); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="mobile" class="form-label">Mobile Number</label>
                                <input type="text" class="form-control" id="mobile" name="mobile" placeholder="e.g. 7250000919" pattern="[0-9]{10}" maxlength="10" required value="<?php echo htmlspecialchars($_POST['mobile'] ?? ''); ?>">
                                <div class="form-text">Enter a valid 10-digit mobile number.</div>
                            </div>
                            <button type="submit" class="getReference btn btn-primary w-100">Submit Linking Request</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

</body>
</html>