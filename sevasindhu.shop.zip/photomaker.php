<?php
/**
 * ID Photo Print Studio - Standalone PHP Application
 * 
 * Combines frontend interactive canvas manipulation, live panning, cutting marks,
 * and solid white backing export into a single self-contained file.
 */

$uploadError = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['photo_file'])) {
    $file = $_FILES['photo_file'];
    $allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    
    if ($file['error'] === UPLOAD_ERR_OK) {
        if (!in_array($file['type'], $allowedTypes)) {
            $uploadError = 'Invalid file format. Please upload a JPG, PNG, or WebP image.';
        }
    } else {
        $uploadError = 'File upload failed. Please try again.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ID Photo Print Studio - Passport & Stamp Sheet Generator</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/@imgly/background-removal@1.5.7/dist/index.umd.js"></script>
    <style>
        .preview-box {
            cursor: grab;
        }
        .preview-box:active {
            cursor: grabbing;
        }
        @keyframes pulse-fast {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.4; }
        }
        .animate-pulse-fast {
            animation: pulse-fast 1.2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
    </style>
</head>
<body class="bg-slate-100 font-sans text-slate-800 min-h-screen flex flex-col items-center justify-between">

    <header class="w-full bg-blue-600 text-white py-6 shadow-md text-center">
        <h1 class="text-3xl font-bold">ID Photo Print Studio</h1>
        <p class="text-blue-100 mt-1">Automatic Background Removal, Pan Alignment & White-Backing Sheet Exporter</p>
    </header>

    <main class="w-full max-w-6xl p-4 md:p-6 my-auto">

        <?php if (!empty($uploadError)): ?>
            <div class="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm text-center">
                <?php echo htmlspecialchars($uploadError); ?>
            </div>
        <?php endif; ?>
        
        <!-- Step 1: Upload View -->
        <div id="upload-view" class="bg-white rounded-xl shadow-md p-8 max-w-xl mx-auto text-center">
            <h2 class="text-2xl font-bold mb-2 text-slate-800">Upload Source Photo</h2>
            <p class="text-slate-500 text-sm mb-6">Select a portrait or document photo. AI background removal will isolate the subject, ready for landscape 6x4 and portrait 4x6 print arrangements.</p>
            
            <label class="flex flex-col items-center justify-center border-2 border-dashed border-slate-300 rounded-xl p-8 cursor-pointer hover:border-blue-500 bg-slate-50 transition">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-slate-400 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                </svg>
                <span class="text-slate-700 font-medium">Click to select photo</span>
                <span class="text-slate-400 text-xs mt-1">Supports JPG, PNG, WebP</span>
                <input type="file" id="photo-input" accept="image/*" class="hidden" onchange="handleImageUpload(event)">
            </label>
        </div>

        <!-- Step 2: Processing View -->
        <div id="loading-view" class="hidden bg-white rounded-xl shadow-md p-10 max-w-xl mx-auto text-center flex flex-col items-center">
            <div class="relative w-16 h-16 mb-4">
                <div class="absolute inset-0 rounded-full border-4 border-blue-200 animate-pulse"></div>
                <div class="absolute inset-0 rounded-full border-4 border-blue-600 border-t-transparent animate-spin"></div>
            </div>
            
            <h3 id="loading-title" class="text-xl font-bold text-slate-800">Processing Photo</h3>
            <p id="loading-status" class="text-sm text-slate-500 mt-2">Initializing AI segmentation model...</p>
            
            <div class="w-full bg-slate-100 rounded-full h-2.5 mt-6 overflow-hidden">
                <div id="progress-bar" class="bg-blue-600 h-2.5 rounded-full transition-all duration-300" style="width: 20%"></div>
            </div>

            <div id="fallback-banner" class="hidden mt-6 bg-amber-50 border border-amber-200 text-amber-800 px-4 py-3 rounded-lg text-xs flex items-start gap-2 text-left">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 text-amber-600 shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <div>
                    <span class="font-bold block">Notice:</span>
                    <span>AI model initialization was bypassed due to environment constraints. Proceeding with original background image.</span>
                </div>
            </div>

            <button id="proceed-btn" onclick="confirmProceed()" class="hidden mt-6 bg-blue-600 hover:bg-blue-700 text-white font-medium px-6 py-2.5 rounded-lg text-sm shadow transition">
                Continue with Original Photo
            </button>
        </div>

        <!-- Step 3: Studio Workspace -->
        <div id="workspace-view" class="hidden">
            <div class="flex flex-col md:flex-row items-center justify-between mb-6 gap-4">
                <div>
                    <h2 class="text-2xl font-bold text-slate-800">Print Layout Studio</h2>
                    <p class="text-sm text-slate-500">Drag inside the preview box to pan and re-center. Choose background solid tones below.</p>
                </div>
                <button onclick="resetUpload()" class="bg-slate-200 hover:bg-slate-300 text-slate-700 px-4 py-2 rounded-lg text-sm font-medium transition">
                    &larr; Upload Another Photo
                </button>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                <!-- Framing & Controls Column -->
                <div class="bg-white rounded-xl shadow-md p-5 flex flex-col items-center justify-center lg:col-span-1 border-2 border-blue-200">
                    <h3 class="text-lg font-bold text-slate-800 mb-1">Live Alignment Box</h3>
                    <p class="text-xs text-slate-500 mb-3 text-center">Click and drag inside the box to reposition:</p>
                    
                    <div id="interactive-preview-container" class="preview-box relative w-64 h-80 border-4 border-dashed border-blue-400 rounded-lg overflow-hidden bg-slate-900 shadow-inner flex items-center justify-center select-none">
                        <canvas id="interactive-canvas" class="block w-full h-full cursor-grab"></canvas>
                        <div class="absolute inset-0 pointer-events-none border border-white/40 flex items-center justify-center">
                            <span class="bg-black/60 text-white text-[10px] px-2 py-1 rounded absolute bottom-2">Live Pan Canvas</span>
                        </div>
                    </div>

                    <div class="mt-4 w-full bg-slate-50 p-3 rounded-lg border border-slate-200">
                        <span class="block text-xs font-bold text-slate-700 mb-2 text-center">Background Color</span>
                        <div class="flex items-center justify-center gap-3">
                            <button onclick="changeBgColor('#ffffff')" class="w-7 h-7 rounded-full bg-white border-2 border-slate-400 shadow-sm focus:outline-none hover:scale-110 transition" title="White"></button>
                            <button onclick="changeBgColor('#0055a5')" class="w-7 h-7 rounded-full bg-blue-600 border-2 border-slate-300 shadow-sm focus:outline-none hover:scale-110 transition" title="Royal Blue"></button>
                            <button onclick="changeBgColor('#e5e7eb')" class="w-7 h-7 rounded-full bg-gray-300 border-2 border-slate-300 shadow-sm focus:outline-none hover:scale-110 transition" title="Off-White / Light Grey"></button>
                            <button onclick="changeBgColor('#dc2626')" class="w-7 h-7 rounded-full bg-red-600 border-2 border-slate-300 shadow-sm focus:outline-none hover:scale-110 transition" title="Red"></button>
                        </div>
                    </div>

                    <button onclick="resetOffsets()" class="mt-3 text-xs text-blue-600 hover:underline font-medium">Reset Pan Centering</button>
                </div>

                <!-- Print Output Preview Sheets -->
                <div class="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    <!-- 6x4 Landscape Sheet (Passport 8-Up) -->
                    <div class="bg-white rounded-xl shadow-md p-4 flex flex-col items-center">
                        <h3 class="text-base font-bold text-slate-800 mb-2">Passport Sheet (Landscape 6x4)</h3>
                        <div class="border-2 border-slate-200 rounded-lg overflow-hidden bg-slate-50 mb-3 w-full flex justify-center">
                            <canvas id="passport-canvas" class="max-w-full h-auto block"></canvas>
                        </div>
                        <button onclick="downloadSheet('passport')" class="w-full bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium py-2 rounded-lg shadow transition flex items-center justify-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                            </svg>
                            Download Passport Sheet (6x4)
                        </button>
                    </div>

                    <!-- 4x6 Portrait Sheet (Stamp 12-Up) -->
                    <div class="bg-white rounded-xl shadow-md p-4 flex flex-col items-center">
                        <h3 class="text-base font-bold text-slate-800 mb-2">Stamp Sheet (Portrait 4x6)</h3>
                        <div class="border-2 border-slate-200 rounded-lg overflow-hidden bg-slate-50 mb-3 w-full flex justify-center">
                            <canvas id="stamp-canvas" class="max-w-full h-auto block"></canvas>
                        </div>
                        <button onclick="downloadSheet('stamp')" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium py-2 rounded-lg shadow transition flex items-center justify-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                            </svg>
                            Download Stamp Sheet (4x6)
                        </button>
                    </div>

                </div>

            </div>
        </div>

    </main>

    <footer class="w-full text-center py-4 text-xs text-slate-500">
        &copy; <?php echo date('Y'); ?> ID Photo Print Studio. All rights reserved.
    </footer>

    <script>
        let uploadedImage = null;
        let currentBgColor = '#ffffff'; 
        let offsetX = 0;
        let offsetY = 0;
        let isDragging = false;
        let startX = 0;
        let startY = 0;

        let imgDisplayWidth = 0;
        let imgDisplayHeight = 0;
        let rawFileCache = null;

        async function handleImageUpload(event) {
            const file = event.target.files[0];
            if (!file) return;
            rawFileCache = file;

            document.getElementById('upload-view').classList.add('hidden');
            document.getElementById('loading-view').classList.remove('hidden');
            document.getElementById('fallback-banner').classList.add('hidden');
            document.getElementById('proceed-btn').classList.add('hidden');
            
            const progressBar = document.getElementById('progress-bar');
            const statusText = document.getElementById('loading-status');
            
            progressBar.style.width = '35%';
            statusText.innerText = 'Extracting subject from background...';

            try {
                setTimeout(() => { progressBar.style.width = '70%'; }, 500);
                
                const blob = await imgRemoval.removeBackground(file);
                progressBar.style.width = '100%';
                statusText.innerText = 'Subject isolated successfully!';

                const url = URL.createObjectURL(blob);
                const img = new Image();
                img.onload = function() {
                    finalizeImageLoad(img);
                };
                img.src = url;

            } catch (err) {
                console.warn('AI background removal error/timeout:', err);
                
                progressBar.style.width = '100%';
                progressBar.classList.remove('bg-blue-600');
                progressBar.classList.add('bg-amber-500');
                
                document.getElementById('loading-title').innerText = 'Proceed with Original';
                statusText.innerText = 'Background isolation model could not be loaded. You can still align and generate sheets directly.';
                document.getElementById('fallback-banner').classList.remove('hidden');
                document.getElementById('proceed-btn').classList.remove('hidden');
            }
        }

        async function confirmProceed() {
            if (!rawFileCache) return;
            
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = new Image();
                img.onload = function() {
                    finalizeImageLoad(img);
                }
                img.src = e.target.result;
            }
            reader.readAsDataURL(rawFileCache);
        }

        function finalizeImageLoad(img) {
            uploadedImage = img;
            offsetX = 0;
            offsetY = 0;
            currentBgColor = '#ffffff'; 

            document.getElementById('loading-view').classList.add('hidden');
            document.getElementById('workspace-view').classList.remove('hidden');

            initInteractiveCanvas();
            redrawAll();
        }

        function changeBgColor(colorHex) {
            currentBgColor = colorHex;
            redrawAll();
        }

        function initInteractiveCanvas() {
            const container = document.getElementById('interactive-preview-container');
            const canvas = document.getElementById('interactive-canvas');
            
            canvas.width = container.clientWidth * 2; 
            canvas.height = container.clientHeight * 2;

            const handleMouseDown = (e) => {
                isDragging = true;
                const pointX = e.clientX !== undefined ? e.clientX : (e.touches && e.touches[0] ? e.touches[0].clientX : 0);
                const pointY = e.clientY !== undefined ? e.clientY : (e.touches && e.touches[0] ? e.touches[0].clientY : 0);
                startX = pointX - offsetX;
                startY = pointY - offsetY;
            };

            const handleMouseMove = (e) => {
                if (!isDragging) return;
                const clientX = e.clientX !== undefined ? e.clientX : (e.touches && e.touches[0] ? e.touches[0].clientX : 0);
                const clientY = e.clientY !== undefined ? e.clientY : (e.touches && e.touches[0] ? e.touches[0].clientY : 0);
                
                offsetX = clientX - startX;
                offsetY = clientY - startY;

                redrawAll();
            };

            const handleMouseUp = () => {
                isDragging = false;
            };

            canvas.onmousedown = handleMouseDown;
            window.onmousemove = handleMouseMove;
            window.onmouseup = handleMouseUp;

            canvas.ontouchstart = handleMouseDown;
            window.ontouchmove = handleMouseMove;
            window.ontouchend = handleMouseUp;
        }

        function resetOffsets() {
            offsetX = 0;
            offsetY = 0;
            redrawAll();
        }

        function redrawAll() {
            if (!uploadedImage) return;
            drawInteractivePreview();
            drawPrintSheets();
        }

        function drawInteractivePreview() {
            const canvas = document.getElementById('interactive-canvas');
            const ctx = canvas.getContext('2d');
            const w = canvas.width;
            const h = canvas.height;

            ctx.fillStyle = currentBgColor;
            ctx.fillRect(0, 0, w, h);

            const targetAspect = 3.5 / 4.5;
            const canvasAspect = w / h;

            if (canvasAspect > targetAspect) {
                imgDisplayHeight = h;
                imgDisplayWidth = h * targetAspect;
            } else {
                imgDisplayWidth = w;
                imgDisplayHeight = w / targetAspect;
            }

            const drawX = (w - imgDisplayWidth) / 2 + offsetX * 2;
            const drawY = (h - imgDisplayHeight) / 2 + offsetY * 2;

            ctx.drawImage(uploadedImage, drawX, drawY, imgDisplayWidth, imgDisplayHeight);
        }

        function drawPrintSheets() {
            // Passport Sheet (Landscape 6x4 at 300 DPI = 1800 x 1200)
            const passportCanvas = document.getElementById('passport-canvas');
            passportCanvas.width = 1800;
            passportCanvas.height = 1200;
            const pCtx = passportCanvas.getContext('2d');
            
            pCtx.fillStyle = '#ffffff';
            pCtx.fillRect(0, 0, passportCanvas.width, passportCanvas.height);
            drawPhotoGridWithPan(pCtx, uploadedImage, 4, 2, 1800, 1200);

            // Stamp Sheet (Portrait 4x6 at 300 DPI = 1200 x 1800)
            const stampCanvas = document.getElementById('stamp-canvas');
            stampCanvas.width = 1200;
            stampCanvas.height = 1800;
            const sCtx = stampCanvas.getContext('2d');
            
            sCtx.fillStyle = '#ffffff';
            sCtx.fillRect(0, 0, stampCanvas.width, stampCanvas.height);
            drawPhotoGridWithPan(sCtx, uploadedImage, 3, 4, 1200, 1800);
        }

        function drawPhotoGridWithPan(ctx, img, cols, rows, sheetW, sheetH) {
            const marginX = 80;
            const marginY = 80;
            const spacing = 30;

            const availableWidth = sheetW - (2 * marginX) - ((cols - 1) * spacing);
            const availableHeight = sheetH - (2 * marginY) - ((rows - 1) * spacing);

            const photoW = availableWidth / cols;
            const photoH = availableHeight / rows;

            for (let r = 0; r < rows; r++) {
                for (let c = 0; c < cols; c++) {
                    const x = marginX + c * (photoW + spacing);
                    const y = marginY + r * (photoH + spacing);

                    ctx.fillStyle = currentBgColor;
                    ctx.fillRect(x, y, photoW, photoH);

                    drawPannedImage(ctx, img, x, y, photoW, photoH);

                    ctx.strokeStyle = '#D1D5DB';
                    ctx.lineWidth = 2;
                    ctx.strokeRect(x, y, photoW, photoH);

                    drawCornerMarks(ctx, x, y, photoW, photoH);
                }
            }
        }

        function drawCornerMarks(ctx, x, y, w, h) {
            const len = 20;
            ctx.strokeStyle = '#94a3b8';
            ctx.lineWidth = 3;

            // Top-Left
            ctx.beginPath();
            ctx.moveTo(x, y + len);
            ctx.lineTo(x, y);
            ctx.lineTo(x + len, y);
            ctx.stroke();

            // Top-Right
            ctx.beginPath();
            ctx.moveTo(x + w - len, y);
            ctx.lineTo(x + w, y);
            ctx.lineTo(x + w, y + len);
            ctx.stroke();

            // Bottom-Left
            ctx.beginPath();
            ctx.moveTo(x, y + h - len);
            ctx.lineTo(x, y + h);
            ctx.lineTo(x + len, y + h);
            ctx.stroke();

            // Bottom-Right
            ctx.beginPath();
            ctx.moveTo(x + w - len, y + h);
            ctx.lineTo(x + w, y + h);
            ctx.lineTo(x + w, y + h - len);
            ctx.stroke();
        }

        function drawPannedImage(ctx, img, x, y, w, h) {
            ctx.save();
            ctx.beginPath();
            ctx.rect(x, y, w, h);
            ctx.clip();

            const scaleFactor = w / imgDisplayWidth;
            const mappedOffsetX = offsetX * 2 * scaleFactor;
            const mappedOffsetY = offsetY * 2 * scaleFactor;

            const targetAspect = w / h;
            let sWidth, sHeight, sX, sY;
            const imgAspect = img.width / img.height;

            if (imgAspect > targetAspect) {
                sHeight = img.height;
                sWidth = img.height * targetAspect;
                sX = (img.width - sWidth) / 2 - (mappedOffsetX * (img.height / h));
                sY = 0;
            } else {
                sWidth = img.width;
                sHeight = img.width / targetAspect;
                sX = 0;
                sY = (img.height - sHeight) / 2 - (mappedOffsetY * (img.width / w));
            }

            ctx.drawImage(img, sX, sY, sWidth, sHeight, x, y, w, h);
            ctx.restore();
        }

        function downloadSheet(type) {
            const srcCanvas = document.getElementById(`${type}-canvas`);
            
            // Dedicated off-screen canvas explicitly flooded with solid white before drawing
            const exportCanvas = document.createElement('canvas');
            exportCanvas.width = srcCanvas.width;
            exportCanvas.height = srcCanvas.height;
            const expCtx = exportCanvas.getContext('2d');

            expCtx.fillStyle = '#ffffff';
            expCtx.fillRect(0, 0, exportCanvas.width, exportCanvas.height);
            expCtx.drawImage(srcCanvas, 0, 0);

            const orientationSuffix = type === 'stamp' ? 'portrait-4x6' : 'landscape-6x4';
            const link = document.createElement('a');
            link.download = `${type}-${orientationSuffix}.jpg`;
            link.href = exportCanvas.toDataURL('image/jpeg', 1.0);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }

        function resetUpload() {
            document.getElementById('workspace-view').classList.add('hidden');
            document.getElementById('upload-view').classList.remove('hidden');
            document.getElementById('photo-input').value = '';
            uploadedImage = null;
            offsetX = 0;
            offsetY = 0;
        }
    </script>
</body>
</html>