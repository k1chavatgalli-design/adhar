<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Karnataka E-Ration Card Generator</title>
    <style>
        :root {
            --phh-bg: #aabd9d;
            --phh-border: #7eab74;
            --phh-header: #3f652a;
            
            --aay-bg: #F5A9A9;
            --aay-border: #F5A9A9;
            --aay-header: #FA5858;

            --nphh-bg: #C8C4E7;
            --nphh-border: #C8C4E7;
            --nphh-header: #6D87D2;

            --card-bg: var(--phh-bg);
            --card-border: var(--phh-border);
            --card-header: var(--phh-header);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: Verdana, Geneva, Tahoma, sans-serif;
        }

        body {
            background-color: #313538;
            color: #333;
            padding: 15px;
        }

        .main-wrapper {
            display: flex;
            flex-direction: column;
            gap: 20px;
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Form Controls */
        .form-side {
            background: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .form-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #2e7d32;
            padding-bottom: 8px;
            margin-bottom: 15px;
        }

        .form-header h2 {
            font-size: 1.1rem;
            color: #2e7d32;
        }

        .btn-autofill {
            background: #0284c7;
            color: white;
            border: none;
            padding: 6px 12px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
            font-weight: bold;
        }

        .btn-autofill:hover { background: #0369a1; }

        .fieldset-group {
            border: 1px solid #d1d5db;
            border-radius: 6px;
            padding: 12px;
            margin-bottom: 15px;
            background-color: #fafafa;
        }

        .fieldset-group legend {
            font-weight: bold;
            color: #2e7d32;
            padding: 0 6px;
            font-size: 0.85rem;
        }

        .form-row {
            display: flex;
            gap: 10px;
            margin-bottom: 10px;
        }

        .form-col {
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 0.72rem;
            font-weight: bold;
            color: #374151;
            margin-bottom: 3px;
        }

        input[type="text"], select, textarea {
            padding: 6px 8px;
            border: 1px solid #9ca3af;
            border-radius: 4px;
            font-size: 0.8rem;
            width: 100%;
        }

        input[type="file"] {
            font-size: 0.72rem;
            margin-top: 3px;
        }

        textarea {
            resize: vertical;
            height: 45px;
            line-height: 1.2;
        }

        .member-card {
            border: 1px dashed #2e7d32;
            padding: 8px;
            border-radius: 5px;
            margin-bottom: 8px;
            background: #fff;
            position: relative;
        }

        .btn-remove-member {
            position: absolute;
            top: 4px;
            right: 4px;
            background: #ef4444;
            color: white;
            border: none;
            padding: 2px 5px;
            border-radius: 3px;
            cursor: pointer;
            font-size: 0.65rem;
        }

        .btn-add-member {
            background: #16a34a;
            color: white;
            border: none;
            padding: 7px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.8rem;
            font-weight: bold;
            width: 100%;
        }

        .btn-print {
            background: #2e7d32;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.95rem;
            font-weight: bold;
            width: 100%;
            box-shadow: 0 4px 6px rgba(0,0,0,0.2);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-print:hover { background: #1b5e20; }

        /* Preview Display Frame at BOTTOM */
        .preview-side {
            background: #525659;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            border-radius: 8px;
            overflow-x: auto;
            width: 100%;
        }

        .preview-toolbar {
            width: 100%;
            max-width: 210mm;
            display: flex;
            justify-content: flex-end;
            margin-bottom: 10px;
        }

        .top-print-btn {
            background: #1e293b;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.85rem;
            font-weight: bold;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        .top-print-btn:hover { background: #0f172a; }

        /* Exact A4 Portrait Printable Sheet Container - Positioned to TOP */
        #rc-container {
            background: white;
            width: 210mm;
            height: 297mm;
            padding: 10mm 12mm;
            box-shadow: 0 0 12px rgba(0,0,0,0.4);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            box-sizing: border-box;
            overflow: hidden;
        }

        /* Document Table Elements */
        #tblRCard {
            width: 740px;
            border-collapse: collapse;
            font-size: 7.5pt;
        }

        .card-column-left {
            width: 350px;
            vertical-align: top;
            border: 1px solid var(--card-border);
            padding: 6px;
            height: 485px;
            box-sizing: border-box;
        }

        .card-column-right {
            width: 365px;
            vertical-align: top;
            border: 1px solid var(--card-border);
            background-color: var(--card-bg);
            padding: 0;
            height: 485px;
            box-sizing: border-box;
        }

        .left-inner-box {
            height: 355px;
            width: 100%;
            border: 4px double var(--card-border);
            padding: 6px;
            box-sizing: border-box;
        }

        .left-disclaimer-box {
            width: 100%;
            height: 100px;
            font-size: 6.8pt;
            background-color: var(--card-bg);
            color: #000;
            border-radius: 14px 14px 0 0;
            margin-top: 8px;
            padding: 6px;
            text-align: center;
            line-height: 1.3;
            display: flex;
            flex-direction: column;
            justify-content: center;
            box-sizing: border-box;
        }

        .right-header-box {
            min-height: 95px;
            background-color: var(--card-header);
            color: white !important;
            border-radius: 0 0 14px 14px;
            padding: 8px 10px;
            box-sizing: border-box;
        }

        .right-header-box * {
            color: white !important;
        }

        /* Member Grid Formatting with 0.1 inch (~7.2pt / 2.5mm) Gap */
        .member-grid-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0 0.1in;
            margin-top: 2px;
        }

        .member-grid-table > tbody > tr > td {
            border: 1px solid #000;
            padding: 4px;
            vertical-align: top;
            width: 50%;
        }

        .member-cell-table {
            width: 100%;
            border-collapse: collapse;
        }

        .member-cell-table td {
            border: none !important;
            padding: 0 !important;
            vertical-align: top;
        }

        .member-text-cell {
            font-size: 6.8pt;
            line-height: 1.25;
            word-break: break-word;
            padding-right: 4px !important;
        }

        .member-img-cell {
            width: 48px;
            text-align: right;
        }

        .member-img {
            width: 46px;
            height: 56px;
            object-fit: cover;
            border: 1px solid #ccc;
        }

        .head-img {
            width: 54px;
            height: 64px;
            object-fit: cover;
            border: 1px solid #ccc;
        }

        .padded-row {
            padding-top: 5px !important;
            padding-bottom: 5px !important;
        }

        .divider-row {
            border-top: 1px solid #716b83;
            border-bottom: 1px solid #716b83;
            padding-top: 5px !important;
            padding-bottom: 5px !important;
        }

        .white-bg-row {
            background-color: #ffffff;
            padding-top: 5px !important;
            padding-bottom: 5px !important;
        }

        .text-line {
            line-height: 1.25;
            word-break: break-word;
            margin-bottom: 3px;
        }

        /* PRINT STYLES - EXACT A4 TOP FIT */
        @media print {
            body {
                background: white;
                padding: 0;
                margin: 0;
            }
            .form-side, .preview-toolbar {
                display: none !important;
            }
            .preview-side {
                background: white;
                padding: 0;
                margin: 0;
                display: block;
            }
            #rc-container {
                width: 210mm !important;
                height: 297mm !important;
                box-shadow: none !important;
                padding: 10mm 12mm !important;
                margin: 0 !important;
                justify-content: flex-start !important;
                page-break-after: avoid;
                page-break-inside: avoid;
            }
            @page {
                size: A4 portrait;
                margin: 0;
            }
        }
    </style>
</head>
<body>

<div class="main-wrapper">
    <!-- TOP INPUT FORM -->
    <div class="form-side">
        <div class="form-header">
            <h2>E-Ration Card Generator</h2>
            <button type="button" class="btn-autofill" onclick="autoFillData()">⚡ Load Sample Record</button>
        </div>

        <form id="rcForm">
            <!-- Category & Info -->
            <fieldset class="fieldset-group">
                <legend>Ration Card Type & Office Details</legend>
                <div class="form-row">
                    <div class="form-col">
                        <label>Category (Card Type)</label>
                        <select id="cardCategory" onchange="updateCardTheme()">
                            <option value="PHH">PHH - Priority Household (Green)</option>
                            <option value="AAY">AAY - Antyodaya Anna Yojane (Pink)</option>
                            <option value="NPHH">NPHH - Non-Priority Household (Blue)</option>
                        </select>
                    </div>
                    <div class="form-col">
                        <label>Ack Number</label>
                        <input type="text" id="ackNo" value="202299424" oninput="syncData()">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-col">
                        <label>Ration Card No.</label>
                        <input type="text" id="rcNo" value="540500361602" oninput="syncData()">
                    </div>
                    <div class="form-col">
                        <label>Issue Date</label>
                        <input type="text" id="issueDate" value="27/04/2015" oninput="syncData()">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-col">
                        <label>Taluk (Kannada)</label>
                        <input type="text" id="taluk" value="ಬೆಳಗಾವಿ" oninput="syncData()">
                    </div>
                    <div class="form-col">
                        <label>District (Kannada)</label>
                        <input type="text" id="district" value="ಬೆಳಗಾವಿ" oninput="syncData()">
                    </div>
                    <div class="form-col">
                        <label>Office Phone</label>
                        <input type="text" id="officePhone" value="0831-2464387" oninput="syncData()">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-col">
                        <label>Emblem Logo Upload (Replaces Header Logo)</label>
                        <input type="file" accept="image/*" onchange="loadLogoImage(event)">
                    </div>
                </div>
            </fieldset>

            <!-- HOF Details -->
            <fieldset class="fieldset-group">
                <legend>Head of Family (HOF)</legend>
                <div class="form-row">
                    <div class="form-col">
                        <label>HOF Name (English)</label>
                        <input type="text" id="hofNameEng" value="LAXMI MAHADEV SAMAGAR" oninput="syncData()">
                    </div>
                    <div class="form-col">
                        <label>HOF Name & Age (Kannada)</label>
                        <input type="text" id="hofNameKan" value="ಲಕ್ಷ್ಮೀ ಮಹಾದೇವ ಸಮಗಾರ (43)" oninput="syncData()">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-col">
                        <label>HOF Photo Upload</label>
                        <input type="file" accept="image/*" onchange="loadHeadImage(event)">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-col">
                        <label>Address (Kannada)</label>
                        <textarea id="addressKan" oninput="syncData()">ಸ್/ಓ ಮಹಾದೇವ ಸಮಗಾರ, ಶಾಪ್ ನಂ ೦೫, ಯಮಕನಮರಡಿ ಸೊಸೈಟಿ ಪಕ್ಕ, ರೇಣುಕಾ ಜೆರಾಕ್ಸ ಎದುರಿಗೆ, ಕೋರ್ಟ್ ಕಾಂಪೌಂಡ್, ಚವಾಟ ಗಲ್ಲಿ 590001</textarea>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-col">
                        <label>Address (English)</label>
                        <textarea id="addressEng" oninput="syncData()">S/O MAHADEV SAMAGAR, SHOP NO 05, BESIDE YAMKANMARDI SOCIETY, OPP RENUKA ZEROX, COURT COMPOUND, CHAVAT GALLI, BELGAUM - 590001</textarea>
                    </div>
                </div>
            </fieldset>

            <!-- Members -->
            <fieldset class="fieldset-group">
                <legend>Family Members</legend>
                <div id="membersContainer"></div>
                <button type="button" class="btn-add-member" onclick="addMember()">+ Add Family Member</button>
            </fieldset>

            <!-- FPS Details -->
            <fieldset class="fieldset-group">
                <legend>Fair Price Shop (FPS) Details</legend>
                <div class="form-row">
                    <div class="form-col">
                        <label>FPS Name & No. (Kannada)</label>
                        <input type="text" id="fpsKan" value="334-ಮಹಾಲಷ್ಮಿ ನಗರ ಸ್ತ್ರೀ. ಶ. ಸ್ವ ಸ.ಸಂಘ" oninput="syncData()">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-col">
                        <label>FPS Name, No. & Address (English)</label>
                        <textarea id="fpsEng" oninput="syncData()">334-mahalaxmi nagar strishakti svasahaya sangh, near railway bridge, old gandhi nagar, Belgaum</textarea>
                    </div>
                </div>
            </fieldset>

            <button type="button" class="btn-print" onclick="window.print()">
                🖨️ Print / Save as PDF (A4)
            </button>
        </form>
    </div>

    <!-- BOTTOM LIVE PREVIEW CANVAS / A4 PDF PREVIEW -->
    <div class="preview-side">
        <div class="preview-toolbar">
            <button type="button" class="top-print-btn" onclick="window.print()">🖨️ Print / Save as PDF (A4)</button>
        </div>

        <div id="rc-container">
            <table id="tblRCard">
                <tr>
                    <td style="padding:0;">
                        <table width="100%" cellpadding="0" cellspacing="0">
                            <tr>
                                <!-- LEFT PANEL: MEMBER LIST -->
                                <td class="card-column-left">
                                    <div class="left-inner-box">
                                        <div style="text-align: center; padding-top: 2px; margin-bottom: 4px;">
                                            <span style="font-size: 7.2pt;">ಕುಟುಂಬದ ಸದಸ್ಯರ ವಿವರಗಳು</span><br>
                                            <span style="font-size: 7.2pt;">Family Member's Detail</span>
                                        </div>
                                        <div id="previewMembersGrid">
                                            <!-- Dynamically injected table -->
                                        </div>
                                    </div>

                                    <!-- Bottom Helpline Container -->
                                    <div class="left-disclaimer-box" id="leftDisclaimer">
                                        <span>ಪಡಿತರ ವ್ಯವಸ್ಥೆಯ ಬಗ್ಗೆ ಹೆಚ್ಚಿನ ಮಾಹಿತಿಗಾಗಿ ದಯವಿಟ್ಟು ಇಲಾಖೆಯ<br>
                                        ವೆಬ್ ಸೈಟ್ https://ahara.karnataka.gov.in ಗೆ ಭೇಟಿ ನೀಡಿ<br>
                                        ಗ್ರಾಹಕರ ಸಹಾಯವಾಣಿ(ನಿಶುಲ್ಕ): 1967, 14445 ಅಥವಾ 1800-425-9339</span>
                                        <div style="height: 3px;"></div>
                                        <span>For additional Information on public distribution system<br>
                                        please visit department website https://ahara.karnataka.gov.in<br>
                                        Consumer Helpline (Toll Free): 1967, 14445 ಅಥವಾ 1800-425-9339</span>
                                    </div>
                                </td>

                                <td style="width: 40px;">&nbsp;</td>

                                <!-- RIGHT PANEL: OFFICIAL RATION CARD -->
                                <td class="card-column-right">
                                    <table width="100%" cellpadding="0" cellspacing="0">
                                        <!-- Header Block -->
                                        <tr>
                                            <td style="padding:0;">
                                                <div class="right-header-box" id="rightHeader">
                                                    <table width="100%" cellpadding="0" cellspacing="0">
                                                        <tr>
                                                            <td align="left" valign="top" style="width: 32%;">
                                                                <span id="pBadge" style="font-size:13pt; font-weight:bold; display:block; line-height:1;">PHH</span>
                                                                <span id="pAckNo" style="font-size:6.8pt; display:block; margin-top:3px;">202299424</span>
                                                            </td>
                                                            <td align="center" valign="middle" style="width: 36%;" id="logoContainer">
                                                                <!-- Default Karnataka Double-Headed Bird Emblem SVG (Overridden if user uploads image) -->
                                                                <svg id="defaultLogoSvg" width="42" height="40" viewBox="0 0 120 100" style="display:block; margin:0 auto;">
                                                                    <path d="M52 12 C52 8, 56 6, 60 6 C64 6, 68 8, 68 12 L66 18 L54 18 Z" fill="#ea580c"/>
                                                                    <circle cx="57" cy="12" r="1.2" fill="#fff"/>
                                                                    <circle cx="63" cy="12" r="1.2" fill="#fff"/>
                                                                    <path d="M60 20 C42 20 22 30 20 46 C18 56 26 66 34 68 C42 70 48 60 54 52 C56 60 52 74 40 80 C50 82 58 78 60 72 C62 78 70 82 80 80 C68 74 64 60 66 52 C72 60 78 70 86 68 C94 66 102 56 100 46 C98 30 78 20 60 20 Z" fill="#ea580c"/>
                                                                    <path d="M22 42 C16 44 12 52 15 60 C18 66 24 66 28 62 C25 56 23 48 22 42 Z" fill="#15803d"/>
                                                                    <path d="M98 42 C104 44 108 52 105 60 C102 66 96 66 92 62 C95 56 97 48 98 42 Z" fill="#15803d"/>
                                                                    <path d="M38 84 L82 84 L76 92 L44 92 Z" fill="#15803d"/>
                                                                </svg>
                                                            </td>
                                                            <td align="right" valign="top" style="width: 32%;">
                                                                <span id="pCardTypeKan" style="font-size:6.2pt; font-weight:bold; display:block; line-height:1.2;">ಆದ್ಯತಾ ಕುಟುಂಬ ಸೀಮೆಎಣ್ಣೆಗೆ ಅನರ್ಹ</span>
                                                                <span id="pCardTypeEng" style="font-size:5.8pt; font-weight:bold; display:block; line-height:1.2; margin-top:2px;">Priority Household Not Eligible for Kerosene</span>
                                                            </td>
                                                        </tr>
                                                    </table>
                                                    <div style="text-align: center; margin-top: 4px; border-top: 1px solid rgba(255,255,255,0.2); padding-top: 3px;">
                                                        <span style="font-size:8pt; font-weight:bold; display:block; line-height:1.2;">ಕರ್ನಾಟಕ ಸರ್ಕಾರ</span>
                                                        <span style="font-size:8pt; font-weight:bold; display:block; line-height:1.2;">GOVERNMENT OF KARNATAKA</span>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>

                                        <!-- Department Title -->
                                        <tr>
                                            <td class="padded-row">
                                                <div style="font-weight: bold; font-size: 7.2pt; margin-bottom: 2px;">ಆಹಾರ, ನಾಗರಿಕ ಸರಬರಾಜು ಮತ್ತು ಗ್ರಾಹಕರ ವ್ಯವಹಾರಗಳ ಇಲಾಖೆ</div>
                                                <div style="font-weight: bold; font-size: 7.2pt; margin-bottom: 3px;">Food, Civil Supplies and Consumer Affairs Department</div>
                                                <table width="100%" cellpadding="0" cellspacing="0" style="margin-top: 3px;">
                                                    <tr>
                                                        <td style="width: 50%;">ತಾಲ್ಲೂಕು : <strong id="pTaluk">ಬೆಳಗಾವಿ</strong></td>
                                                        <td style="width: 50%;">ಜಿಲ್ಲೆ : <strong id="pDistrict">ಬೆಳಗಾವಿ</strong></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>

                                        <!-- Ration Card Number Row -->
                                        <tr>
                                            <td class="divider-row">
                                                <table width="100%" cellpadding="0" cellspacing="0">
                                                    <tr>
                                                        <td><span>ಪಡಿತರ ಚೀಟಿಯ ಸಂಖ್ಯೆ Ration Card No.: </span></td>
                                                        <td align="left"><strong id="pRcNo" style="font-size: 7.8pt;">540500361602</strong></td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>

                                        <!-- HOF Info Block with Increased Top Margin / Spacing Added to First Line -->
                                        <tr class="white-bg-row">
                                            <td>
                                                <table width="100%" cellpadding="0" cellspacing="0">
                                                    <tr>
                                                        <td style="width: 60px; height: 62px;" align="left" valign="top">
                                                            <img id="pHofImg" src="data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='48' height='56' viewBox='0 0 48 56'><rect width='48' height='56' fill='%23cbd5e1'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' font-size='8' fill='%23475569'>Photo</text></svg>" class="head-img">
                                                        </td>
                                                        <td align="left" valign="top" style="padding-left: 6px;">
                                                            <div id="pHofNameEng" class="text-line" style="font-size: 7.2pt; margin-top: 9px;">LAXMI MAHADEV SAMAGAR</div>
                                                            <div style="height: 3px;"></div>
                                                            <div id="pHofNameKan" class="text-line" style="font-size: 7.2pt;">ಲಕ್ಷ್ಮೀ ಮಹಾದೇವ ಸಮಗಾರ (43)</div>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>

                                        <!-- HOF Address Block -->
                                        <tr class="white-bg-row">
                                            <td style="height: 52px;" align="left" valign="top">
                                                <div id="pAddressKan" class="text-line" style="font-size: 6.8pt; margin-bottom: 3px;"></div>
                                                <div id="pAddressEng" class="text-line" style="font-size: 6.8pt;"></div>
                                            </td>
                                        </tr>

                                        <!-- Family Member Count -->
                                        <tr>
                                            <td class="padded-row" align="right">
                                                <strong>ಸದಸ್ಯರ ಸಂಖ್ಯೆ Family Members : </strong>
                                                <span id="pMemberCount" style="font-size: 7.2pt; padding-right: 12px;">3</span>
                                            </td>
                                        </tr>

                                        <!-- Gas Connection Details -->
                                        <tr>
                                            <td class="divider-row">
                                                <div style="margin-bottom: 2px;">ಅನಿಲ ಗ್ರಾಹಕರ ಸಂಖ್ಯೆ ಮತ್ತು ಹೆಸರು :</div>
                                                <div>Consumer No. & Distributor's Name :</div>
                                            </td>
                                        </tr>

                                        <!-- FPS Info -->
                                        <tr>
                                            <td class="padded-row" style="height: 55px;" align="left" valign="top">
                                                <div style="margin-bottom: 1px;">ನ್ಯಾಯಬೆಲೆ ಅಂಗಡಿಯ ಸಂಖ್ಯೆ ಮತ್ತು ಹೆಸರು :</div>
                                                <div style="margin-bottom: 3px;">Fair Price Shop No. & Name</div>
                                                <div id="pFpsKan" class="text-line" style="font-size: 6.8pt; margin-top: 2px;"></div>
                                                <div id="pFpsEng" class="text-line" style="font-size: 6.8pt;"></div>
                                            </td>
                                        </tr>

                                        <!-- Contact & Issue Date -->
                                        <tr>
                                            <td class="padded-row">
                                                <table width="100%" cellpadding="0" cellspacing="0">
                                                    <tr>
                                                        <td style="width: 60%;">
                                                            <div style="margin-bottom: 2px;">ಕಛೇರಿಯ ದೂರವಾಣಿ ಸಂಖ್ಯೆ : <span id="pOfficePhone" style="font-size: 7.2pt;">0831-2464387</span></div>
                                                            <div>Office Phone No.:</div>
                                                        </td>
                                                        <td align="right" valign="top">
                                                            <div style="margin-bottom: 2px;">ದಿನಾಂಕ : <span id="pIssueDate" style="font-size: 6.8pt;">27/04/2015</span></div>
                                                            <div>Date :</div>
                                                        </td>
                                                    </tr>
                                                </table>
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>

<script>
    let members = [
        { nameKan: 'ಮಹಾದೇವ ಬಸಪ್ಪ ಸಮಗಾರ', nameEng: 'MAHADEV BASAPPA SAMAGAR', relation: 'ಪತಿ (50)', img: null },
        { nameKan: 'ಸಾಗರ ಮ ಸಮಗಾರ', nameEng: 'SAGAR M SAMAGAR', relation: 'ಮಗ (25)', img: null },
        { nameKan: 'ಸಚಿನ ಸಮಗಾರ', nameEng: 'SACHIN SAMAGAR', relation: 'ಮಗ (21)', img: null }
    ];

    let headImgData = null;

    function renderMemberInputs() {
        const container = document.getElementById('membersContainer');
        container.innerHTML = '';

        members.forEach((m, idx) => {
            const card = document.createElement('div');
            card.className = 'member-card';
            card.innerHTML = `
                <button type="button" class="btn-remove-member" onclick="removeMember(${idx})">✕</button>
                <div class="form-row">
                    <div class="form-col">
                        <label>Member ${idx + 1} Name (Kannada)</label>
                        <input type="text" value="${m.nameKan}" oninput="updateMemberData(${idx}, 'nameKan', this.value)">
                    </div>
                    <div class="form-col">
                        <label>Name (English)</label>
                        <input type="text" value="${m.nameEng}" oninput="updateMemberData(${idx}, 'nameEng', this.value)">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-col">
                        <label>Relation & Age</label>
                        <input type="text" value="${m.relation}" oninput="updateMemberData(${idx}, 'relation', this.value)">
                    </div>
                    <div class="form-col">
                        <label>Photo Upload</label>
                        <input type="file" accept="image/*" onchange="loadMemberImage(event, ${idx})">
                    </div>
                </div>
            `;
            container.appendChild(card);
        });
    }

    function addMember() {
        members.push({ nameKan: '', nameEng: '', relation: '', img: null });
        renderMemberInputs();
        syncData();
    }

    function removeMember(idx) {
        members.splice(idx, 1);
        renderMemberInputs();
        syncData();
    }

    function updateMemberData(idx, field, val) {
        members[idx][field] = val;
        syncData();
    }

    function loadMemberImage(event, idx) {
        const reader = new FileReader();
        reader.onload = function() {
            members[idx].img = reader.result;
            syncData();
        };
        if(event.target.files[0]) reader.readAsDataURL(event.target.files[0]);
    }

    function loadHeadImage(event) {
        const reader = new FileReader();
        reader.onload = function() {
            headImgData = reader.result;
            document.getElementById('pHofImg').src = headImgData;
        };
        if(event.target.files[0]) reader.readAsDataURL(event.target.files[0]);
    }

    function loadLogoImage(event) {
        const reader = new FileReader();
        reader.onload = function() {
            const logoContainer = document.getElementById('logoContainer');
            logoContainer.innerHTML = `<img src="${reader.result}" style="width: 42px; height: 40px; object-fit: contain; display: block; margin: 0 auto; background: transparent;">`;
        };
        if(event.target.files[0]) reader.readAsDataURL(event.target.files[0]);
    }

    function updateCardTheme() {
        const category = document.getElementById('cardCategory').value;
        const root = document.documentElement;

        if (category === 'AAY') {
            root.style.setProperty('--card-bg', 'var(--aay-bg)');
            root.style.setProperty('--card-border', 'var(--aay-border)');
            root.style.setProperty('--card-header', 'var(--aay-header)');
            document.getElementById('pBadge').innerText = 'AAY';
            document.getElementById('pCardTypeKan').innerText = 'ಅಂತ್ಯೋದಯ ಅನ್ನ ಯೋಜನೆ ಸೀಮೆಎಣ್ಣೆಗೆ ಅನರ್ಹ';
            document.getElementById('pCardTypeEng').innerText = 'Antyodaya Anna Yojane Not Eligible for Kerosene';
        } else if (category === 'NPHH') {
            root.style.setProperty('--card-bg', 'var(--nphh-bg)');
            root.style.setProperty('--card-border', 'var(--nphh-border)');
            root.style.setProperty('--card-header', 'var(--nphh-header)');
            document.getElementById('pBadge').innerText = 'NPHH';
            document.getElementById('pCardTypeKan').innerText = 'ಆದ್ಯತೇತರ ಕುಟುಂಬ ಸೀಮೆಎಣ್ಣೆಗೆ ಅನರ್ಹ';
            document.getElementById('pCardTypeEng').innerText = 'Non Priority Household Not Eligible for Kerosene';
        } else {
            root.style.setProperty('--card-bg', 'var(--phh-bg)');
            root.style.setProperty('--card-border', 'var(--phh-border)');
            root.style.setProperty('--card-header', 'var(--phh-header)');
            document.getElementById('pBadge').innerText = 'PHH';
            document.getElementById('pCardTypeKan').innerText = 'ಆದ್ಯತಾ ಕುಟುಂಬ ಸೀಮೆಎಣ್ಣೆಗೆ ಅನರ್ಹ';
            document.getElementById('pCardTypeEng').innerText = 'Priority Household Not Eligible for Kerosene';
        }
    }

    function syncData() {
        document.getElementById('pAckNo').innerText = document.getElementById('ackNo').value;
        document.getElementById('pRcNo').innerText = document.getElementById('rcNo').value;
        document.getElementById('pIssueDate').innerText = document.getElementById('issueDate').value;
        document.getElementById('pTaluk').innerText = document.getElementById('taluk').value;
        document.getElementById('pDistrict').innerText = document.getElementById('district').value;
        document.getElementById('pOfficePhone').innerText = document.getElementById('officePhone').value;

        document.getElementById('pHofNameEng').innerText = document.getElementById('hofNameEng').value;
        document.getElementById('pHofNameKan').innerText = document.getElementById('hofNameKan').value;
        document.getElementById('pAddressKan').innerText = document.getElementById('addressKan').value;
        document.getElementById('pAddressEng').innerText = document.getElementById('addressEng').value;

        document.getElementById('pFpsKan').innerText = document.getElementById('fpsKan').value;
        document.getElementById('pFpsEng').innerText = document.getElementById('fpsEng').value;

        document.getElementById('pMemberCount').innerText = members.length;

        const grid = document.getElementById('previewMembersGrid');
        grid.innerHTML = '';

        const table = document.createElement('table');
        table.className = 'member-grid-table';
        
        let html = '';
        for (let i = 0; i < members.length; i += 2) {
            html += '<tr>';
            
            const m1 = members[i];
            const img1 = m1.img || "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='44' height='52' viewBox='0 0 44 52'><rect width='44' height='52' fill='%23cbd5e1'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' font-size='7.5' fill='%23475569'>Photo</text></svg>";
            html += `
                <td>
                    <table class="member-cell-table">
                        <tr>
                            <td class="member-text-cell">
                                <div style="margin-bottom:2px;">${m1.nameKan}</div>
                                <div style="margin-bottom:2px;">${m1.relation}</div>
                                <strong>${m1.nameEng}</strong>
                            </td>
                            <td class="member-img-cell">
                                <img src="${img1}" class="member-img">
                            </td>
                        </tr>
                    </table>
                </td>
            `;

            if (i + 1 < members.length) {
                const m2 = members[i + 1];
                const img2 = m2.img || "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='44' height='52' viewBox='0 0 44 52'><rect width='44' height='52' fill='%23cbd5e1'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' font-size='7.5' fill='%23475569'>Photo</text></svg>";
                html += `
                    <td>
                        <table class="member-cell-table">
                            <tr>
                                <td class="member-text-cell">
                                    <div style="margin-bottom:2px;">${m2.nameKan}</div>
                                    <div style="margin-bottom:2px;">${m2.relation}</div>
                                    <strong>${m2.nameEng}</strong>
                                </td>
                                <td class="member-img-cell">
                                    <img src="${img2}" class="member-img">
                                </td>
                            </tr>
                        </table>
                    </td>
                `;
            } else {
                html += '<td></td>';
            }

            html += '</tr>';
        }

        table.innerHTML = html;
        grid.appendChild(table);
    }

    function autoFillData() {
        document.getElementById('cardCategory').value = 'PHH';
        document.getElementById('ackNo').value = '202299424';
        document.getElementById('rcNo').value = '540500361602';
        document.getElementById('issueDate').value = '27/04/2015';
        document.getElementById('taluk').value = 'ಬೆಳಗಾವಿ';
        document.getElementById('district').value = 'ಬೆಳಗಾವಿ';
        document.getElementById('officePhone').value = '0831-2464387';

        document.getElementById('hofNameEng').value = 'LAXMI MAHADEV SAMAGAR';
        document.getElementById('hofNameKan').value = 'ಲಕ್ಷ್ಮೀ ಮಹಾದೇವ ಸಮಗಾರ (43)';
        document.getElementById('addressKan').value = 'ಸ್/ಓ ಮಹಾದೇವ ಸಮಗಾರ, ಶಾಪ್ ನಂ ೦೫, ಯಮಕನಮರಡಿ ಸೊಸೈಟಿ ಪಕ್ಕ, ರೇಣುಕಾ ಜೆರಾಕ್ಸ ಎದುರಿಗೆ, ಕೋರ್ಟ್ ಕಾಂಪೌಂಡ್, ಚವಾಟ ಗಲ್ಲಿ 590001';
        document.getElementById('addressEng').value = 'S/O MAHADEV SAMAGAR, SHOP NO 05, BESIDE YAMKANMARDI SOCIETY, OPP RENUKA ZEROX, COURT COMPOUND, CHAVAT GALLI, BELGAUM - 590001';

        document.getElementById('fpsKan').value = '334-ಮಹಾಲಷ್ಮಿ ನಗರ ಸ್ತ್ರೀ. ಶ. ಸ್ವ ಸ.ಸಂಘ';
        document.getElementById('fpsEng').value = '334-mahalaxmi nagar strishakti svasahaya sangh, near railway bridge, old gandhi nagar, Belgaum';

        members = [
            { nameKan: 'ಮಹಾದೇವ ಬಸಪ್ಪ ಸಮಗಾರ', nameEng: 'MAHADEV BASAPPA SAMAGAR', relation: 'ಪತಿ (50)', img: null },
            { nameKan: 'ಸಾಗರ ಮ ಸಮಗಾರ', nameEng: 'SAGAR M SAMAGAR', relation: 'ಮග (25)', img: null },
            { nameKan: 'ಸಚಿನ ಸಮಗಾರ', nameEng: 'SACHIN SAMAGAR', relation: 'ಮග (21)', img: null }
        ];

        renderMemberInputs();
        updateCardTheme();
        syncData();
    }

    window.onload = function() {
        renderMemberInputs();
        updateCardTheme();
        syncData();
    };
</script>

</body>
</html>