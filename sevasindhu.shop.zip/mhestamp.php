<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maharashtra Gazette - Name Change Affidavit Form & Generator</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Lucide Icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <!-- docx.js for client-side Word document creation -->
    <script src="https://unpkg.com/docx@8.2.2/build/index.umd.js"></script>
    <!-- FileSaver.js for saving generated files -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>
    <!-- Google Fonts including Bookman substitute font -->
    <link href="https://fonts.googleapis.com/css2?family=Bookman+URW:ital,wght@0,400;0,700;1,400&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        legal: {
                            50: '#f0f4f8',
                            100: '#d9e2ec',
                            500: '#334e68',
                            600: '#243b53',
                            700: '#102a43',
                            800: '#0b1b2b',
                            gold: '#b7791f'
                        }
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        bookman: ['"Bookman Old Style"', 'Bookman', '"URW Bookman L"', 'serif']
                    }
                }
            }
        }
    </script>
    <style>
        :root {
            --doc-font-size: 14px;
        }

        /* Print Styles - Completely Cleaned for PDF Export */
        @page {
            size: A4 portrait;
            margin: 15mm;
        }

        @media print {
            html, body {
                background: #ffffff !important;
                color: #000000 !important;
                margin: 0 !important;
                padding: 0 !important;
            }
            .no-print {
                display: none !important;
            }
            .print-container {
                padding: 0 !important;
                margin: 0 !important;
                background: transparent !important;
                border: none !important;
                box-shadow: none !important;
            }
            .paper-preview {
                box-shadow: none !important;
                border: none !important;
                outline: none !important;
                padding: 0 !important;
                margin: 0 !important;
                width: 100% !important;
                max-width: 100% !important;
                min-height: auto !important;
            }
        }

        .font-bookman-style {
            font-family: 'Bookman Old Style', 'Bookman', 'URW Bookman L', 'Times New Roman', serif;
        }

        #paperSheet {
            font-size: var(--doc-font-size);
        }

        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f5f9;
        }
        ::-webkit-scrollbar-thumb {
            background: #cbd5e1;
            border-radius: 4px;
        }
    </style>
</head>
<body class="bg-slate-100 font-sans text-slate-800 min-h-screen flex flex-col">

    <!-- Toast Notification -->
    <div id="toast" class="fixed bottom-5 right-5 z-50 transform translate-y-20 opacity-0 transition-all duration-300 ease-in-out bg-slate-900 text-white px-5 py-3 rounded-xl shadow-2xl flex items-center space-x-3 pointer-events-none">
        <i id="toast-icon" data-lucide="check-circle" class="w-5 h-5 text-emerald-400"></i>
        <span id="toast-message" class="text-sm font-medium">Notification message</span>
    </div>

    <!-- Header / Navbar -->
    <header class="bg-legal-700 text-white shadow-lg no-print sticky top-0 z-40">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex flex-wrap items-center justify-between gap-4">
            <div class="flex items-center space-x-3">
                <div class="p-2 bg-legal-600 rounded-lg border border-legal-500">
                    <i data-lucide="file-text" class="w-6 h-6 text-amber-400"></i>
                </div>
                <div>
                    <h1 class="text-lg font-bold tracking-tight text-white flex items-center gap-2">
                        Maharashtra Name Change Gazette Generator
                    </h1>
                    <p class="text-xs text-slate-300">Formatted in Bookman Font • Official Affidavit Layout</p>
                </div>
            </div>
            
            <div class="flex items-center space-x-2">
                <button onclick="autofillSampleData()" class="px-3 py-1.5 text-xs font-medium bg-legal-600 hover:bg-legal-500 text-slate-200 rounded-lg border border-slate-600 transition flex items-center gap-1.5">
                    <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
                    Reset Form
                </button>
            </div>
        </div>
    </header>

    <!-- Main Container -->
    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- LEFT COLUMN: Data Entry Form -->
        <section class="lg:col-span-5 space-y-5 no-print">
            <div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="bg-slate-50 px-5 py-4 border-b border-slate-200 flex items-center justify-between">
                    <h2 class="font-semibold text-slate-800 flex items-center gap-2 text-base">
                        <i data-lucide="edit-3" class="w-5 h-5 text-legal-600"></i>
                        Data Entry Form
                    </h2>
                    <span class="text-xs font-semibold uppercase text-legal-600 bg-legal-50 px-2.5 py-1 rounded-full border border-legal-100">Live Editor</span>
                </div>

                <form id="affidavitForm" class="p-5 space-y-4 text-sm" onsubmit="event.preventDefault();">
                    
                    <!-- Old Name -->
                    <div>
                        <label for="oldName" class="block font-medium text-slate-700 mb-1">Old Name <span class="text-red-500">*</span></label>
                        <div class="relative">
                            <input type="text" id="oldName" value="SALAMA MODIN MULLA" class="w-full uppercase pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-legal-500 focus:border-legal-500 font-semibold text-slate-800" oninput="updatePreview()">
                            <i data-lucide="user-x" class="w-4 h-4 absolute left-3 top-2.5 text-slate-400"></i>
                        </div>
                    </div>

                    <!-- New Name -->
                    <div>
                        <label for="newName" class="block font-medium text-slate-700 mb-1">New Name <span class="text-red-500">*</span></label>
                        <div class="relative">
                            <input type="text" id="newName" value="SHANTA VITTAL TIMMANNAVAR" class="w-full uppercase pl-9 pr-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-legal-500 focus:border-legal-500 font-semibold text-legal-700" oninput="updatePreview()">
                            <i data-lucide="user-check" class="w-4 h-4 absolute left-3 top-2.5 text-emerald-600"></i>
                        </div>
                    </div>

                    <!-- Age Field -->
                    <div>
                        <label for="age" class="block font-medium text-slate-700 mb-1">Age (Years) <span class="text-red-500">*</span></label>
                        <input type="text" id="age" value="51 YEARS" class="w-full uppercase px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-legal-500 focus:border-legal-500" oninput="updatePreview()">
                    </div>

                    <!-- Address Field -->
                    <div>
                        <label for="address" class="block font-medium text-slate-700 mb-1">Address <span class="text-red-500">*</span></label>
                        <textarea id="address" rows="2" class="w-full uppercase px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-legal-500 focus:border-legal-500 text-xs" oninput="updatePreview()">KHANKHA GALLI UDGIR, DIST LATUR, MAHARASHTRA 413517</textarea>
                    </div>

                    <!-- Execution Place -->
                    <div>
                        <label for="executionPlace" class="block font-medium text-slate-700 mb-1">Execution Place</label>
                        <input type="text" id="executionPlace" value="UDGIR, DIST. LATUR" class="w-full uppercase px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-legal-500 focus:border-legal-500" oninput="updatePreview()">
                    </div>

                    <!-- Execution Date Fields (Day, Month, Year) -->
                    <div class="grid grid-cols-3 gap-3">
                        <div>
                            <label for="execDay" class="block font-medium text-slate-700 mb-1">Day</label>
                            <input type="text" id="execDay" value="30" class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-legal-500 focus:border-legal-500 text-center" oninput="updatePreview()">
                        </div>
                        <div>
                            <label for="execMonth" class="block font-medium text-slate-700 mb-1">Month</label>
                            <input type="text" id="execMonth" value="October" class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-legal-500 focus:border-legal-500 text-center" oninput="updatePreview()">
                        </div>
                        <div>
                            <label for="execYear" class="block font-medium text-slate-700 mb-1">Year</label>
                            <input type="text" id="execYear" value="2026" class="w-full px-3 py-2 border border-slate-300 rounded-lg focus:ring-2 focus:ring-legal-500 focus:border-legal-500 text-center" oninput="updatePreview()">
                        </div>
                    </div>
                </form>
            </div>
        </section>

        <!-- RIGHT COLUMN: Live Interactive Document Preview & Action Toolbar -->
        <section class="lg:col-span-7 flex flex-col space-y-4">
            
            <!-- Action Toolbar -->
            <div class="no-print bg-white p-3.5 rounded-2xl shadow-sm border border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <div class="flex items-center space-x-2">
                    <span class="inline-flex items-center px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800">
                        <span class="w-2 h-2 mr-1.5 bg-emerald-500 rounded-full animate-pulse"></span> Font: Bookman
                    </span>

                    <!-- Font Size Controls -->
                    <div class="inline-flex items-center bg-slate-100 rounded-lg border border-slate-300 p-0.5 ml-2">
                        <button type="button" onclick="adjustFontSize(-1)" title="Decrease font size" class="p-1 text-slate-600 hover:text-slate-900 hover:bg-white rounded transition">
                            <i data-lucide="minus" class="w-3.5 h-3.5"></i>
                        </button>
                        <span id="fontSizeDisplay" class="px-2 text-xs font-semibold text-slate-700 select-none">14px</span>
                        <button type="button" onclick="adjustFontSize(1)" title="Increase font size" class="p-1 text-slate-600 hover:text-slate-900 hover:bg-white rounded transition">
                            <i data-lucide="plus" class="w-3.5 h-3.5"></i>
                        </button>
                        <button type="button" onclick="resetFontSize()" title="Reset font size" class="px-1.5 py-0.5 text-[10px] text-slate-500 hover:text-slate-800 border-l border-slate-300 ml-0.5">
                            Reset
                        </button>
                    </div>
                </div>

                <!-- Export Actions -->
                <div class="flex flex-wrap items-center gap-2">
                    <button onclick="copyAffidavitText()" class="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition flex items-center gap-1.5 border border-slate-300" title="Copy to clipboard">
                        <i data-lucide="copy" class="w-4 h-4"></i>
                        Copy Text
                    </button>
                    
                    <button onclick="window.print()" class="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition flex items-center gap-1.5 border border-slate-300" title="Print / PDF">
                        <i data-lucide="printer" class="w-4 h-4"></i>
                        Print / PDF
                    </button>

                    <button onclick="generateWordDoc()" class="px-4 py-2 text-xs font-semibold text-white bg-legal-600 hover:bg-legal-700 active:bg-legal-800 rounded-lg shadow transition flex items-center gap-2">
                        <i data-lucide="download" class="w-4 h-4 text-amber-400"></i>
                        Generate Word (.docx)
                    </button>
                </div>
            </div>

            <!-- Document Sheet Viewport -->
            <div class="print-container bg-slate-200 p-2 sm:p-6 rounded-2xl border border-slate-300 shadow-inner overflow-x-auto flex justify-center">
                
                <!-- The Virtual Paper Sheet in Bookman Font -->
                <div id="paperSheet" class="paper-preview font-bookman-style bg-white w-full max-w-[720px] min-h-[800px] p-8 sm:p-14 shadow-2xl rounded-sm border border-slate-300 text-slate-900 leading-relaxed flex flex-col justify-between select-text">
                    
                    <div>
                        <!-- Document Heading -->
                        <div class="text-center space-y-2 mb-8">
                            <h2 class="font-bold text-lg sm:text-xl text-slate-900 tracking-wide uppercase border-b-2 border-slate-900 pb-1.5 inline-block">
                                AFFIDAVIT FOR CHANGE OF NAME
                            </h2>
                            <p class="text-xs font-semibold tracking-wider text-slate-700 uppercase">
                                (For Publication in the Maharashtra Government Gazette)
                            </p>
                        </div>

                        <!-- Main Affidavit Statements -->
                        <div class="space-y-4 text-justify text-slate-900 leading-relaxed">
                            <p>
                                I, <strong class="uppercase font-bold" id="pv-newNameHeading">SHANTA VITTAL TIMMANNAVAR</strong>, 
                                AGED <strong class="uppercase font-bold" id="pv-age">51 YEARS</strong>, 
                                RESIDING AT <strong class="uppercase font-bold" id="pv-fullAddress">KHANKHA GALLI UDGIR, DIST LATUR, MAHARASHTRA 413517</strong>, 
                                do hereby solemnly affirm and state on oath as under:
                            </p>

                            <ol class="list-decimal list-outside pl-5 space-y-3">
                                <li>
                                    That my old name was 
                                    <strong class="uppercase font-bold" id="pv-oldName">SALAMA MODIN MULLA</strong> 
                                    as recorded in my legal records and identity documents.
                                </li>
                                <li>
                                    That I have changed my name from 
                                    <strong class="uppercase font-bold" id="pv-oldName2">SALAMA MODIN MULLA</strong> 
                                    to 
                                    <strong class="uppercase font-bold" id="pv-newName">SHANTA VITTAL TIMMANNAVAR</strong> 
                                    for all intents and purposes.
                                </li>
                                <li>
                                    That from now onwards, I shall at all times hereafter in all records, deeds, writings, proceedings, and dealings be known, called, and designated by my new name 
                                    <strong class="uppercase font-bold" id="pv-newName2">SHANTA VITTAL TIMMANNAVAR</strong>.
                                </li>
                                <li>
                                    That I am executing this Affidavit to declare my change of name and to submit it for publication in the official Maharashtra Government Gazette.
                                </li>
                            </ol>
                        </div>

                        <!-- Single Date, Place & Signature Block -->
                        <div class="mt-12 pt-4 flex flex-col space-y-8 font-bookman-style">
                            <div>
                                Solemnly affirmed at <strong class="uppercase" id="pv-place">UDGIR, DIST. LATUR</strong><br>
                                On this <strong id="pv-day">30</strong> day of <strong id="pv-month">October</strong> <strong id="pv-year">2026</strong>.
                            </div>

                            <div class="flex justify-end items-end pt-10">
                                <div class="text-right border-t border-slate-800 pt-2 min-w-[220px]">
                                    <p class="font-bold uppercase text-slate-900" id="pv-sigNewName">SHANTA VITTAL TIMMANNAVAR</p>
                                    <p class="text-xs text-slate-700">(DEPONENT)</p>
                                    <p class="text-xs text-slate-600 italic mt-0.5">Old Name: <span id="pv-sigOldName">SALAMA MODIN MULLA</span></p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </section>

    </main>

    <!-- Footer -->
    <footer class="bg-white border-t border-slate-200 py-4 no-print text-center text-xs text-slate-500">
        <p>Maharashtra Gazette Name Change Generator</p>
    </footer>

    <!-- JavaScript Application Logic -->
    <script>
        let currentFontSize = 14;

        document.addEventListener('DOMContentLoaded', () => {
            if (window.lucide) {
                lucide.createIcons();
            }
            updatePreview();
        });

        // Font Size Controllers
        function adjustFontSize(delta) {
            currentFontSize = Math.min(22, Math.max(11, currentFontSize + delta));
            applyFontSize();
        }

        function resetFontSize() {
            currentFontSize = 14;
            applyFontSize();
        }

        function applyFontSize() {
            document.documentElement.style.setProperty('--doc-font-size', `${currentFontSize}px`);
            const display = document.getElementById('fontSizeDisplay');
            if (display) {
                display.textContent = `${currentFontSize}px`;
            }
        }

        // Live Preview Updater Function
        function updatePreview() {
            const oldName = (document.getElementById('oldName').value || 'SALAMA MODIN MULLA').trim().toUpperCase();
            const newName = (document.getElementById('newName').value || 'SHANTA VITTAL TIMMANNAVAR').trim().toUpperCase();
            const age = (document.getElementById('age').value || '51 YEARS').trim().toUpperCase();
            const address = (document.getElementById('address').value || 'KHANKHA GALLI UDGIR, DIST LATUR, MAHARASHTRA 413517').trim().toUpperCase();
            const place = (document.getElementById('executionPlace').value || 'UDGIR, DIST. LATUR').trim().toUpperCase();
            
            const day = document.getElementById('execDay').value.trim() || '30';
            const month = document.getElementById('execMonth').value.trim() || 'October';
            const year = document.getElementById('execYear').value.trim() || '2026';

            // Update DOM element previews
            document.getElementById('pv-newNameHeading').textContent = newName;
            document.getElementById('pv-age').textContent = age;
            document.getElementById('pv-fullAddress').textContent = address;
            document.getElementById('pv-oldName').textContent = oldName;
            document.getElementById('pv-oldName2').textContent = oldName;
            document.getElementById('pv-newName').textContent = newName;
            document.getElementById('pv-newName2').textContent = newName;
            
            document.getElementById('pv-place').textContent = place;
            document.getElementById('pv-day').textContent = day;
            document.getElementById('pv-month').textContent = month;
            document.getElementById('pv-year').textContent = year;

            document.getElementById('pv-sigNewName').textContent = newName;
            document.getElementById('pv-sigOldName').textContent = oldName;
        }

        function autofillSampleData() {
            document.getElementById('oldName').value = 'SALAMA MODIN MULLA';
            document.getElementById('newName').value = 'SHANTA VITTAL TIMMANNAVAR';
            document.getElementById('age').value = '51 YEARS';
            document.getElementById('address').value = 'KHANKHA GALLI UDGIR, DIST LATUR, MAHARASHTRA 413517';
            document.getElementById('executionPlace').value = 'UDGIR, DIST. LATUR';
            document.getElementById('execDay').value = '30';
            document.getElementById('execMonth').value = 'October';
            document.getElementById('execYear').value = '2026';

            updatePreview();
            showToast('Form reset to default values', 'info');
        }

        // Copy Plain Text Affidavit
        function copyAffidavitText() {
            const oldName = document.getElementById('oldName').value.toUpperCase();
            const newName = document.getElementById('newName').value.toUpperCase();
            const age = document.getElementById('age').value.toUpperCase();
            const address = document.getElementById('address').value.toUpperCase();
            const place = document.getElementById('executionPlace').value.toUpperCase();
            const day = document.getElementById('execDay').value;
            const month = document.getElementById('execMonth').value;
            const year = document.getElementById('execYear').value;

            const text = `AFFIDAVIT FOR CHANGE OF NAME
(For Publication in the Maharashtra Government Gazette)

I, ${newName}, AGED ${age}, RESIDING AT ${address}, do hereby solemnly affirm and state on oath as under:

1. That my old name was ${oldName} as recorded in my legal records and identity documents.
2. That I have changed my name from ${oldName} to ${newName} for all intents and purposes.
3. That from now onwards, I shall at all times hereafter in all records, deeds, writings, proceedings, and dealings be known, called, and designated by my new name ${newName}.
4. That I am executing this Affidavit to declare my change of name and to submit it for publication in the official Maharashtra Government Gazette.

Solemnly affirmed at ${place}
On this ${day} day of ${month} ${year}.

____________________________
${newName}
(DEPONENT)
(Old Name: ${oldName})`;

            if (navigator.clipboard && window.isSecureContext) {
                navigator.clipboard.writeText(text).then(() => {
                    showToast('Affidavit text copied!');
                }).catch(() => fallbackCopyText(text));
            } else {
                fallbackCopyText(text);
            }
        }

        function fallbackCopyText(text) {
            const textArea = document.createElement("textarea");
            textArea.value = text;
            textArea.style.position = "fixed";
            document.body.appendChild(textArea);
            textArea.focus();
            textArea.select();
            try {
                document.execCommand('copy');
                showToast('Affidavit text copied!');
            } catch (err) {
                showToast('Failed to copy text', 'error');
            }
            document.body.removeChild(textArea);
        }

        function showToast(message, type = 'success') {
            const toast = document.getElementById('toast');
            const toastMsg = document.getElementById('toast-message');
            const toastIcon = document.getElementById('toast-icon');

            toastMsg.textContent = message;
            
            if (type === 'error') {
                toastIcon.setAttribute('data-lucide', 'alert-circle');
                toastIcon.className = "w-5 h-5 text-red-400";
            } else if (type === 'info') {
                toastIcon.setAttribute('data-lucide', 'info');
                toastIcon.className = "w-5 h-5 text-sky-400";
            } else {
                toastIcon.setAttribute('data-lucide', 'check-circle');
                toastIcon.className = "w-5 h-5 text-emerald-400";
            }
            if (window.lucide) lucide.createIcons();

            toast.classList.remove('translate-y-20', 'opacity-0');
            toast.classList.add('translate-y-0', 'opacity-100');

            setTimeout(() => {
                toast.classList.remove('translate-y-0', 'opacity-100');
                toast.classList.add('translate-y-20', 'opacity-0');
            }, 3000);
        }

        // Client-side Word Document Generation formatted in Bookman Old Style font
        function generateWordDoc() {
            try {
                const oldName = (document.getElementById('oldName').value || 'SALAMA MODIN MULLA').toUpperCase();
                const newName = (document.getElementById('newName').value || 'SHANTA VITTAL TIMMANNAVAR').toUpperCase();
                const age = (document.getElementById('age').value || '51 YEARS').toUpperCase();
                const address = (document.getElementById('address').value || 'KHANKHA GALLI UDGIR, DIST LATUR, MAHARASHTRA 413517').toUpperCase();
                const place = (document.getElementById('executionPlace').value || 'UDGIR, DIST. LATUR').toUpperCase();
                const day = document.getElementById('execDay').value || '30';
                const month = document.getElementById('execMonth').value || 'October';
                const year = document.getElementById('execYear').value || '2026';

                const docxLib = window.docx;
                if (!docxLib) {
                    showToast('Docx library not loaded', 'error');
                    return;
                }

                const { Document, Paragraph, TextRun, AlignmentType } = docxLib;
                const FONT_BOOKMAN = "Bookman Old Style";

                // Scale Word export docx point sizes relative to user-adjusted screen font
                const basePt = Math.round(currentFontSize * 1.7);

                const doc = new Document({
                    sections: [{
                        properties: {
                            page: {
                                margin: {
                                    top: 1440, // 1 inch
                                    right: 1440,
                                    bottom: 1440,
                                    left: 1440
                                }
                            }
                        },
                        children: [
                            new Paragraph({
                                alignment: AlignmentType.CENTER,
                                spacing: { after: 100 },
                                children: [
                                    new TextRun({
                                        text: "AFFIDAVIT FOR CHANGE OF NAME",
                                        bold: true,
                                        size: basePt + 4,
                                        font: FONT_BOOKMAN
                                    })
                                ]
                            }),
                            new Paragraph({
                                alignment: AlignmentType.CENTER,
                                spacing: { after: 400 },
                                children: [
                                    new TextRun({
                                        text: "(For Publication in the Maharashtra Government Gazette)",
                                        italics: true,
                                        size: basePt - 4,
                                        font: FONT_BOOKMAN
                                    })
                                ]
                            }),

                            // Opening paragraph
                            new Paragraph({
                                alignment: AlignmentType.JUSTIFY,
                                spacing: { after: 200, line: 360 },
                                children: [
                                    new TextRun({ text: "I, ", font: FONT_BOOKMAN, size: basePt }),
                                    new TextRun({ text: `${newName}`, bold: true, font: FONT_BOOKMAN, size: basePt }),
                                    new TextRun({ text: `, AGED `, font: FONT_BOOKMAN, size: basePt }),
                                    new TextRun({ text: `${age}`, bold: true, font: FONT_BOOKMAN, size: basePt }),
                                    new TextRun({ text: `, RESIDING AT `, font: FONT_BOOKMAN, size: basePt }),
                                    new TextRun({ text: `${address}`, bold: true, font: FONT_BOOKMAN, size: basePt }),
                                    new TextRun({ text: `, do hereby solemnly affirm and state on oath as under:`, font: FONT_BOOKMAN, size: basePt })
                                ]
                            }),

                            // Point 1
                            new Paragraph({
                                alignment: AlignmentType.JUSTIFY,
                                spacing: { after: 150, line: 360 },
                                children: [
                                    new TextRun({ text: "1.  That my old name was ", font: FONT_BOOKMAN, size: basePt }),
                                    new TextRun({ text: `${oldName}`, bold: true, font: FONT_BOOKMAN, size: basePt }),
                                    new TextRun({ text: " as recorded in my legal records and identity documents.", font: FONT_BOOKMAN, size: basePt })
                                ]
                            }),

                            // Point 2
                            new Paragraph({
                                alignment: AlignmentType.JUSTIFY,
                                spacing: { after: 150, line: 360 },
                                children: [
                                    new TextRun({ text: "2.  That I have changed my name from ", font: FONT_BOOKMAN, size: basePt }),
                                    new TextRun({ text: `${oldName}`, bold: true, font: FONT_BOOKMAN, size: basePt }),
                                    new TextRun({ text: " to ", font: FONT_BOOKMAN, size: basePt }),
                                    new TextRun({ text: `${newName}`, bold: true, font: FONT_BOOKMAN, size: basePt }),
                                    new TextRun({ text: " for all intents and purposes.", font: FONT_BOOKMAN, size: basePt })
                                ]
                            }),

                            // Point 3
                            new Paragraph({
                                alignment: AlignmentType.JUSTIFY,
                                spacing: { after: 150, line: 360 },
                                children: [
                                    new TextRun({ text: "3.  That from now onwards, I shall at all times hereafter in all records, deeds, writings, proceedings, and dealings be known, called, and designated by my new name ", font: FONT_BOOKMAN, size: basePt }),
                                    new TextRun({ text: `${newName}`, bold: true, font: FONT_BOOKMAN, size: basePt }),
                                    new TextRun({ text: ".", font: FONT_BOOKMAN, size: basePt })
                                ]
                            }),

                            // Point 4
                            new Paragraph({
                                alignment: AlignmentType.JUSTIFY,
                                spacing: { after: 300, line: 360 },
                                children: [
                                    new TextRun({ text: "4.  That I am executing this Affidavit to declare my change of name and to submit it for publication in the official Maharashtra Government Gazette.", font: FONT_BOOKMAN, size: basePt })
                                ]
                            }),

                            // Execution line
                            new Paragraph({
                                spacing: { after: 500 },
                                children: [
                                    new TextRun({ text: `Solemnly affirmed at ${place}\nOn this ${day} day of ${month} ${year}.`, font: FONT_BOOKMAN, size: basePt })
                                ]
                            }),

                            // Right-aligned Deponent Signature Block
                            new Paragraph({
                                alignment: AlignmentType.RIGHT,
                                spacing: { before: 800 },
                                children: [
                                    new TextRun({ text: "____________________________", font: FONT_BOOKMAN, size: basePt - 2 })
                                ]
                            }),
                            new Paragraph({
                                alignment: AlignmentType.RIGHT,
                                children: [
                                    new TextRun({ text: `${newName}`, bold: true, font: FONT_BOOKMAN, size: basePt - 2 })
                                ]
                            }),
                            new Paragraph({
                                alignment: AlignmentType.RIGHT,
                                children: [
                                    new TextRun({ text: "(DEPONENT)", bold: true, font: FONT_BOOKMAN, size: basePt - 4 })
                                ]
                            }),
                            new Paragraph({
                                alignment: AlignmentType.RIGHT,
                                children: [
                                    new TextRun({ text: `Old Name: ${oldName}`, italics: true, font: FONT_BOOKMAN, size: basePt - 4 })
                                ]
                            })
                        ]
                    }]
                });

                docxLib.Packer.toBlob(doc).then((blob) => {
                    saveAs(blob, `Maharashtra_Gazette_Affidavit_${newName.replace(/\s+/g, '_')}.docx`);
                    showToast('Word Document downloaded in Bookman font!');
                });

            } catch (err) {
                console.error(err);
                showToast('Failed to generate Word document', 'error');
            }
        }
    </script>
</body>
</html>