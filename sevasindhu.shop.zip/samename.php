<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>One and the Same Person Affidavit Generator</title>
  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Lucide Icons -->
  <script src="https://unpkg.com/lucide@latest"></script>

  <style>
    :root {
      --affidavit-font-size: 16px;
    }

    body {
      font-family: 'Inter', sans-serif;
    }

    /* Legal Document Typography - Bookman Old Style */
    .legal-font {
      font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif;
    }

    .affidavit-title {
      font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif;
    }

    /* Page container styling on screen */
    .page-sheet {
      width: 210mm;
      min-height: 297mm;
      height: 297mm;
      max-height: 297mm;
      background: #ffffff;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
      position: relative;
      box-sizing: border-box;
      overflow: hidden;
      font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif;
      font-size: var(--affidavit-font-size);
    }

    /* Strict A4 Print Specific Styling */
    @page {
      size: A4 portrait;
      margin: 0;
    }

    @media print {
      html, body {
        width: 210mm !important;
        height: 297mm !important;
        margin: 0 !important;
        padding: 0 !important;
        background: #ffffff !important;
        color: #000000 !important;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
        font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif !important;
      }

      .no-print {
        display: none !important;
      }

      main {
        padding: 0 !important;
        margin: 0 !important;
        max-width: 100% !important;
      }

      #preview-container {
        border: none !important;
        box-shadow: none !important;
        margin: 0 !important;
        padding: 0 !important;
        background: transparent !important;
        width: 210mm !important;
        display: block !important;
      }

      .page-sheet {
        box-shadow: none !important;
        border: none !important;
        width: 210mm !important;
        height: 297mm !important;
        max-height: 297mm !important;
        min-height: 297mm !important;
        margin: 0 !important;
        padding: 14mm 18mm !important;
        box-sizing: border-box !important;
        overflow: hidden !important;
        page-break-inside: avoid !important;
        break-inside: avoid !important;
        page-break-after: avoid !important;
        break-after: avoid !important;
        font-size: var(--affidavit-font-size) !important;
        font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif !important;
        transform: scale(var(--doc-scale, 0.96));
        transform-origin: top center;
        zoom: var(--doc-scale, 0.96);
      }

      .keep-together {
        page-break-inside: avoid !important;
        break-inside: avoid !important;
      }
    }
  </style>
</head>
<body class="bg-slate-100 min-h-screen text-slate-800 antialiased selection:bg-amber-100 selection:text-amber-900">

  <!-- Header Navigation -->
  <header class="no-print bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-30 shadow-md">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3">
      <div class="flex items-center gap-3">
        <div class="p-2 bg-amber-500 text-slate-950 rounded-lg shadow-sm">
          <i data-lucide="scale" class="w-6 h-6"></i>
        </div>
        <div>
          <h1 class="text-base sm:text-lg font-bold tracking-tight">One and the Same Person Affidavit</h1>
          <p class="text-xs text-slate-400">Name Discrepancy & Record Rectification Format</p>
        </div>
      </div>
      <div class="flex items-center gap-2">
        <button type="button" onclick="scrollToPreview()" class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition">
          <i data-lucide="eye" class="w-4 h-4"></i>
          <span>View Preview</span>
        </button>
        <button type="button" onclick="handlePrint()" class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-medium shadow-sm transition active:scale-95">
          <i data-lucide="printer" class="w-4 h-4"></i>
          <span>Print / Save PDF</span>
        </button>
      </div>
    </div>
  </header>

  <main class="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-8">

    <!-- DATA ENTRY FORM SECTION -->
    <section class="no-print bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      <div class="bg-slate-50 border-b border-slate-200 px-6 py-4 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 class="text-base font-bold text-slate-900 flex items-center gap-2">
            <i data-lucide="file-pen" class="w-4 h-4 text-amber-600"></i>
            Data Entry Particulars
          </h2>
          <p class="text-xs text-slate-500 mt-0.5">Edit deponent and record discrepancy parameters to update the live legal preview.</p>
        </div>
        <div class="flex items-center gap-2">
          <button type="button" onclick="resetToDefaultData()" class="inline-flex items-center gap-1 px-3 py-1.5 text-xs text-slate-600 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg transition font-medium">
            <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
            Reset Initial Data
          </button>
        </div>
      </div>

      <form id="affidavit-form" class="p-6 space-y-6" onsubmit="event.preventDefault(); updateAffidavit();">

        <!-- Deponent Particulars -->
        <div>
          <h3 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <i data-lucide="user" class="w-4 h-4"></i> 1. Deponent Personal Details
          </h3>
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Deponent Full Name</label>
              <input type="text" id="deponentName" value="MUMTAJ IBRAHIM SAIKH" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white uppercase tracking-wide">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Age</label>
              <input type="text" id="deponentAge" value="61 Years" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Occupation</label>
              <input type="text" id="deponentOccupation" value="House Wife" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div class="sm:col-span-2 md:col-span-3">
              <label class="block text-xs font-semibold text-slate-700 mb-1">Residential Address</label>
              <textarea id="deponentAddress" rows="2" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">Dolphin 435, Pant Nagar, Balekundri B K, Belagavi 591103</textarea>
            </div>
          </div>
        </div>

        <hr class="border-slate-200">

        <!-- Name Variations & Record Source -->
        <div>
          <h3 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <i data-lucide="id-card" class="w-4 h-4"></i> 2. Record Title, Name Variations & Submission Authority
          </h3>
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Name in Aadhaar / PAN Card</label>
              <input type="text" id="cardName" value="MUMTAJ SHAIKH" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white uppercase font-bold text-amber-900">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Official Record Type / Name</label>
              <input type="text" id="recordType" value="Navy Records" placeholder="e.g. Navy Records, Service Records, School LC" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white font-semibold text-emerald-800">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Name in Official Record</label>
              <input type="text" id="recordName" value="MUMTAJ IBRAHIM SHAIKH" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white uppercase font-bold text-slate-900">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Submitting Authority / Office</label>
              <input type="text" id="submitAuthority" value="RECORD OFFICE NAVPEN" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white uppercase font-bold text-blue-900">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Execution Place</label>
              <input type="text" id="executionPlace" value="Belagavi" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Affidavit Date</label>
              <input type="text" id="affidavitDate" value="04/09/2026" placeholder="DD/MM/YYYY" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>
          </div>
        </div>

        <hr class="border-slate-200">

        <!-- Controls: Font Size, Stamp Space, Page Scale -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <!-- Font Size Adjustment (Increase / Decrease) -->
          <div class="bg-indigo-50/60 p-4 rounded-xl border border-indigo-200/70 flex flex-col justify-between gap-3">
            <div>
              <label class="text-xs font-semibold text-slate-800 flex items-center justify-between">
                <span class="flex items-center gap-1.5"><i data-lucide="type" class="w-4 h-4 text-indigo-600"></i> Text Font Size:</span>
                <span id="fontSizeDisplay" class="text-indigo-800 font-bold font-mono text-sm bg-white px-2 py-0.5 rounded border border-indigo-200">16 px</span>
              </label>
              <p class="text-[11px] text-slate-500 mt-1">Adjust font size up or down to fill A4 sheet perfectly.</p>
            </div>
            <div class="flex items-center gap-2">
              <button type="button" onclick="adjustFontSize(-1)" class="flex-1 py-1.5 px-3 bg-white border border-indigo-300 rounded-lg hover:bg-indigo-100 text-indigo-950 font-bold text-sm transition flex items-center justify-center gap-1 active:scale-95 shadow-sm">
                <i data-lucide="minus" class="w-3.5 h-3.5"></i> A-
              </button>
              <button type="button" onclick="setFontSize(16)" class="py-1.5 px-2 text-[11px] bg-indigo-100 border border-indigo-300 rounded-lg hover:bg-indigo-200 text-indigo-900 font-semibold transition">
                Reset
              </button>
              <button type="button" onclick="adjustFontSize(1)" class="flex-1 py-1.5 px-3 bg-white border border-indigo-300 rounded-lg hover:bg-indigo-100 text-indigo-950 font-bold text-sm transition flex items-center justify-center gap-1 active:scale-95 shadow-sm">
                <i data-lucide="plus" class="w-3.5 h-3.5"></i> A+
              </button>
            </div>
          </div>

          <!-- Non-Judicial Stamp Reserve -->
          <div class="bg-amber-50/50 p-4 rounded-xl border border-amber-200/60 flex flex-col justify-between gap-3">
            <div>
              <label for="topMarginSlider" class="text-xs font-semibold text-slate-800 flex items-center justify-between">
                <span class="flex items-center gap-1.5"><i data-lucide="file-text" class="w-4 h-4 text-amber-600"></i> Stamp Space:</span>
                <span id="topMarginValue" class="text-amber-800 font-mono text-xs bg-white px-1.5 py-0.5 rounded border border-amber-200">0 mm</span>
              </label>
              <p class="text-[11px] text-slate-500 mt-1">Set 70mm - 85mm for physical e-stamp papers.</p>
            </div>
            <div class="flex items-center gap-2">
              <input type="range" id="topMarginSlider" min="0" max="90" step="5" value="0" oninput="updateTopMargin(this.value)" class="w-full accent-amber-600 cursor-pointer">
              <button type="button" onclick="setStampPreset(0)" class="px-2 py-1 text-[11px] bg-white border border-slate-300 rounded hover:bg-slate-100 whitespace-nowrap">0mm</button>
              <button type="button" onclick="setStampPreset(75)" class="px-2 py-1 text-[11px] bg-amber-100 border border-amber-300 text-amber-900 rounded hover:bg-amber-200 font-medium whitespace-nowrap">75mm</button>
            </div>
          </div>

          <!-- Page Scale Slider -->
          <div class="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-col justify-between gap-3">
            <div>
              <label for="scaleSlider" class="text-xs font-semibold text-slate-800 flex items-center justify-between">
                <span class="flex items-center gap-1.5"><i data-lucide="maximize-2" class="w-4 h-4 text-slate-600"></i> Page Scale:</span>
                <span id="scaleValue" class="text-slate-800 font-bold font-mono text-xs bg-white px-1.5 py-0.5 rounded border border-slate-300">96%</span>
              </label>
              <p class="text-[11px] text-slate-500 mt-1">Locks layout boundary strictly within standard A4.</p>
            </div>
            <div class="flex items-center gap-2">
              <input type="range" id="scaleSlider" min="85" max="105" step="1" value="96" oninput="updateDocumentScale(this.value)" class="w-full accent-slate-700 cursor-pointer">
              <button type="button" onclick="setDocumentScale(96)" class="px-2 py-1 text-[11px] bg-slate-200 border border-slate-300 text-slate-900 font-bold rounded hover:bg-slate-300">96%</button>
              <button type="button" onclick="setDocumentScale(100)" class="px-2 py-1 text-[11px] bg-white border border-slate-300 rounded hover:bg-slate-100">100%</button>
            </div>
          </div>
        </div>

        <div class="flex flex-wrap items-center justify-end gap-3 pt-2">
          <button type="button" onclick="updateAffidavit()" class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-900 text-white font-medium text-xs hover:bg-slate-800 shadow transition">
            <i data-lucide="refresh-cw" class="w-4 h-4"></i>
            Refresh Document Preview
          </button>
          <button type="button" onclick="handlePrint()" class="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition transform active:scale-95">
            <i data-lucide="printer" class="w-4 h-4"></i>
            Print / Save to PDF
          </button>
        </div>
      </form>
    </section>

    <!-- LIVE PREVIEW SECTION -->
    <section class="space-y-4">
      <div class="no-print flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-slate-900 flex items-center gap-2">
            <i data-lucide="file-badge" class="w-4 h-4 text-amber-600"></i>
            Document Preview (Exact A4 Single-Sheet Output)
          </h2>
          <p class="text-xs text-slate-500">Bookman Old Style • Dynamic Font Scale & Zero Extra Space</p>
        </div>
        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
          <span class="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
          Exact A4 Fitted
        </span>
      </div>

      <div id="preview-container" class="bg-slate-300/70 p-4 sm:p-8 rounded-2xl border border-slate-300 flex flex-col items-center gap-8 shadow-inner overflow-x-auto">
        
        <!-- A4 Page Sheet with dynamic font sizing -->
        <div id="affidavit-sheet" class="page-sheet rounded-sm p-8 sm:p-12 md:p-14 legal-font leading-normal block">
          
          <!-- Stamp Space Spacer -->
          <div id="stamp-space" class="transition-all duration-200" style="height: 0mm;"></div>

          <div class="keep-together">
            <!-- Header Title -->
            <div class="text-center mb-3">
              <h1 class="affidavit-title text-[1.4em] font-bold underline uppercase tracking-wider">AFFIDAVIT</h1>
            </div>

            <!-- Introductory Paragraph -->
            <div class="text-justify mb-3 leading-normal">
              HEREIN, I <span id="out-deponentName" class="font-bold underline uppercase">MUMTAJ IBRAHIM SAIKH</span>, Age: <span id="out-deponentAge" class="font-semibold">61 Years</span>, Occ: <span id="out-deponentOccupation" class="font-semibold">House Wife</span>, R/O <span id="out-deponentAddress" class="font-medium">Dolphin 435, Pant Nagar, Balekundri B K, Belagavi 591103</span>, today at <span id="out-placeIntro" class="font-semibold">Belagavi</span>, do hereby state on solemn affirmation and make the following affidavit.
            </div>

            <!-- Numbered Points -->
            <div class="space-y-2.5 text-justify my-3 leading-normal">
              <div class="flex items-start">
                <span class="font-bold min-w-[24px]">1.</span>
                <span>I state that I am residing at above said Address.</span>
              </div>

              <div class="flex items-start">
                <span class="font-bold min-w-[24px]">2.</span>
                <div>
                  I state that my Name is mentioned in Aadhaar Card and Pan Card as <strong id="out-cardName" class="uppercase">MUMTAJ SHAIKH</strong> whereas my name is mentioned in <strong id="out-recordType" class="font-bold">Navy Records</strong> as <strong id="out-recordName" class="uppercase">MUMTAJ IBRAHIM SHAIKH</strong> both the above mentioned names are belongs to one and the same person that is myself.
                </div>
              </div>

              <div class="flex items-start">
                <span class="font-bold min-w-[24px]">3.</span>
                <div>
                  Further I state that my Name and date of birth is mentioned in Aadhaar Card and Pan Card as <strong id="out-cardName2" class="uppercase">MUMTAJ SHAIKH</strong> whereas my name is mentioned in <strong id="out-recordType2" class="font-bold">Navy Records</strong> as <strong id="out-recordName2" class="uppercase">MUMTAJ IBRAHIM SHAIKH</strong> both the above mentioned names are belongs to one and the same person that is myself.
                </div>
              </div>

              <div class="flex items-start">
                <span class="font-bold min-w-[24px]">4.</span>
                <div>
                  I am swearing to this affidavit to produce before the <strong id="out-submitAuthority" class="uppercase">RECORD OFFICE NAVPEN</strong> to show that <strong id="out-cardName3" class="uppercase">MUMTAJ SHAIKH</strong> and <strong id="out-deponentName2" class="uppercase">MUMTAJ IBRAHIM SAIKH</strong> both the above mentioned names are belong in to one and same person that is myself.
                </div>
              </div>
            </div>

            <!-- Verification Clause -->
            <div class="text-justify mt-3 mb-5 leading-normal">
              The contents of the above affidavit is read over by me and same is true and correct to the best of my knowledge, information and belief.
            </div>

            <!-- Signature Block directly under end of text -->
            <div class="mt-5 pt-1">
              <div class="flex justify-between items-end">
                <div class="space-y-1 font-semibold text-[0.95em]">
                  <div>Place: <span id="out-placeFooter">Belagavi</span></div>
                  <div>Date: <span id="out-dateFooter">04/09/2026</span></div>
                </div>

                <div class="text-right">
                  <div class="h-6"></div>
                  <div class="font-bold uppercase text-[0.95em] border-t border-black pt-1 inline-block min-w-[160px] text-center">
                    Deponent.<br>
                    <span id="out-deponentSignature" class="text-xs font-normal"></span>
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>

  </main>

  <footer class="no-print border-t border-slate-200 bg-white py-6 mt-12 text-center text-xs text-slate-500">
    <p>One and the Same Person Affidavit Generator • Configurable Font Size</p>
  </footer>

  <script>
    let currentFontSize = 16; // default font size in pixels

    const defaultData = {
      deponentName: "MUMTAJ IBRAHIM SAIKH",
      deponentAge: "61 Years",
      deponentOccupation: "House Wife",
      deponentAddress: "Dolphin 435, Pant Nagar, Balekundri B K, Belagavi 591103",
      cardName: "MUMTAJ SHAIKH",
      recordType: "Navy Records",
      recordName: "MUMTAJ IBRAHIM SHAIKH",
      submitAuthority: "RECORD OFFICE NAVPEN",
      executionPlace: "Belagavi",
      affidavitDate: "04/09/2026"
    };

    // Font size controls
    function setFontSize(size) {
      currentFontSize = Math.min(22, Math.max(12, parseInt(size) || 16));
      document.documentElement.style.setProperty('--affidavit-font-size', `${currentFontSize}px`);
      
      const displayElem = document.getElementById('fontSizeDisplay');
      if (displayElem) {
        displayElem.innerText = `${currentFontSize} px`;
      }
    }

    function adjustFontSize(delta) {
      setFontSize(currentFontSize + delta);
    }

    function updateAffidavit() {
      const getVal = (id) => (document.getElementById(id) ? document.getElementById(id).value.trim() : '');

      const name = getVal('deponentName') || defaultData.deponentName;
      const age = getVal('deponentAge') || defaultData.deponentAge;
      const occ = getVal('deponentOccupation') || defaultData.deponentOccupation;
      const addr = getVal('deponentAddress') || defaultData.deponentAddress;

      const card = getVal('cardName') || defaultData.cardName;
      const recordType = getVal('recordType') || defaultData.recordType;
      const record = getVal('recordName') || defaultData.recordName;
      const auth = getVal('submitAuthority') || defaultData.submitAuthority;

      const place = getVal('executionPlace') || defaultData.executionPlace;
      const date = getVal('affidavitDate') || defaultData.affidavitDate;

      // Outputs
      document.getElementById('out-deponentName').innerText = name;
      document.getElementById('out-deponentName2').innerText = name;
      document.getElementById('out-deponentAge').innerText = age;
      document.getElementById('out-deponentOccupation').innerText = occ;
      document.getElementById('out-deponentAddress').innerText = addr;

      document.getElementById('out-cardName').innerText = card;
      document.getElementById('out-cardName2').innerText = card;
      document.getElementById('out-cardName3').innerText = card;

      document.getElementById('out-recordType').innerText = recordType;
      document.getElementById('out-recordType2').innerText = recordType;

      document.getElementById('out-recordName').innerText = record;
      document.getElementById('out-recordName2').innerText = record;

      document.getElementById('out-submitAuthority').innerText = auth;

      document.getElementById('out-placeIntro').innerText = place;
      document.getElementById('out-placeFooter').innerText = place;
      document.getElementById('out-dateFooter').innerText = date;
    }

    function updateTopMargin(val) {
      const spacer = document.getElementById('stamp-space');
      const text = document.getElementById('topMarginValue');
      const numericVal = Math.min(90, Math.max(0, parseInt(val) || 0));

      if (spacer) spacer.style.height = `${numericVal}mm`;
      if (text) text.innerText = `${numericVal} mm`;
    }

    function setStampPreset(val) {
      const slider = document.getElementById('topMarginSlider');
      if (slider) slider.value = val;
      updateTopMargin(val);
    }

    function updateDocumentScale(val) {
      const numericVal = parseInt(val) || 96;
      const ratio = numericVal / 100;
      document.documentElement.style.setProperty('--doc-scale', ratio);
      
      const scaleValueElem = document.getElementById('scaleValue');
      if (scaleValueElem) scaleValueElem.innerText = `${numericVal}%`;

      const sheet = document.getElementById('affidavit-sheet');
      if (sheet) {
        sheet.style.transform = `scale(${ratio})`;
        sheet.style.transformOrigin = 'top center';
      }
    }

    function setDocumentScale(val) {
      const slider = document.getElementById('scaleSlider');
      if (slider) slider.value = val;
      updateDocumentScale(val);
    }

    function resetToDefaultData() {
      Object.keys(defaultData).forEach(key => {
        const el = document.getElementById(key);
        if (el) el.value = defaultData[key];
      });

      setStampPreset(0);
      setDocumentScale(96);
      setFontSize(16);
      updateAffidavit();
    }

    function scrollToPreview() {
      document.getElementById('preview-container').scrollIntoView({ behavior: 'smooth' });
    }

    function handlePrint() {
      updateAffidavit();
      window.print();
    }

    document.addEventListener('DOMContentLoaded', () => {
      if (window.lucide) {
        lucide.createIcons();
      }

      setFontSize(16);
      updateAffidavit();
      updateDocumentScale(96);

      const inputIds = [
        'deponentName', 'deponentAge', 'deponentOccupation', 'deponentAddress',
        'cardName', 'recordType', 'recordName', 'submitAuthority', 'executionPlace', 'affidavitDate'
      ];

      inputIds.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
          element.addEventListener('input', updateAffidavit);
        }
      });
    });
  </script>
</body>
</html>