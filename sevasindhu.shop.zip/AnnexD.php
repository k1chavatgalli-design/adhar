<?php
// Initialize default data
$data = [
    'docNumber'      => 'ANNEXURE D',
    'declarantName'  => 'AISHWARYA LATTE',
    'relType'        => 'D/o',
    'relativeName'   => 'SHITAL LATTE',
    'address'        => '115, JAIN ONI, YARNAL, BELAGAVI, KARNATAKA-591221',
    'aadhaarNo'      => '[Aadhaar Redacted]',
    'priorName'      => 'AISHWARYA LATTE',
    'eventDate'      => '',
    'newSurname'     => 'DESAI',
    'fullName'       => 'AISHWARYA KIRANADADA DESAI',
    'verLocation'    => 'Belagavi',
    'verDate'        => date('Y-m-d')
];

// Handle POST submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($data as $key => $val) {
        if (isset($_POST[$key])) {
            $data[$key] = trim($_POST[$key]);
        }
    }
}

// Helper function for legal date format
function formatLegalDate($dateStr) {
    if (empty($dateStr)) {
        return '*****';
    }
    $timestamp = strtotime($dateStr);
    if (!$timestamp) {
        return htmlspecialchars($dateStr);
    }
    return date('jS \d\a\y \o\f F Y', $timestamp);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aadhaar Affidavit Generator - Single Page A4</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @media print {
            body {
                background-color: #ffffff !important;
                margin: 0 !important;
                padding: 0 !important;
            }
            .no-print {
                display: none !important;
            }
            .print-area {
                box-shadow: none !important;
                margin: 0 !important;
                width: 210mm !important;
                height: 297mm !important;
                max-height: 297mm !important;
                padding: 15mm 15mm 15mm 15mm !important;
                border: none !important;
                overflow: hidden !important;
                page-break-after: avoid !important;
                page-break-inside: avoid !important;
            }
            @page {
                size: A4 portrait;
                margin: 0;
            }
        }
        .a4-page {
            width: 210mm;
            height: 297mm;
            padding: 18mm 18mm 15mm 18mm;
            background: white;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            font-family: 'Times New Roman', Times, serif;
            box-sizing: border-box;
            overflow: hidden;
        }
    </style>
</head>
<body class="bg-slate-100 text-slate-800 font-sans min-h-screen">

    <!-- Header Navigation -->
    <header class="bg-slate-900 text-white shadow-md sticky top-0 z-50 no-print">
        <div class="max-w-7xl mx-auto px-4 py-3 flex justify-between items-center">
            <div class="flex items-center space-x-3">
                <svg class="w-7 h-7 text-blue-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                </svg>
                <h1 class="text-lg font-bold tracking-wide">Affidavit After Marriage Annexury D)</h1>
            </div>
            <button onclick="window.print()" class="bg-blue-600 hover:bg-blue-700 text-white font-medium px-4 py-2 rounded-lg shadow transition flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path>
                </svg>
                Print / Save PDF
            </button>
        </div>
    </header>

    <div class="max-w-7xl mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">

        <!-- Left Column: Data Entry Form -->
        <div class="lg:col-span-5 bg-white rounded-xl shadow-sm border border-slate-200 p-5 no-print h-fit">
            <h2 class="text-base font-bold text-slate-800 mb-3 border-b pb-2 flex items-center justify-between">
                <span>Data Entry Form</span>
                <span class="text-xs bg-blue-100 text-blue-800 font-semibold px-2 py-0.5 rounded">PHP POST</span>
            </h2>

            <form method="POST" action="" class="space-y-3">

                <div>
                    <label class="block text-xs font-semibold text-slate-600 uppercase mb-1">Top-Right Header Text</label>
                    <input type="text" name="docNumber" value="<?php echo htmlspecialchars($data['docNumber']); ?>" class="w-full border rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-600 uppercase mb-1">Declarant Name (Full)</label>
                    <input type="text" name="declarantName" value="<?php echo htmlspecialchars($data['declarantName']); ?>" class="w-full border rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
                </div>

                <div class="grid grid-cols-3 gap-2">
                    <div class="col-span-1">
                        <label class="block text-xs font-semibold text-slate-600 uppercase mb-1">Relation</label>
                        <select name="relType" class="w-full border rounded-lg px-2 py-1.5 text-sm bg-white focus:ring-2 focus:ring-blue-500 outline-none font-semibold text-blue-900">
                            <option value="D/o" <?php echo $data['relType'] === 'D/o' ? 'selected' : ''; ?>>D/o</option>
                            <option value="W/o" <?php echo $data['relType'] === 'W/o' ? 'selected' : ''; ?>>W/o</option>
                            <option value="C/o" <?php echo $data['relType'] === 'C/o' ? 'selected' : ''; ?>>C/o</option>
                        </select>
                    </div>
                    <div class="col-span-2">
                        <label class="block text-xs font-semibold text-slate-600 uppercase mb-1">Relative's Name</label>
                        <input type="text" name="relativeName" value="<?php echo htmlspecialchars($data['relativeName']); ?>" class="w-full border rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-600 uppercase mb-1">Residential Address</label>
                    <textarea name="address" rows="2" class="w-full border rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"><?php echo htmlspecialchars($data['address']); ?></textarea>
                </div>

                <div>
                    <label class="block text-xs font-semibold text-slate-600 uppercase mb-1">Aadhaar Number / Placeholder</label>
                    <input type="text" name="aadhaarNo" value="<?php echo htmlspecialchars($data['aadhaarNo']); ?>" class="w-full border rounded-lg px-3 py-1.5 text-sm font-mono focus:ring-2 focus:ring-blue-500 outline-none">
                </div>

                <div class="grid grid-cols-2 gap-2">
                    <div>
                        <label class="block text-xs font-semibold text-slate-600 uppercase mb-1">Prior Name</label>
                        <input type="text" name="priorName" value="<?php echo htmlspecialchars($data['priorName']); ?>" class="w-full border rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-600 uppercase mb-1">Marriage/Event Date</label>
                        <input type="date" name="eventDate" value="<?php echo htmlspecialchars($data['eventDate']); ?>" class="w-full border rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-2">
                    <div>
                        <label class="block text-xs font-semibold text-slate-600 uppercase mb-1">New Surname</label>
                        <input type="text" name="newSurname" value="<?php echo htmlspecialchars($data['newSurname']); ?>" class="w-full border rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-600 uppercase mb-1">New Full Name</label>
                        <input type="text" name="fullName" value="<?php echo htmlspecialchars($data['fullName']); ?>" class="w-full border rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-2 border-t pt-2">
                    <div>
                        <label class="block text-xs font-semibold text-slate-600 uppercase mb-1">Verification Place</label>
                        <input type="text" name="verLocation" value="<?php echo htmlspecialchars($data['verLocation']); ?>" class="w-full border rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
                    </div>
                    <div>
                        <label class="block text-xs font-semibold text-slate-600 uppercase mb-1">Verification Date</label>
                        <input type="date" name="verDate" value="<?php echo htmlspecialchars($data['verDate']); ?>" class="w-full border rounded-lg px-3 py-1.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none">
                    </div>
                </div>

                <div class="pt-2">
                    <button type="submit" class="w-full bg-slate-800 hover:bg-slate-900 text-white font-medium py-2 rounded-lg transition shadow text-sm">
                        Update Document Preview
                    </button>
                </div>
            </form>
        </div>

        <!-- Right Column: Printable Single-Page A4 -->
        <div class="lg:col-span-7 flex justify-center">
            <div class="a4-page print-area text-slate-900 leading-snug text-justify text-sm">

                <!-- Header Block: "ANNEXURE D" in Top-Right Corner, "AFFIDAVIT" centered below -->
                <div class="mb-6">
                    <div class="text-right font-bold text-sm tracking-wider uppercase mb-2">
                        <?php echo htmlspecialchars($data['docNumber']); ?>
                    </div>
                    <div class="text-center font-bold text-base underline tracking-widest uppercase">
                        AFFIDAVIT
                    </div>
                </div>

                <!-- Preamble -->
                <p class="mb-4 leading-normal">
                    I, Smt./Ms. <span class="font-bold uppercase px-0.5"><?php echo htmlspecialchars($data['declarantName']); ?></span>, 
                    <span class="font-bold px-0.5"><?php echo htmlspecialchars($data['relType']); ?></span> 
                    <span class="font-bold uppercase px-0.5"><?php echo htmlspecialchars($data['relativeName']); ?></span>, 
                    resident of <span class="font-bold uppercase px-0.5"><?php echo htmlspecialchars($data['address']); ?></span>, 
                    do hereby solemnly affirm and declare as under:
                </p>

                <!-- 7 Points -->
                <ol class="list-decimal list-outside pl-5 space-y-2.5 text-justify">
                    <li>
                        That I am the holder of Aadhaar number 
                        <span class="font-mono font-bold tracking-widest px-0.5"><?php echo htmlspecialchars($data['aadhaarNo']); ?></span>.
                    </li>
                    <li>
                        That my name prior to marriage/divorce was 
                        <span class="font-bold uppercase px-0.5"><?php echo htmlspecialchars($data['priorName']); ?></span>.
                    </li>
                    <li>
                        That consequent upon my marriage solemnized on / divorce becoming effective on 
                        <span class="font-semibold px-0.5"><?php echo formatLegalDate($data['eventDate']); ?></span>, 
                        I have adopted/am entitled to use the surname 
                        <span class="font-bold uppercase px-0.5"><?php echo htmlspecialchars($data['newSurname']); ?></span>, 
                        and my full name is now 
                        <span class="font-bold uppercase px-0.5"><?php echo htmlspecialchars($data['fullName']); ?></span>.
                    </li>
                    <li>
                        That I request for name update in my Aadhaar by replacing my earlier surname 
                        <span class="font-bold uppercase px-0.5"><?php echo htmlspecialchars($data['priorName']); ?></span> 
                        with my present surname 
                        <span class="font-bold uppercase px-0.5"><?php echo htmlspecialchars($data['newSurname']); ?></span> 
                        while my identity as the individual remains same.
                    </li>
                    <li>
                        That I am submitting the prescribed supporting document(s) in support of the said change of surname.
                    </li>
                    <li>
                        That the requested name update is solely on account of marriage/divorce and does not involve any fraudulent assumption or concealment of identity.
                    </li>
                    <li>
                        That I undertake if any declaration made herein or any document submitted by me is found to be false, fabricated, forged, fraudulent or otherwise not genuine, I shall be solely responsible for all legal consequences including deactivation of my Aadhaar number and prosecution under the applicable laws.
                    </li>
                </ol>

                <!-- First Signature -->
                <div class="mt-8 text-right">
                    <div class="inline-block text-center pr-4">
                        <div class="h-8"></div>
                        <div class="font-bold">Deponent</div>
                    </div>
                </div>

                <!-- Verification -->
                <div class="mt-4 pt-3 border-t border-slate-300">
                    <div class="font-bold underline mb-1">Verification:</div>
                    <p class="leading-normal">
                        Verified at <span class="font-bold px-0.5"><?php echo htmlspecialchars($data['verLocation']); ?></span> 
                        on this <span class="font-bold px-0.5"><?php echo formatLegalDate($data['verDate']); ?></span> 
                        that the contents of this affidavit are true and correct to the best of my knowledge and belief, and nothing material has been concealed therefrom.
                    </p>
                </div>

                <!-- Second Signature -->
                <div class="mt-8 text-right">
                    <div class="inline-block text-center pr-4">
                        <div class="h-8"></div>
                        <div class="font-bold">Deponent</div>
                    </div>
                </div>

            </div>
        </div>

    </div>

</body>
</html>