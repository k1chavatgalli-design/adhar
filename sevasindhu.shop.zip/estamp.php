<?php
/**
 * Affidavit Generator
 * Form → Preview (e-Stamp page 1 + page 2) → PDF
 */

date_default_timezone_set('Asia/Kolkata');
$live_issued_date = date('d-M-Y');
$live_date = date('d-m-Y');

function generateCertificateNo(): string {
    return 'IN-KA'
        . str_pad((string) random_int(0, 99999999), 8, '0', STR_PAD_LEFT)
        . str_pad((string) random_int(0, 99999999), 8, '0', STR_PAD_LEFT)
        . 'T';
}

$live_certificate_no = generateCertificateNo();

$affidavit_fields = [
    'name'          => 'Full Name',
    'father_name'   => "Father's Name",
    'address'       => 'Address',
    'caste'         => 'Caste',
    'annual_income' => 'Annual Income (Rs.)',
    'for_person'    => 'Certificate For (Name)',
    'mother_name'   => "Mother's Name",
    'purpose'       => 'Purpose',
    'place'         => 'Place',
    'date'          => 'Date',
];

$stamp_fields = [
    'certificate_no'       => 'Certificate No',
    'issued_date'          => 'Certificate Issued Date',
    'account_reference'    => 'Account Reference',
    'unique_doc_reference' => 'Unique Doc Reference',
    'issued_by'            => 'Purchased by',
    'description'          => 'Description of Document',
    'property_description' => 'Property Description',
    'consideration_price'  => 'Consideration Price (Rs.)',
    'first_party'          => 'First Party',
    'second_party'         => 'Second Party',
    'stamp_paid_by'        => 'Stamp Paid By',
    'stamp_amount'         => 'Stamp Duty Amount (Rs.)',
];

$defaults = [
    'name'                 => 'DIKSHAN M M',
    'father_name'          => 'MANJUNATH M P',
    'address'              => 'no 28 1st CROSS S L V ENCLAVE NEAR VAIKUNTA BAR LAKSHMIPURA BANGALORE -562123',
    'caste'                => 'DOMBI DASARU',
    'annual_income'        => '20,000',
    'for_person'           => 'Sheela Bai',
    'mother_name'          => 'Hemi Bai',
    'purpose'              => 'Educational purpose',
    'place'                => 'BENGALURU',
    'date'                 => $live_date,
    'certificate_no'       => $live_certificate_no,
    'issued_date'          => $live_issued_date,
    'account_reference'    => 'NONACC (SV)/ ka12345678/ BENGALURU/ KA-BN',
    'unique_doc_reference' => 'SUBIN-KAKA1234567890123456789012T',
    'issued_by'            => 'DIKSHAN M M',
    'description'          => 'AFFIDAVIT',
    'property_description' => 'AFFIDAVIT',
    'consideration_price'  => '0',
    'first_party'          => 'DIKSHAN M M',
    'second_party'         => 'NA',
    'stamp_paid_by'        => 'DIKSHAN M M',
    'stamp_amount'         => '100',
];

$is_preview = ($_SERVER['REQUEST_METHOD'] === 'POST');

$data = $defaults;
if ($is_preview) {
    foreach (array_keys($defaults) as $key) {
        $data[$key] = trim($_POST[$key] ?? '');
    }
}
$data['issued_date'] = $live_issued_date;
$data['date'] = $live_date;
if ($is_preview) {
    $posted_cert = strtoupper(trim($_POST['certificate_no'] ?? ''));
    if (!preg_match('/^IN-KA\d{16}T$/', $posted_cert)) {
        $data['certificate_no'] = generateCertificateNo();
    } else {
        $data['certificate_no'] = $posted_cert;
    }
}

function h(string $v): string {
    return htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
}

function numberToWords50k($num): string {
    $num = (int)$num;
    $ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
        "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen",
        "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
    $tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];

    if ($num === 0) return "Zero";
    if ($num < 0 || $num > 100000) return (string)$num;

    $two = function ($n) use ($ones, $tens) {
        if ($n < 20) return $ones[$n];
        $t = intdiv($n, 10);
        $o = $n % 10;
        return $tens[$t] . ($o ? " " . $ones[$o] : "");
    };

    $three = function ($n) use ($ones, $two) {
        if ($n < 100) return $two($n);
        $h = intdiv($n, 100);
        $r = $n % 100;
        return $ones[$h] . " Hundred" . ($r ? " and " . $two($r) : "");
    };

    if ($num < 1000) return $three($num);

    $thousands = intdiv($num, 1000);
    $rem       = $num % 1000;
    $words = $two($thousands) . " Thousand";
    if ($rem) {
        $words .= ($rem < 100 ? " and " : " ") . $three($rem);
    }
    return $words;
}

$stamp_amount_int = (int)preg_replace('/[^\d]/', '', $data['stamp_amount']);
$consideration_int = (int)preg_replace('/[^\d]/', '', $data['consideration_price']);
$stamp_amount_words = numberToWords50k($stamp_amount_int) . ' Only';
$consideration_words = numberToWords50k($consideration_int);

$stamp_rows = [
    ['Certificate No', $data['certificate_no'], true],
    ['Certificate Issued Date', $data['issued_date'], false],
    ['Account Reference', $data['account_reference'], false],
    ['Unique Doc. Reference', $data['unique_doc_reference'], false],
    ['Purchased by', $data['issued_by'], false],
    ['Description of Document', $data['description'], false],
    ['Property Description', $data['property_description'], false],
    ['Consideration Price (Rs.)', number_format($consideration_int), false],
    ['First Party', $data['first_party'], false],
    ['Second Party', $data['second_party'], false],
    ['Stamp Duty Paid By', $data['stamp_paid_by'], false],
    ['Stamp Duty Amount(Rs.)', number_format($stamp_amount_int), false],
];

header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $is_preview ? 'Preview Affidavit - ' . h($data['name']) : 'Affidavit Form'; ?></title>
    <?php if ($is_preview): ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.2/html2pdf.bundle.min.js"></script>
    <?php endif; ?>
    <style>
        :root {
            --ink: #1a1a1a;
            --muted: #5a5a5a;
            --line: #d0d0d0;
            --accent: #0b5cab;
            --bg: #f0f2f5;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            color: var(--ink);
            background: var(--bg);
            font-family: Georgia, "Times New Roman", Times, serif;
        }

        .form-wrap {
            max-width: 820px;
            margin: 0 auto;
            padding: 28px 18px 48px;
        }
        .form-card {
            background: #fff;
            border: 1px solid var(--line);
            padding: 28px 26px 32px;
        }
        .form-card h1 {
            margin: 0 0 6px;
            font-size: 1.55rem;
            letter-spacing: 0.04em;
            text-align: center;
            text-transform: uppercase;
        }
        .form-card .sub {
            text-align: center;
            color: var(--muted);
            font-size: 0.95rem;
            margin: 0 0 24px;
        }
        .section-title {
            grid-column: 1 / -1;
            margin: 18px 0 4px;
            padding-bottom: 6px;
            border-bottom: 1px solid var(--line);
            font-size: 0.95rem;
            font-weight: 700;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            color: #333;
        }
        .section-title:first-of-type { margin-top: 0; }
        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px 16px;
        }
        .field { display: flex; flex-direction: column; gap: 5px; }
        .field.full { grid-column: 1 / -1; }
        .field label {
            font-size: 0.82rem;
            font-weight: 700;
            letter-spacing: 0.02em;
            color: #333;
        }
        .field input,
        .field textarea {
            font: inherit;
            font-size: 0.98rem;
            padding: 9px 11px;
            border: 1px solid #b8b8b8;
            background: #fafafa;
            color: var(--ink);
            width: 100%;
        }
        .field input:focus,
        .field textarea:focus {
            outline: 2px solid #9ec5ea;
            border-color: var(--accent);
            background: #fff;
        }
        .field textarea { min-height: 72px; resize: vertical; }
        .actions {
            margin-top: 22px;
            display: flex;
            gap: 10px;
            justify-content: center;
            flex-wrap: wrap;
        }
        .btn {
            appearance: none;
            border: none;
            cursor: pointer;
            font-family: inherit;
            font-size: 1rem;
            padding: 11px 22px;
            background: var(--accent);
            color: #fff;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover { background: #084a8a; }
        .btn.secondary {
            background: #fff;
            color: var(--accent);
            border: 1px solid var(--accent);
        }
        .btn.secondary:hover { background: #eef5fc; }
        .btn:disabled { opacity: 0.65; cursor: wait; }
        @media (max-width: 640px) {
            .grid { grid-template-columns: 1fr; }
        }

        .toolbar {
            position: sticky;
            top: 0;
            z-index: 20;
            background: #fff;
            border-bottom: 1px solid var(--line);
            padding: 12px 16px;
            display: flex;
            gap: 10px;
            justify-content: center;
            flex-wrap: wrap;
        }

        @page { size: A4; margin: 0; }
        .preview-shell {
            width: 210mm;
            max-width: 100%;
            margin: 20px auto 40px;
            padding: 0 8px;
        }
        #affidavit {
            color: #000;
            font-family: "Times New Roman", Times, serif;
            font-size: 14pt;
            line-height: 1.65;
        }
        .a4-page {
            width: 210mm;
            height: 297mm;
            max-width: 100%;
            margin: 0 auto 18px;
            padding: 22mm 20mm 20mm;
            background: #fff;
            border: 1px solid var(--line);
            box-sizing: border-box;
            overflow: hidden;
            page-break-after: always;
            break-after: page;
            display: flex;
            flex-direction: column;
            position: relative;
        }
        .a4-page:last-child {
            page-break-after: auto;
            break-after: auto;
            margin-bottom: 0;
        }
        .a4-page .page-body {
            flex: 1 1 auto;
            text-align: justify;
            min-height: 0;
        }
        .a4-page .page-body p { margin: 14px 0; }

        /* Page 1: e-Stamp bond + details overlay */
        .a4-page.page-1 {
            justify-content: flex-end;
            padding: 0;
            background-color: #fff;
            background-image: url('bg/bond_bg.png');
            background-repeat: no-repeat;
            background-position: center top;
            background-size: 100% 100%;
            font-family: Arial, Helvetica, sans-serif;
        }
        .stamp-layer {
            position: absolute;
            inset: 0;
            z-index: 2;
            pointer-events: none;
        }
        .stamp-text {
            position: absolute;
            font-size: 13px;
            color: #222325;
            line-height: 1.05;
            white-space: nowrap;
            max-width: 100mm;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .stamp-text.wrap {
            white-space: normal;
            max-width: 105mm;
            line-height: 1.15;
        }
        .stamp-rs {
            position: absolute;
            top: 51.5mm;
            left: 171mm;
            font-size: 20px;
            color: #d5d1d1;
            font-weight: bold;
            line-height: 1;
        }
        .outer-circle {
            width: 111px;
            height: 100px;
            border-radius: 100%;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #ffffff;
            position: absolute;
            top: 175mm;
            left: 158mm;
        }
        .inner-circle {
            width: 140px;
            height: 140px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .outer-circle svg { width: 150px; height: 150px; }
        .textArcTop,
        .textArcMiddle,
        .textArcBottom {
            font-size: 12px;
            fill: #d5d1d1;
            font-weight: bold;
            letter-spacing: 0.5px;
            dominant-baseline: middle;
        }
        .centerText {
            font-size: 17px;
            fill: #d5d1d1;
            font-weight: bold;
        }
        .crosshair {
            position: absolute;
            width: 30mm;
            height: 30mm;
        }
        .crosshair svg { width: 60%; height: 97%; }
        .notary-stamp {
            position: absolute;
            top: 138mm;
            left: 138mm;
            width: 48mm;
            height: auto;
            z-index: 6;
            opacity: 0.95;
            pointer-events: none;
            transform: rotate(-8deg);
            mix-blend-mode: multiply;
        }

        .page1-footer {
            position: absolute;
            left: 22mm;
            right: 22mm;
            bottom: 22mm;
            z-index: 3;
            font-family: "Times New Roman", Times, serif;
            font-size: 14pt;
            line-height: 1.55;
            color: #000;
        }
        .page1-footer .doc-header {
            text-align: center;
            font-size: 20pt;
            font-weight: bold;
            text-decoration: underline;
            margin: 0 0 14px;
            letter-spacing: 2px;
        }
        .page1-footer .intro { margin: 0 0 12px; text-align: justify; }
        .page1-footer .affirm { margin: 0 0 18px; text-align: justify; }
        .page1-footer .page-cont { text-align: right; margin: 0; }

        .doc-header {
            text-align: center;
            font-size: 20pt;
            font-weight: bold;
            text-decoration: underline;
            margin: 0 0 36px;
            letter-spacing: 2px;
            flex: 0 0 auto;
        }
        .indent { text-indent: 50px; }
        .page-num {
            text-align: center;
            font-weight: bold;
            margin: 0 0 28px;
        }
        .deponent {
            text-align: right;
            margin-top: 48px;
            font-weight: bold;
        }
        .place-date {
            margin-top: 8px;
            position: relative;
            max-width: 95mm;
        }
        .place-date p { margin: 4px 0; }
        .place-date .place-line { margin-top: 2px; }
        .attested-stamp {
            display: block;
            /* original PNG 696px ≈ 59mm at 300dpi — exact stamp size */
            width: 78mm;
            height: auto;
            margin: -100mm 0 2px -24mm;
            padding: 0;
            border: 0;
            background: transparent !important;
            mix-blend-mode: multiply;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }
        .signature-line {
            margin-top: 64px;
            text-align: right;
        }
        .footer-note {
            margin-top: 28px;
            font-size: 11pt;
            font-style: italic;
            text-align: center;
            color: #555;
        }
        @media screen and (max-width: 820px) {
            .preview-shell { width: 100%; }
            .a4-page {
                width: 100%;
                height: 297mm;
                min-height: 297mm;
            }
        }
        @media print {
            body { background: #fff; }
            .toolbar, .no-print { display: none !important; }
            .preview-shell {
                width: 210mm;
                margin: 0;
                padding: 0;
            }
            .a4-page {
                width: 210mm;
                height: 297mm;
                margin: 0;
                border: none;
                box-shadow: none;
                overflow: hidden;
                -webkit-print-color-adjust: exact;
                print-color-adjust: exact;
            }
            .a4-page.page-1 {
                background-image: url('bg/bond_bg.png') !important;
                background-size: 100% 100% !important;
                background-repeat: no-repeat !important;
            }
        }
    </style>
</head>
<body>

<?php if (!$is_preview): ?>

<div class="form-wrap">
    <form class="form-card" method="post" action="" id="affidavit-form">
        <h1>AFFIDAVIT</h1>
        <p class="sub">Full Name ondu fill → First Party / Stamp Paid By / Purchased by auto baruttade</p>

        <div class="grid">
            <div class="section-title">Full Name (auto-fills stamp parties)</div>
            <div class="field full">
                <label for="name"><?php echo h($affidavit_fields['name']); ?></label>
                <input id="name" name="name" required value="<?php echo h($data['name']); ?>" autocomplete="name">
            </div>

            <div class="section-title">e-Stamp / Bond Details</div>
            <?php foreach ($stamp_fields as $key => $label):
                $sync = in_array($key, ['issued_by', 'first_party', 'stamp_paid_by'], true);
                $live = ($key === 'issued_date');
                $auto_unique = ($key === 'certificate_no');
            ?>
            <div class="field<?php echo in_array($key, ['account_reference', 'unique_doc_reference', 'description'], true) ? ' full' : ''; ?>">
                <label for="<?php echo h($key); ?>"><?php echo h($label); ?><?php echo $sync ? ' (auto)' : ($live ? ' (live)' : ($auto_unique ? ' (auto unique)' : '')); ?></label>
                <input
                    id="<?php echo h($key); ?>"
                    name="<?php echo h($key); ?>"
                    required
                    value="<?php echo h($data[$key]); ?>"
                    <?php echo $sync ? 'data-sync-from="name" class="synced-name"' : ''; ?>
                    <?php echo ($live || $auto_unique) ? 'readonly' : ''; ?>
                >
            </div>
            <?php endforeach; ?>

            

        <div class="actions">
            <button type="submit" class="btn">Preview Affidavit</button>
        </div>
    </form>
</div>

<script>
(function () {
    var nameEl = document.getElementById('name');
    if (!nameEl) return;

    function syncName() {
        var v = nameEl.value;
        document.querySelectorAll('[data-sync-from="name"]').forEach(function (el) {
            el.value = v;
        });
    }

    nameEl.addEventListener('input', syncName);
    nameEl.addEventListener('change', syncName);
    syncName();
})();
</script>

<?php else: ?>

<div class="toolbar no-print">
    <a class="btn secondary" href="index.php">← Edit Form</a>
    <button type="button" class="btn" id="btn-pdf">Download PDF</button>
    <button type="button" class="btn secondary" onclick="window.print()">Print</button>
</div>

<div class="preview-shell">
    <div id="affidavit">
        <section class="a4-page page-1" id="page-1">
            <div class="stamp-layer">
                <?php
                $top = 74.5;
                foreach ($stamp_rows as $row) {
                    [$label, $value, $bold] = $row;
                    $fw = $bold ? 'font-weight:bold;' : '';
                    $wrap = (strlen((string)$value) > 42) ? ' wrap' : '';
                    echo '<div class="stamp-text" style="top:' . $top . 'mm; left:21mm; ' . $fw . '">' . h($label) . '</div>';
                    echo '<div class="stamp-text' . $wrap . '" style="top:' . $top . 'mm; left:85mm; ' . $fw . '">' . h((string)$value) . '</div>';
                    $top += ($label === 'Consideration Price (Rs.)') ? 8.5 : 5.7;
                }
                ?>
                <div class="stamp-text" style="top:144.5mm; left:86mm;">(<?php echo h($stamp_amount_words); ?>)</div>
                <div class="stamp-text" style="top:117.5mm; left:87mm;">(<?php echo h($consideration_words); ?>)</div>
                <div class="stamp-rs">Rs.<?php echo h((string)$stamp_amount_int); ?></div>

                <div class="outer-circle">
                    <div class="inner-circle">
                        <svg viewBox="0 0 200 200" aria-label="Round Stamp">
                            <circle cx="100" cy="100" r="85" stroke="#d5d1d1" stroke-width="4" fill="none" />
                            <circle cx="100" cy="100" r="60" stroke="#d5d1d1" stroke-width="1.5" fill="none" />
                            <defs>
                                <path id="arcTop" d="M100,100 m-78,0 a78,78 0 1,1 156,0 a78,78 0 1,1 -156,0" />
                                <path id="arcMiddle" d="M100,100 m-52,0 a52,52 0 1,1 104,0 a52,52 0 1,1 -104,0" />
                                <path id="arcBottom" d="M100,100 m52,0 a52,52 0 1,0 -104,0 a52,52 0 1,0 104,0" />
                            </defs>
                            <text dy="7">
                                <textPath href="#arcTop" startOffset="26%" text-anchor="middle" class="textArcTop">
                                    <?php echo h($data['first_party']); ?>
                                </textPath>
                            </text>
                            <text dy="1">
                                <textPath href="#arcMiddle" startOffset="26%" text-anchor="middle" class="textArcMiddle">
                                    <?php echo h($data['certificate_no']); ?>
                                </textPath>
                            </text>
                            <text dy="1">
                                <textPath href="#arcBottom" startOffset="75%" text-anchor="middle" class="textArcBottom">
                                    <?php echo h($data['issued_date']); ?>
                                </textPath>
                            </text>
                            <text x="100" y="106" class="centerText" text-anchor="middle">
                                RS: <?php echo h((string)$stamp_amount_int); ?>
                            </text>
                        </svg>
                    </div>
                </div>

                <div class="crosshair" style="top:157mm; left:58.5mm;">
                    <svg viewBox="0 0 100 100">
                        <circle cx="50" cy="50" r="20" stroke="black" stroke-width="1" fill="none" />
                        <line x1="10" y1="50" x2="88" y2="50" stroke="black" stroke-width="1"/>
                        <line x1="50" y1="10" x2="50" y2="88" stroke="black" stroke-width="1"/>
                    </svg>
                </div>
                <div class="crosshair" style="top:186mm; left:137mm;">
                    <svg viewBox="0 0 100 100">
                        <circle cx="50" cy="50" r="20" stroke="black" stroke-width="1" fill="none" />
                        <line x1="10" y1="50" x2="88" y2="50" stroke="black" stroke-width="1"/>
                        <line x1="50" y1="10" x2="50" y2="88" stroke="black" stroke-width="1"/>
                    </svg>
                </div>
        </section>
    </div>
    </p>
</div>

<script>
(function () {
    var btn = document.getElementById('btn-pdf');
    if (!btn || typeof html2pdf === 'undefined') return;

    btn.addEventListener('click', function () {
        btn.disabled = true;
        btn.textContent = 'Preparing PDF…';

        var el = document.getElementById('affidavit');
        var name = <?php echo json_encode($data['name']); ?>;
        var filename = 'Affidavit_' + String(name || 'document').replace(/[^\w\-]+/g, '_') + '.pdf';

        var opt = {
            margin: 0,
            filename: filename,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { scale: 2, useCORS: true, letterRendering: true, windowWidth: 794 },
            jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
            pagebreak: { mode: ['css', 'legacy'], after: '.a4-page' }
        };

        html2pdf().set(opt).from(el).save().then(function () {
            btn.disabled = false;
            btn.textContent = 'Download PDF';
        }).catch(function () {
            btn.disabled = false;
            btn.textContent = 'Download PDF';
            alert('PDF create agalilla. Print button use maadi → Save as PDF.');
        });
    });
})();
</script>

<?php endif; ?>

</body>
</html>