<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Affidavit Data Entry & PDF Generator</title>
  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Lucide Icons -->
  <script src="https://unpkg.com/lucide@latest"></script>

  <style>
    :root {
      --affidavit-font-size: 15px;
    }

    body {
      font-family: 'Inter', sans-serif;
    }

    /* Legal Document Typography - Bookman Old Style */
    .legal-font {
      font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif;
    }

    .affidavit-title {
      font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif;
      letter-spacing: 0.15em;
    }

    /* Page container styling on screen */
    .page-sheet {
      width: 210mm;
      min-height: 297mm;
      height: 297mm;
      background: #ffffff;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
      position: relative;
      box-sizing: border-box;
      overflow: hidden;
      font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif;
      font-size: var(--affidavit-font-size);
    }

    /* Strict A4 Print Specific Styling */
    @page {
      size: A4 portrait;
      margin: 0;
    }

    @media print {
      html, body {
        width: 210mm !important;
        height: auto !important;
        margin: 0 !important;
        padding: 0 !important;
        background: #ffffff !important;
        color: #000000 !important;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
        font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif !important;
      }

      .no-print {
        display: none !important;
      }

      main {
        padding: 0 !important;
        margin: 0 !important;
        max-width: 100% !important;
      }

      #preview-container {
        border: none !important;
        box-shadow: none !important;
        margin: 0 !important;
        padding: 0 !important;
        background: transparent !important;
        width: 210mm !important;
        display: block !important;
      }

      .page-sheet {
        box-shadow: none !important;
        border: none !important;
        width: 210mm !important;
        height: 297mm !important;
        max-height: 297mm !important;
        min-height: 297mm !important;
        margin: 0 !important;
        padding: 16mm 20mm !important;
        box-sizing: border-box !important;
        overflow: hidden !important;
        page-break-inside: avoid !important;
        break-inside: avoid !important;
        font-size: var(--affidavit-font-size) !important;
        font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif !important;
        transform: scale(var(--doc-scale, 0.96));
        transform-origin: top center;
        zoom: var(--doc-scale, 0.96);
      }

      #page-1-sheet {
        display: flex !important;
        flex-direction: column !important;
        justify-content: flex-end !important;
        page-break-after: always !important;
        break-after: page !important;
        page-break-inside: avoid !important;
        break-inside: avoid !important;
      }

      #page-2-sheet {
        display: block !important;
        page-break-before: always !important;
        break-before: page !important;
        page-break-after: avoid !important;
        break-after: avoid !important;
        page-break-inside: avoid !important;
        break-inside: avoid !important;
      }

      .keep-together {
        page-break-inside: avoid !important;
        break-inside: avoid !important;
      }
    }
  </style>
</head>
<body class="bg-slate-100 min-h-screen text-slate-800 antialiased selection:bg-amber-100 selection:text-amber-900">

  <!-- Header Navigation -->
  <header class="no-print bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-30 shadow-md">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3">
      <div class="flex items-center gap-3">
        <div class="p-2 bg-amber-500 text-slate-950 rounded-lg shadow-sm">
          <i data-lucide="scale" class="w-6 h-6"></i>
        </div>
        <div>
          <h1 class="text-base sm:text-lg font-bold tracking-tight">Affidavit Generator & Notary Form</h1>
          <p class="text-xs text-slate-400">Belagavi Corporation Birth Certificate Correction</p>
        </div>
      </div>
      <div class="flex items-center gap-2">
        <button type="button" onclick="scrollToPreview()" class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition">
          <i data-lucide="eye" class="w-4 h-4"></i>
          <span>View Preview</span>
        </button>
        <button type="button" onclick="handlePrint()" class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-medium shadow-sm transition active:scale-95">
          <i data-lucide="printer" class="w-4 h-4"></i>
          <span>Print / Save PDF</span>
        </button>
      </div>
    </div>
  </header>

  <main class="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-8">

    <!-- DATA ENTRY FORM SECTION -->
    <section class="no-print bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      <div class="bg-slate-50 border-b border-slate-200 px-6 py-4 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 class="text-base font-bold text-slate-900 flex items-center gap-2">
            <i data-lucide="file-pen" class="w-4 h-4 text-amber-600"></i>
            Data Entry Details
          </h2>
          <p class="text-xs text-slate-500 mt-0.5">Edit form parameters to immediately update the affidavit document preview below.</p>
        </div>
        <div class="flex items-center gap-2">
          <button type="button" onclick="resetToDefaultData()" class="inline-flex items-center gap-1 px-3 py-1.5 text-xs text-slate-600 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg transition font-medium">
            <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
            Reset Initial Data
          </button>
        </div>
      </div>

      <form id="affidavit-form" class="p-6 space-y-6" onsubmit="event.preventDefault(); updateAffidavit();">

        <!-- Deponent Information -->
        <div>
          <h3 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <i data-lucide="user" class="w-4 h-4"></i> 1. Deponent Personal Particulars
          </h3>
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Deponent Full Name</label>
              <input type="text" id="deponentName" value="SATISH" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white uppercase tracking-wide">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Age / Majority Status</label>
              <input type="text" id="deponentAge" value="Major" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Occupation</label>
              <input type="text" id="deponentOccupation" value="Private Services" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div class="sm:col-span-2 md:col-span-3">
              <label class="block text-xs font-semibold text-slate-700 mb-1">Complete Residential Address</label>
              <textarea id="deponentAddress" rows="2" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">#T2, Parnali Apartment, Roy Road, Tilakwadi, Belgaum, Belagavi, Karnataka 590006</textarea>
            </div>
          </div>
        </div>

        <hr class="border-slate-200">

        <!-- Certificate & Registration Details -->
        <div>
          <h3 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <i data-lucide="file-check-2" class="w-4 h-4"></i> 2. Certificate Information
          </h3>
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Relation / Certificate Subject</label>
              <input type="text" id="certRelation" value="son" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div class="md:col-span-2">
              <label class="block text-xs font-semibold text-slate-700 mb-1">Issuing Authority</label>
              <input type="text" id="issuingAuthority" value="City Corporation of Belagavi" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Registration Number</label>
              <input type="text" id="regNumber" value="803033/T/B/2014/005020" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white font-mono text-xs">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Date of Registration</label>
              <input type="text" id="regDate" value="28/03/2014" placeholder="DD/MM/YYYY" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Date of Birth</label>
              <input type="text" id="dobDate" value="16/03/2014" placeholder="DD/MM/YYYY" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Execution Place</label>
              <input type="text" id="executionPlace" value="Belagavi" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Affidavit Date</label>
              <input type="text" id="affidavitDate" value="08/10/2026" placeholder="DD/MM/YYYY" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>
          </div>
        </div>

        <hr class="border-slate-200">

        <!-- Corrections Table Builder -->
        <div>
          <div class="flex items-center justify-between mb-3">
            <h3 class="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <i data-lucide="table-2" class="w-4 h-4"></i> 3. Discrepancy & Correction Table Entries
            </h3>
            <button type="button" id="btnAddRow" class="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-amber-800 bg-amber-50 border border-amber-300 rounded-lg hover:bg-amber-100 transition shadow-sm">
              <i data-lucide="plus-circle" class="w-3.5 h-3.5"></i> Add Correction Row
            </button>
          </div>

          <div class="overflow-x-auto border border-slate-200 rounded-xl bg-slate-50">
            <table class="w-full text-left text-xs text-slate-700 border-collapse">
              <thead class="bg-slate-100 text-slate-700 uppercase font-semibold text-[11px] border-b border-slate-200">
                <tr>
                  <th class="py-2.5 px-3 w-40">Column No / Field</th>
                  <th class="py-2.5 px-3">Wrong / Erroneous Data</th>
                  <th class="py-2.5 px-3">Correct / To Be Entered Data</th>
                  <th class="py-2.5 px-2 text-center w-12">Action</th>
                </tr>
              </thead>
              <tbody id="corrections-tbody" class="divide-y divide-slate-200 bg-white">
                <!-- Populated dynamically via JS -->
              </tbody>
            </table>
          </div>
        </div>

        <hr class="border-slate-200">

        <!-- Font Size, Margins & Scale Controls -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <!-- Font Size Adjustment -->
          <div class="bg-indigo-50/60 p-4 rounded-xl border border-indigo-200/70 flex flex-col justify-between gap-3">
            <div>
              <label class="text-xs font-semibold text-slate-800 flex items-center justify-between">
                <span class="flex items-center gap-1.5"><i data-lucide="type" class="w-4 h-4 text-indigo-600"></i> Font Size:</span>
                <span id="fontSizeDisplay" class="text-indigo-800 font-bold font-mono text-xs bg-white px-2 py-0.5 rounded border border-indigo-200">15 px</span>
              </label>
              <p class="text-[11px] text-slate-500 mt-1">Increase or decrease document text font size.</p>
            </div>
            <div class="flex items-center gap-2">
              <button type="button" onclick="adjustFontSize(-1)" class="flex-1 py-1.5 px-3 bg-white border border-indigo-300 rounded-lg hover:bg-indigo-100 text-indigo-950 font-bold text-xs transition flex items-center justify-center gap-1 active:scale-95 shadow-sm">
                <i data-lucide="minus" class="w-3.5 h-3.5"></i> A-
              </button>
              <button type="button" onclick="setFontSize(15)" class="py-1.5 px-2 text-[11px] bg-indigo-100 border border-indigo-300 rounded-lg hover:bg-indigo-200 text-indigo-900 font-semibold transition">
                Reset
              </button>
              <button type="button" onclick="adjustFontSize(1)" class="flex-1 py-1.5 px-3 bg-white border border-indigo-300 rounded-lg hover:bg-indigo-100 text-indigo-950 font-bold text-xs transition flex items-center justify-center gap-1 active:scale-95 shadow-sm">
                <i data-lucide="plus" class="w-3.5 h-3.5"></i> A+
              </button>
            </div>
          </div>

          <!-- Non-Judicial Stamp Reserve -->
          <div class="bg-amber-50/50 p-4 rounded-xl border border-amber-200/60 flex flex-col justify-between gap-3">
            <div>
              <label for="topMarginSlider" class="text-xs font-semibold text-slate-800 flex items-center justify-between">
                <span class="flex items-center gap-1.5"><i data-lucide="file-text" class="w-4 h-4 text-amber-600"></i> Stamp Space:</span>
                <span id="topMarginValue" class="text-amber-800 font-mono text-xs bg-white px-1.5 py-0.5 rounded border border-amber-200">0 mm</span>
              </label>
              <p class="text-[11px] text-slate-500 mt-1">Set to 70mm - 90mm for physical e-Stamp paper.</p>
            </div>
            <div class="flex items-center gap-2">
              <input type="range" id="topMarginSlider" min="0" max="100" step="5" value="0" oninput="updateTopMargin(this.value)" class="w-full accent-amber-600 cursor-pointer">
              <button type="button" onclick="setStampPreset(0)" class="px-2 py-1 text-[11px] bg-white border border-slate-300 rounded hover:bg-slate-100 whitespace-nowrap">0mm</button>
              <button type="button" onclick="setStampPreset(80)" class="px-2 py-1 text-[11px] bg-amber-100 border border-amber-300 text-amber-900 rounded hover:bg-amber-200 font-medium whitespace-nowrap">80mm</button>
            </div>
          </div>

          <!-- Page Scale Slider -->
          <div class="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-col justify-between gap-3">
            <div>
              <label for="scaleSlider" class="text-xs font-semibold text-slate-800 flex items-center justify-between">
                <span class="flex items-center gap-1.5"><i data-lucide="maximize-2" class="w-4 h-4 text-slate-600"></i> Output Scale:</span>
                <span id="scaleValue" class="text-slate-800 font-bold font-mono text-xs bg-white px-1.5 py-0.5 rounded border border-slate-300">96%</span>
              </label>
              <p class="text-[11px] text-slate-500 mt-1">Locked to 96% to keep text neatly bounded within A4.</p>
            </div>
            <div class="flex items-center gap-2">
              <input type="range" id="scaleSlider" min="85" max="105" step="1" value="96" oninput="updateDocumentScale(this.value)" class="w-full accent-slate-700 cursor-pointer">
              <button type="button" onclick="setDocumentScale(96)" class="px-2 py-1 text-[11px] bg-slate-200 border border-slate-300 text-slate-900 font-bold rounded hover:bg-slate-300">96%</button>
              <button type="button" onclick="setDocumentScale(100)" class="px-2 py-1 text-[11px] bg-white border border-slate-300 rounded hover:bg-slate-100">100%</button>
            </div>
          </div>
        </div>

        <div class="flex flex-wrap items-center justify-end gap-3 pt-2">
          <button type="button" onclick="updateAffidavit()" class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-900 text-white font-medium text-xs hover:bg-slate-800 shadow transition">
            <i data-lucide="refresh-cw" class="w-4 h-4"></i>
            Refresh Document Preview
          </button>
          <button type="button" onclick="handlePrint()" class="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition transform active:scale-95">
            <i data-lucide="printer" class="w-4 h-4"></i>
            Print / Save to PDF
          </button>
        </div>
      </form>
    </section>

    <!-- LIVE DOCUMENT PREVIEW SECTION -->
    <section class="space-y-4">
      <div class="no-print flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-slate-900 flex items-center gap-2">
            <i data-lucide="file-badge" class="w-4 h-4 text-amber-600"></i>
            Document Preview (2-Page Legal Output)
          </h2>
          <p class="text-xs text-slate-500">Page 1: Title & Solemn Affirmation • Page 2: Statement, Discrepancy Table & Deponent Signature</p>
        </div>
        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
          <span class="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
          2-Page Synchronized
        </span>
      </div>

      <div id="preview-container" class="bg-slate-300/70 p-4 sm:p-8 rounded-2xl border border-slate-300 flex flex-col items-center gap-8 shadow-inner overflow-x-auto">
        
        <!-- PAGE 1 -->
        <div id="page-1-sheet" class="page-sheet page-break-after rounded-sm p-8 sm:p-14 md:p-16 legal-font leading-relaxed flex flex-col justify-end">
          <div class="no-print absolute top-3 right-4 text-[11px] font-sans font-bold bg-slate-100 border border-slate-300 text-slate-600 px-2 py-0.5 rounded">
            PAGE 1 of 2
          </div>

          <div id="stamp-space" class="transition-all duration-200" style="height: 0mm;"></div>

          <div class="keep-together mt-auto pb-4">
            <div class="text-center mb-6">
              <h1 class="affidavit-title text-[1.6em] font-black underline tracking-widest uppercase">AFFIDAVIT</h1>
            </div>

            <div class="text-justify leading-loose indent-12">
              I, <span id="out-deponentName" class="font-bold underline uppercase tracking-wide">SATISH</span>, 
              Age: <span id="out-deponentAge" class="font-semibold">Major</span>, 
              Occ: <span id="out-deponentOccupation" class="font-semibold">Private Services</span>, 
              residing at: <span id="out-deponentAddress" class="font-medium">#T2, Parnali Apartment, Roy Road, Tilakwadi, Belgaum, Belagavi, Karnataka 590006</span>, 
              today at <span id="out-executionPlace" class="font-semibold">Belagavi</span>, do hereby state on solemn affirmation and make this affidavit as under:
            </div>
          </div>
        </div>

        <!-- PAGE 2 -->
        <div id="page-2-sheet" class="page-sheet rounded-sm p-8 sm:p-14 md:p-16 legal-font leading-relaxed block">
          <div class="no-print absolute top-3 right-4 text-[11px] font-sans font-bold bg-slate-100 border border-slate-300 text-slate-600 px-2 py-0.5 rounded">
            PAGE 2 of 2
          </div>

          <div>
            <div class="text-center font-bold text-[1.1em] mb-6 tracking-widest">- 2 -</div>

            <div class="space-y-4 mb-6">
              <div class="flex items-start text-justify">
                <span class="font-bold min-w-[32px]">1]</span>
                <span>That I am permanent resident of the above mentioned address.</span>
              </div>

              <div class="flex items-start text-justify">
                <span class="font-bold min-w-[32px]">2]</span>
                <div>
                  That, in my <span id="out-certRelation" class="font-semibold">son</span> Birth Certificate issued by the 
                  <span id="out-issuingAuthority" class="font-bold">City Corporation of Belagavi</span> bearing 
                  Registration No. : <span id="out-regNumber" class="font-bold font-mono">803033/T/B/2014/005020</span>, 
                  Date of Registration : <span id="out-regDate" class="font-semibold">28/03/2014</span>, and 
                  Date of Birth : <span id="out-dobDate" class="font-semibold">16/03/2014</span>. In the said birth certificate all entries are correct except:
                </div>
              </div>
            </div>

            <!-- Correction Table -->
            <div class="my-6">
              <table class="w-full border-collapse border border-black text-center text-[0.95em]">
                <thead>
                  <tr class="bg-gray-100 font-bold border-b border-black">
                    <th class="border border-black py-2.5 px-3 w-1/4">Column No</th>
                    <th class="border border-black py-2.5 px-4 w-3/8 text-center">Wrong Data</th>
                    <th class="border border-black py-2.5 px-4 w-3/8 text-center">Correct Data</th>
                  </tr>
                </thead>
                <tbody id="out-corrections-body">
                  <!-- Dynamically populated via JS -->
                </tbody>
              </table>
            </div>

            <div class="space-y-4 mb-5 text-justify">
              <p class="indent-8">
                So the same may kindly be entered in the Birth Register and new birth certificate may kindly be issued at the earliest on the account of this affidavit.
              </p>
              <p class="indent-8">
                The contents of this affidavit are read over and explained to me in my vernacular and the same are true and correct to the best of my personal knowledge, belief and understanding.
              </p>
            </div>

            <div class="mt-6 pt-2">
              <div class="flex justify-between items-end">
                <div class="space-y-1 font-semibold text-[0.95em]">
                  <div>Place: <span id="out-place-footer">Belagavi</span></div>
                  <div>Date: <span id="out-date-footer">08/10/2026</span></div>
                </div>

                <div class="text-right">
                  <div class="h-10"></div>
                  <div class="font-bold tracking-wider uppercase text-[0.95em] border-t border-black pt-1 inline-block px-4">
                    DEPONENT
                  </div>
                </div>
              </div>
            </div>
          </div>

        </div>

      </div>
    </section>

  </main>

  <footer class="no-print border-t border-slate-200 bg-white py-6 mt-12 text-center text-xs text-slate-500">
    <p>Affidavit Generator Form • Designed for easy document formatting and standard legal printing</p>
  </footer>

  <script>
    let currentFontSize = 15; // default font size in pixels

    // Correction Items Data Store
    let corrections = [
      {
        columnNo: "6. FATHER NAME",
        wrongData: "SATISH CHANAGOND",
        correctData: "SATISH"
      }
    ];

    const defaultData = {
      deponentName: "SATISH",
      deponentAge: "Major",
      deponentOccupation: "Private Services",
      deponentAddress: "#T2, Parnali Apartment, Roy Road, Tilakwadi, Belgaum, Belagavi, Karnataka 590006",
      certRelation: "son",
      issuingAuthority: "City Corporation of Belagavi",
      regNumber: "803033/T/B/2014/005020",
      regDate: "28/03/2014",
      dobDate: "16/03/2014",
      executionPlace: "Belagavi",
      affidavitDate: "08/10/2026"
    };

    function escapeHtml(str) {
      if (!str) return '';
      return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
    }

    // Font size controls
    function setFontSize(size) {
      currentFontSize = Math.min(22, Math.max(12, parseInt(size) || 15));
      document.documentElement.style.setProperty('--affidavit-font-size', `${currentFontSize}px`);
      
      const displayElem = document.getElementById('fontSizeDisplay');
      if (displayElem) {
        displayElem.innerText = `${currentFontSize} px`;
      }
    }

    function adjustFontSize(delta) {
      setFontSize(currentFontSize + delta);
    }

    // Direct DOM construction for form inputs to prevent event-handler detachment
    function renderFormCorrectionRows() {
      const tbody = document.getElementById('corrections-tbody');
      tbody.innerHTML = '';

      corrections.forEach((row, index) => {
        const tr = document.createElement('tr');
        tr.className = 'hover:bg-slate-50 transition border-b border-slate-100 last:border-b-0';

        // Column / Field Input
        const tdCol = document.createElement('td');
        tdCol.className = 'py-2 px-3';
        const inCol = document.createElement('input');
        inCol.type = 'text';
        inCol.className = 'w-full px-2 py-1.5 text-xs border border-slate-300 rounded focus:border-amber-500 focus:outline-none bg-white font-medium';
        inCol.placeholder = 'e.g. 6. FATHER NAME';
        inCol.value = row.columnNo;
        inCol.oninput = (e) => {
          corrections[index].columnNo = e.target.value;
          renderPreviewCorrectionRows();
        };
        tdCol.appendChild(inCol);

        // Wrong Data Input
        const tdWrong = document.createElement('td');
        tdWrong.className = 'py-2 px-3';
        const inWrong = document.createElement('input');
        inWrong.type = 'text';
        inWrong.className = 'w-full px-2 py-1.5 text-xs border border-slate-300 rounded focus:border-amber-500 focus:outline-none bg-white uppercase';
        inWrong.placeholder = 'Wrong / Erroneous Data';
        inWrong.value = row.wrongData;
        inWrong.oninput = (e) => {
          corrections[index].wrongData = e.target.value;
          renderPreviewCorrectionRows();
        };
        tdWrong.appendChild(inWrong);

        // Correct Data Input
        const tdCorrect = document.createElement('td');
        tdCorrect.className = 'py-2 px-3';
        const inCorrect = document.createElement('input');
        inCorrect.type = 'text';
        inCorrect.className = 'w-full px-2 py-1.5 text-xs border border-slate-300 rounded focus:border-amber-500 focus:outline-none bg-white font-semibold uppercase';
        inCorrect.placeholder = 'Correct / Exact Data';
        inCorrect.value = row.correctData;
        inCorrect.oninput = (e) => {
          corrections[index].correctData = e.target.value;
          renderPreviewCorrectionRows();
        };
        tdCorrect.appendChild(inCorrect);

        // Delete Row Action
        const tdAction = document.createElement('td');
        tdAction.className = 'py-2 px-2 text-center';
        const btnDel = document.createElement('button');
        btnDel.type = 'button';
        btnDel.className = 'text-rose-500 hover:text-rose-700 disabled:opacity-30 p-1 rounded transition';
        btnDel.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>`;
        
        if (corrections.length === 1) {
          btnDel.disabled = true;
        } else {
          btnDel.onclick = () => {
            corrections.splice(index, 1);
            renderFormCorrectionRows();
            renderPreviewCorrectionRows();
          };
        }
        tdAction.appendChild(btnDel);

        tr.appendChild(tdCol);
        tr.appendChild(tdWrong);
        tr.appendChild(tdCorrect);
        tr.appendChild(tdAction);

        tbody.appendChild(tr);
      });
    }

    // Add Row Click Handler
    function addCorrectionRow() {
      corrections.push({
        columnNo: '',
        wrongData: '',
        correctData: ''
      });
      renderFormCorrectionRows();
      renderPreviewCorrectionRows();
    }

    // Render Preview Table on Page 2
    function renderPreviewCorrectionRows() {
      const outTbody = document.getElementById('out-corrections-body');
      outTbody.innerHTML = '';

      corrections.forEach(row => {
        const tr = document.createElement('tr');
        tr.className = 'border-b border-black';
        tr.innerHTML = `
          <td class="border border-black py-2.5 px-3 font-semibold whitespace-pre-wrap">${escapeHtml(row.columnNo || '-')}</td>
          <td class="border border-black py-2.5 px-4 font-mono uppercase text-red-900 tracking-wide">${escapeHtml(row.wrongData || '-')}</td>
          <td class="border border-black py-2.5 px-4 font-bold uppercase text-black tracking-wide">${escapeHtml(row.correctData || '-')}</td>
        `;
        outTbody.appendChild(tr);
      });
    }

    function updateAffidavit() {
      const getVal = (id) => (document.getElementById(id) ? document.getElementById(id).value.trim() : '');

      document.getElementById('out-deponentName').innerText = getVal('deponentName') || 'SATISH';
      document.getElementById('out-deponentAge').innerText = getVal('deponentAge') || 'Major';
      document.getElementById('out-deponentOccupation').innerText = getVal('deponentOccupation') || 'Private Services';
      document.getElementById('out-deponentAddress').innerText = getVal('deponentAddress') || '#T2, Parnali Apartment, Roy Road, Tilakwadi, Belgaum, Belagavi, Karnataka 590006';
      
      document.getElementById('out-certRelation').innerText = getVal('certRelation') || 'son';
      document.getElementById('out-issuingAuthority').innerText = getVal('issuingAuthority') || 'City Corporation of Belagavi';
      document.getElementById('out-regNumber').innerText = getVal('regNumber') || '803033/T/B/2014/005020';
      document.getElementById('out-regDate').innerText = getVal('regDate') || '28/03/2014';
      document.getElementById('out-dobDate').innerText = getVal('dobDate') || '16/03/2014';
      
      const executionPlace = getVal('executionPlace') || 'Belagavi';
      const affidavitDate = getVal('affidavitDate') || '08/10/2026';

      document.getElementById('out-executionPlace').innerText = executionPlace;
      document.getElementById('out-place-footer').innerText = executionPlace;
      document.getElementById('out-date-footer').innerText = affidavitDate;

      renderPreviewCorrectionRows();
    }

    function updateTopMargin(val) {
      const spacer = document.getElementById('stamp-space');
      const text = document.getElementById('topMarginValue');
      const numericVal = Math.min(100, Math.max(0, parseInt(val) || 0));

      if (spacer) spacer.style.height = `${numericVal}mm`;
      if (text) text.innerText = `${numericVal} mm`;
    }

    function setStampPreset(val) {
      const slider = document.getElementById('topMarginSlider');
      if (slider) slider.value = val;
      updateTopMargin(val);
    }

    function updateDocumentScale(val) {
      const numericVal = parseInt(val) || 96;
      const ratio = numericVal / 100;
      document.documentElement.style.setProperty('--doc-scale', ratio);
      
      const scaleValueElem = document.getElementById('scaleValue');
      if (scaleValueElem) scaleValueElem.innerText = `${numericVal}%`;

      document.querySelectorAll('.page-sheet').forEach(sheet => {
        sheet.style.transform = `scale(${ratio})`;
        sheet.style.transformOrigin = 'top center';
      });
    }

    function setDocumentScale(val) {
      const slider = document.getElementById('scaleSlider');
      if (slider) slider.value = val;
      updateDocumentScale(val);
    }

    function resetToDefaultData() {
      Object.keys(defaultData).forEach(key => {
        const el = document.getElementById(key);
        if (el) el.value = defaultData[key];
      });

      corrections = [
        {
          columnNo: "6. FATHER NAME",
          wrongData: "SATISH CHANAGOND",
          correctData: "SATISH"
        }
      ];

      setStampPreset(0);
      setDocumentScale(96);
      setFontSize(15);
      renderFormCorrectionRows();
      updateAffidavit();
    }

    function scrollToPreview() {
      document.getElementById('preview-container').scrollIntoView({ behavior: 'smooth' });
    }

    function handlePrint() {
      updateAffidavit();
      window.print();
    }

    document.addEventListener('DOMContentLoaded', () => {
      if (window.lucide) {
        lucide.createIcons();
      }

      // Attach event listener directly to Add Row button
      const btnAddRow = document.getElementById('btnAddRow');
      if (btnAddRow) {
        btnAddRow.addEventListener('click', addCorrectionRow);
      }

      setFontSize(15);
      renderFormCorrectionRows();
      updateAffidavit();
      updateDocumentScale(96);

      const inputIds = [
        'deponentName', 'deponentAge', 'deponentOccupation', 'deponentAddress',
        'certRelation', 'issuingAuthority', 'regNumber', 'regDate', 'dobDate',
        'executionPlace', 'affidavitDate'
      ];

      inputIds.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
          element.addEventListener('input', updateAffidavit);
        }
      });
    });
  </script>
</body>
</html>