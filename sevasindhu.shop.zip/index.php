<?php
// Handle Backend API Requests via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (ob_get_length()) ob_clean();
    header('Content-Type: application/json; charset=utf-8');

    $inputJSON = file_get_contents('php://input');
    $data = json_decode($inputJSON, true);

    $response = [
        "status" => "400",
        "message" => "Invalid action or request payload."
    ];

    if (is_array($data) && isset($data['action'])) {
        $action = $data['action'];

        switch ($action) {
            case 'voter_link':
                $epic = trim($data['epic'] ?? $data['epic_number'] ?? '');
                $mobile = trim($data['mobile'] ?? $data['mobile_number'] ?? '');

                if (!empty($epic) && !empty($mobile)) {
                    $response = [
                        "status" => "200",
                        "message" => "Mobile Link Request Submitted Successfully",
                        "epic" => $epic,
                        "mobile" => $mobile,
                        "ref_id" => "REF" . rand(100000, 999999),
                        "application_no" => "APP" . rand(10000000, 99999999),
                        "balance_left" => "450.00"
                    ];
                } else {
                    $response = ["status" => "400", "message" => "Missing EPIC Number or Mobile Number."];
                }
                break;

            case 'find_pan':
                $aadhaarNo = trim($data['aadhaar_number'] ?? $data['aadhaar_no'] ?? '');

                if (!empty($aadhaarNo)) {
                    $response = [
                        "status" => "200",
                        "message" => "PAN details retrieved successfully.",
                        "pan" => "ABCDE" . rand(1000, 9999) . "F"
                    ];
                } else {
                    $response = ["status" => "400", "message" => "Aadhaar number is required."];
                }
                break;

            default:
                $response = [
                    "status" => "200",
                    "message" => "Form Submitted Successfully",
                    "ref_id" => "REQ-" . rand(100000, 999999)
                ];
                break;
        }
    }

    echo json_encode($response);
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nemmadi Digital Services Portal</title>
    <style>
        :root {
            --bg-color: #0b0f19;
            --card-bg: #111827;
            --card-hover: #1f2937;
            --text-primary: #f3f4f6;
            --text-secondary: #9ca3af;
            --border-color: #374151;
            --accent: #38bdf8;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background-color: var(--bg-color);
            color: var(--text-primary);
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            min-height: 100vh;
        }

        .container {
            max-width: 900px;
            width: 100%;
        }

        header {
            text-align: center;
            margin-bottom: 24px;
        }

        h1 {
            color: var(--accent);
            font-size: 1.85rem;
            margin-bottom: 6px;
        }

        .top-nav-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            padding: 10px 16px;
            border-radius: 10px;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 12px;
            position: relative;
        }

        .breadcrumb {
            display: flex;
            gap: 8px;
            align-items: center;
            font-size: 0.9rem;
            color: var(--text-secondary);
        }

        .breadcrumb span {
            cursor: pointer;
            color: var(--accent);
        }

        .breadcrumb span:hover {
            text-decoration: underline;
        }

        .search-container {
            display: flex;
            gap: 6px;
            align-items: center;
            position: relative;
        }

        .search-container input {
            padding: 8px 12px;
            background: var(--bg-color);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            color: var(--text-primary);
            font-size: 0.85rem;
            outline: none;
            width: 210px;
            transition: width 0.3s, border-color 0.3s;
        }

        .search-container input:focus {
            width: 250px;
            border-color: var(--accent);
        }

        .search-btn {
            background: var(--accent);
            color: #000;
            border: none;
            padding: 8px 14px;
            font-weight: 600;
            font-size: 0.85rem;
            border-radius: 6px;
            cursor: pointer;
        }

        .search-btn:hover {
            opacity: 0.9;
        }

        .search-results-box {
            position: absolute;
            top: 100%;
            right: 0;
            width: 330px;
            max-height: 350px;
            overflow-y: auto;
            background: var(--card-bg);
            border: 1px solid var(--accent);
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.6);
            margin-top: 8px;
            z-index: 1000;
            display: none;
        }

        .search-result-item {
            padding: 10px 14px;
            border-bottom: 1px solid var(--border-color);
            cursor: pointer;
            transition: background 0.2s;
        }

        .search-result-item:last-child {
            border-bottom: none;
        }

        .search-result-item:hover {
            background: var(--card-hover);
        }

        .search-result-item .res-title {
            color: var(--accent);
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 2px;
        }

        .search-result-item .res-category {
            color: var(--text-secondary);
            font-size: 0.75rem;
        }

        .search-no-result {
            padding: 12px;
            text-align: center;
            color: var(--text-secondary);
            font-size: 0.85rem;
        }

        .view {
            display: none;
        }

        .view.active {
            display: block;
        }

        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
            gap: 20px;
        }

        .service-logo-card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 14px;
            padding: 22px 14px;
            text-align: center;
            cursor: pointer;
            transition: transform 0.2s ease, border-color 0.2s ease, box-shadow 0.2s ease;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            position: relative;
        }

        .service-logo-card:hover {
            background: var(--card-hover);
            transform: translateY(-4px);
            border-color: var(--accent);
            box-shadow: 0 8px 20px rgba(56, 189, 248, 0.12);
        }

        .round-logo {
            width: 68px;
            height: 68px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 12px;
            background: rgba(255, 255, 255, 0.04);
            border: 2px solid var(--border-color);
            transition: all 0.3s ease;
        }

        .round-logo svg {
            width: 32px;
            height: 32px;
            transition: transform 0.2s ease;
        }

        .service-logo-card:hover .round-logo {
            transform: scale(1.05);
            background: rgba(255, 255, 255, 0.08);
        }

        .service-logo-card:hover .round-logo svg {
            transform: scale(1.05);
        }

        .service-logo-card h3 {
            margin: 0 0 6px 0;
            font-size: 0.95rem;
            font-weight: 600;
        }

        .service-logo-card p {
            margin: 0;
            font-size: 0.75rem;
            color: var(--text-secondary);
            line-height: 1.3;
        }

        .work-panel {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 24px;
        }

        .work-panel h2 {
            margin-top: 0;
            color: var(--accent);
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-group label {
            display: block;
            font-size: 0.85rem;
            color: var(--text-secondary);
            margin-bottom: 6px;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 10px 14px;
            background: var(--bg-color);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            color: var(--text-primary);
            box-sizing: border-box;
            font-size: 0.9rem;
        }

        .btn-action {
            background: var(--accent);
            color: #000;
            border: none;
            padding: 12px 20px;
            font-weight: 600;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            transition: opacity 0.2s;
        }

        .btn-action:hover {
            opacity: 0.9;
        }

        .back-btn {
            background: transparent;
            border: 1px solid var(--border-color);
            color: var(--text-secondary);
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            margin-bottom: 16px;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .back-btn:hover {
            background: var(--card-hover);
            color: var(--text-primary);
        }

        .response-box {
            margin-top: 20px;
            padding: 16px;
            border-radius: 8px;
            display: none;
        }

        .response-success {
            background-color: #064e3b;
            border: 1px solid #059669;
            color: #a7f3d0;
        }

        .response-error {
            background-color: #7f1d1d;
            border: 1px solid #dc2626;
            color: #fecaca;
        }

        #working-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background-color: #000000;
            color: #ffffff;
            z-index: 99999;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            padding: 20px;
        }

        #working-overlay h2 {
            font-size: 2rem;
            margin: 0 0 16px 0;
            font-weight: 700;
            letter-spacing: 1px;
            color: #ffffff;
        }

        #working-overlay p {
            font-size: 1.1rem;
            color: #aaaaaa;
            margin: 0 0 24px 0;
        }

        .countdown-badge {
            display: inline-block;
            font-size: 3rem;
            font-weight: 800;
            width: 80px;
            height: 80px;
            line-height: 76px;
            border-radius: 50%;
            border: 3px solid #ffffff;
            color: #ffffff;
            background: #000000;
        }
    </style>
</head>
<body>

<div id="working-overlay">
    <h2 id="working-title">We are working on it...</h2>
    <p>Please wait while we prepare this service for you.</p>
    <div class="countdown-badge" id="countdown-timer">3</div>
</div>

<div class="container">
    <header>
        <h1>Nemmadi Digital Services</h1>
        <p style="color: var(--text-secondary); margin: 0;">Select a service category below to proceed</p>
    </header>

    <div class="top-nav-bar">
        <div class="breadcrumb" id="breadcrumb">
            <span onclick="showMainView()">Home</span>
        </div>
        <div class="search-container">
            <input type="text" id="portal-search-input" placeholder="Search service..." oninput="handleSearchInput()" onkeydown="if(event.key==='Enter') executeFirstSearchMatch();" />
            <button class="search-btn" onclick="executeFirstSearchMatch()">Search</button>
            <div id="search-results-box" class="search-results-box"></div>
        </div>
    </div>

    <!-- VIEW 1: Main Services -->
    <div id="main-view" class="view active">
        <div class="services-grid" id="main-grid-container"></div>
    </div>

    <!-- VIEW 2: Sub-Services Grid -->
    <div id="sub-view" class="view">
        <button class="back-btn" onclick="showMainView()">← Back to Main Services</button>
        <h2 id="sub-service-title" style="margin-bottom: 16px; font-size: 1.3rem;"></h2>
        <div class="services-grid" id="sub-service-container"></div>
    </div>

    <!-- VIEW 3: Service Work Panel -->
    <div id="work-view" class="view">
        <button class="back-btn" onclick="goBackToSub()">← Back to Sub-Services</button>
        <div class="work-panel">
            <h2 id="work-title"></h2>
            <p id="work-desc" style="color: var(--text-secondary); margin-bottom: 20px;"></p>

            <form id="service-form" onsubmit="handleFormSubmit(event)">
                <div id="form-fields-container"></div>
                <button type="submit" class="btn-action">Proceed & Submit Work</button>
            </form>

            <div id="response-container" class="response-box"></div>
        </div>
    </div>
</div>

<script>
    // SVG Logos defined as reusable strings
    const SVG_ICONS = {
        fingerprint: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4"/><path d="M14 13.12c0 2.38 0 6.38-1 8.88"/><path d="M2 12a10 10 0 0 1 18-6"/><path d="M2 16h.01"/><path d="M21.8 16c.2-2 .131-5.354 0-6"/><path d="M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2"/><path d="M8.65 22c.21-.66.45-1.32.57-2"/><path d="M9 6.8a6 6 0 0 1 9 5.2v2"/></svg>`,
        stamp: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 22h14"/><path d="M19.27 13.73A2.5 2.5 0 0 0 17.5 13h-11A2.5 2.5 0 0 0 4 15.5V17a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-1.5c0-.66-.26-1.3-.73-1.77Z"/><path d="M14 13V8.5C14 7.12 12.88 6 11.5 6h-1C9.12 6 8 7.12 8 8.5V13"/></svg>`,
        pan_card: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/><circle cx="7" cy="15" r="1.5"/><line x1="12" x2="18" y1="15" y2="15"/></svg>`,
        voter_box: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 12 2 2 4-4"/><path d="M5 7c0-1.1.9-2 2-2h10a2 2 0 0 1 2 2v12H5V7Z"/><path d="M22 19H2"/></svg>`,
        ration_grain: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 22 16 8"/><path d="M3.47 12.53 5 11l1.53 1.53a3.5 3.5 0 0 1 0 4.94L5 19l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z"/><path d="M7.47 8.53 9 7l1.53 1.53a3.5 3.5 0 0 1 0 4.94L9 15l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z"/><path d="M11.47 4.53 13 3l1.53 1.53a3.5 3.5 0 0 1 0 4.94L13 11l-1.53-1.53a3.5 3.5 0 0 1 0-4.94Z"/><path d="M20 2h2v2a4 4 0 0 1-4 4h-2V6a4 4 0 0 1 4-4Z"/></svg>`,
        book_edit: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5Z"/><path d="m14 6 4 4"/><path d="m11 9 4-4 2 2-4 4H11V9Z"/></svg>`,
        camera_photo: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>`,
        crop_resize: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2v14a2 2 0 0 0 2 2h14"/><path d="M18 22V8a2 2 0 0 0-2-2H2"/></svg>`,
        gazette_badge: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="6"/><path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11"/></svg>`,
        shield_army: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/></svg>`,
        download: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>`,
        search_id: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" x2="16.65" y1="21" y2="16.65"/><path d="M11 8v6"/><path d="M8 11h6"/></svg>`,
        palette: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.992 6.012 17.499 2 12 2z"/></svg>`,
        link_icon: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>`,
        document: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/><polyline points="14 2 14 8 20 8"/></svg>`,
        user_heart: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>`,
        refresh: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 21h5v-5"/></svg>`,
        home_key: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>`,
        user_check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><polyline points="16 11 18 13 22 9"/></svg>`,
        file_text: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>`
    };

    const portalData = {
        "aadhaar": {
            "title": "Aadhaar Card",
            "icon": SVG_ICONS.fingerprint,
            "color": "#38bdf8",
            "subservices": {
                "download": {
                    "name": "Download",
                    "icon": SVG_ICONS.download,
                    "desc": "Official e-Aadhaar download portal.",
                    "type": "link",
                    "url": "https://myaadhaar.uidai.gov.in/"
                },
                "find_pan": {
                    "name": "PAN Find",
                    "icon": SVG_ICONS.search_id,
                    "desc": "Locate or verify linked PAN details.",
                    "type": "form",
                    "fields": ["Aadhaar Number"]
                },
                "colour_card": {
                    "name": "Colour Card Print",
                    "icon": SVG_ICONS.palette,
                    "desc": "Generate and print colour card layout.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/colouraadhar.html"
                }
            }
        },
        "uidai_stamp": {
            "title": "UIDAI E-Stamp",
            "icon": SVG_ICONS.stamp,
            "color": "#3b82f6",
            "subservices": {
                "annexure_d": {
                    "name": "Annexure D (Marriage)",
                    "icon": SVG_ICONS.document,
                    "desc": "Format for Annexure D after marriage.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/AnnexD.php"
                },
                "annexure_c": {
                    "name": "Annexure I (DOB)",
                    "icon": SVG_ICONS.document,
                    "desc": "Format for DOB self declaration.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/AnnexI.php"
                },
                "annexure_ia_child": {
                    "name": "ANNEXURE IA FOR DOB CHILDREN",
                    "icon": SVG_ICONS.document,
                    "desc": "Format for DOB self declaration for children.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/AnnexIAChild.php"
                },
                "reactivation": {
                    "name": "Maharashtra Gazzette Form",
                    "icon": SVG_ICONS.refresh,
                    "desc": "Request portal for Aadhaar reactivation.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/mhgazform.php"
                },
                "mh_gazette_estamp": {
                    "name": "Maharashtra Gazette E-Stamp",
                    "icon": SVG_ICONS.gazette_badge,
                    "desc": "Maharashtra Gazette E-Stamp portal.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/mhestamp"
                }
            }
        },
        "estamp_formats": {
            "title": "E STAMP FORMATS",
            "icon": SVG_ICONS.stamp,
            "color": "#06b6d4",
            "subservices": {
                "birth_correction": {
                    "name": "BIRTH CORRECTION",
                    "icon": SVG_ICONS.document,
                    "desc": "Affidavit format for birth certificate correction.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/birthaffidavit.php"
                },
                "rent_agreement": {
                    "name": "RENT AGREEMENT",
                    "icon": SVG_ICONS.home_key,
                    "desc": "Residential and commercial rent agreement drafting.",
                    "type": "maintenance"
                },
                "double_pan_cancellation": {
                    "name": "DOUBLE PAN CARD CANCELLATION",
                    "icon": SVG_ICONS.pan_card,
                    "desc": "Surrender and cancellation affidavit for dual PAN.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/pancancel.php"
                },
                "same_person_double_name": {
                    "name": "SAME PERSON DOUBLE NAME",
                    "icon": SVG_ICONS.user_check,
                    "desc": "One and the same person affidavit format.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/samename.php"
                },
                "esi_health_claim": {
                    "name": "ESI HEALTH CLAIM AFFIDAVIT",
                    "icon": SVG_ICONS.file_text,
                    "desc": "Affidavit for ESI reimbursement and medical claims.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/esi.php"
                }
            }
        },
        "pan": {
            "title": "PAN Card",
            "icon": SVG_ICONS.pan_card,
            "color": "#f43f5e",
            "subservices": {
                "download": {
                    "name": "e-PAN Download",
                    "icon": SVG_ICONS.download,
                    "desc": "Instant download of e-PAN card PDF.",
                    "type": "form",
                    "fields": ["PAN Number", "Date of Birth"]
                },
                "find_aadhaar": {
                    "name": "Verify Linking Status",
                    "icon": SVG_ICONS.link_icon,
                    "desc": "Find and verify linked status.",
                    "type": "form",
                    "fields": ["PAN Number", "Registered Mobile Number"]
                }
            }
        },
        "voter": {
            "title": "Voter ID",
            "icon": SVG_ICONS.voter_box,
            "color": "#10b981",
            "subservices": {
                "mobile_link": {
                    "name": "Mobile Link / Update",
                    "icon": SVG_ICONS.link_icon,
                    "desc": "Link or update mobile number to Voter ID.",
                    "type": "form",
                    "fields": ["EPIC Number", "Mobile Number"]
                },
                "download": {
                    "name": "e-EPIC Download",
                    "icon": SVG_ICONS.download,
                    "desc": "Download digital e-EPIC card.",
                    "type": "form",
                    "fields": ["EPIC Number", "Select State"]
                }
            }
        },
        "ration": {
            "title": "Ration Card",
            "icon": SVG_ICONS.ration_grain,
            "color": "#f59e0b",
            "subservices": {
                "all_in_one": {
                    "name": "All in One Ration Card Download",
                    "icon": SVG_ICONS.download,
                    "desc": "Universal portal for all region ration card downloads.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/rationmser"
                },
                "rc_upload_download": {
                    "name": "RC UPLOAD AND DOWNLOAD",
                    "icon": SVG_ICONS.palette,
                    "desc": "Upload and download color ration card layout.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/rccolour.php"
                },
                "bser": {
                    "name": "BSER Region",
                    "icon": SVG_ICONS.ration_grain,
                    "desc": "Bangalore Urban, Rural & West zones.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/bser.php"
                },
                "kser": {
                    "name": "KSER Region",
                    "icon": SVG_ICONS.ration_grain,
                    "desc": "Ballari, Kalaburgi, Raichur, Tumkur & others.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/kser.php"
                },
                "mser": {
                    "name": "MSER Region",
                    "icon": SVG_ICONS.ration_grain,
                    "desc": "Belagavi, Dharwad, Mysuru, Udupi & others.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/mser.php"
                }
            }
        },
        "manual_ration": {
            "title": "Manual Ration Card",
            "icon": SVG_ICONS.book_edit,
            "color": "#eab308",
            "type": "link",
            "url": "https://sevasindhu.shop/manualration"
        },
        "photo_maker": {
            "title": "Photo Maker",
            "icon": SVG_ICONS.camera_photo,
            "color": "#ec4899",
            "subservices": {
                "passport_photo": {
                    "name": "Passport Photo",
                    "icon": SVG_ICONS.camera_photo,
                    "desc": "Generate and print passport photo sheets.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/photomaker.html"
                },
                "marriage_photo": {
                    "name": "Marriage Photo",
                    "icon": SVG_ICONS.user_heart,
                    "desc": "Generate and print marriage photo sheets.",
                    "type": "link",
                    "url": "https://sevasindhu.shop/marriagephotomaker.html"
                }
            }
        },
        "photo_resizer": {
            "title": "Photo Resizer",
            "icon": SVG_ICONS.crop_resize,
            "color": "#a855f7",
            "type": "link",
            "url": "https://sevasindhu.shop/photoresizer"
        },
        "gazette": {
            "title": "Gazetted Form",
            "icon": SVG_ICONS.gazette_badge,
            "color": "#0d9488",
            "type": "link",
            "url": "https://sevasindhu.shop/gazette.html"
        },
        "army_self": {
            "title": "Army Declaration",
            "icon": SVG_ICONS.shield_army,
            "color": "#84cc16",
            "type": "link",
            "url": "https://sevasindhu.shop/army_self.php"
        }
    };

    let currentCategoryKey = null;
    let currentSubServiceKey = null;

    function renderMainView() {
        let gridHtml = '';
        for (const [key, cat] of Object.entries(portalData)) {
            const clickAction = cat.type === 'link' 
                ? `window.location.href='${cat.url}';` 
                : `showSubServices('${key}');`;

            gridHtml += `
                <div class="service-logo-card" onclick="${clickAction}">
                    <div class="round-logo" style="border-color: ${cat.color}; color: ${cat.color};">
                        ${cat.icon}
                    </div>
                    <h3>${cat.title}</h3>
                </div>
            `;
        }
        document.getElementById('main-grid-container').innerHTML = gridHtml;
    }

    function showMainView() {
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        document.getElementById('main-view').classList.add('active');
        document.getElementById('breadcrumb').innerHTML = '<span>Home</span>';
        currentCategoryKey = null;
        currentSubServiceKey = null;
        closeSearchResults();
    }

    function showSubServices(catKey) {
        currentCategoryKey = catKey;
        const category = portalData[catKey];
        if (!category) return;

        document.getElementById('sub-service-title').innerText = category.title + ' Services';

        let containerHtml = '';
        if (category.subservices) {
            for (const [subKey, subVal] of Object.entries(category.subservices)) {
                let clickAction = '';
                if (subVal.type === 'link') {
                    clickAction = `window.location.href='${subVal.url}';`;
                } else if (subVal.type === 'maintenance') {
                    clickAction = `triggerWorkingScreen('${subVal.name}');`;
                } else {
                    clickAction = `showWorkView('${catKey}', '${subKey}');`;
                }

                containerHtml += `
                    <div class="service-logo-card" onclick="${clickAction}">
                        <div class="round-logo" style="border-color: ${category.color}; color: ${category.color};">
                            ${subVal.icon || category.icon}
                        </div>
                        <h3>${subVal.name}</h3>
                        <p>${subVal.desc}</p>
                    </div>
                `;
            }
        }

        document.getElementById('sub-service-container').innerHTML = containerHtml;
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        document.getElementById('sub-view').classList.add('active');

        document.getElementById('breadcrumb').innerHTML = `
            <span onclick="showMainView()">Home</span> / <span>${category.title}</span>
        `;
        closeSearchResults();
    }

    function triggerWorkingScreen(serviceName) {
        const overlay = document.getElementById('working-overlay');
        const timerBadge = document.getElementById('countdown-timer');

        let timeLeft = 3;
        timerBadge.innerText = timeLeft;
        overlay.style.display = 'flex';

        const countdownInterval = setInterval(() => {
            timeLeft--;
            timerBadge.innerText = timeLeft;

            if (timeLeft <= 0) {
                clearInterval(countdownInterval);
                overlay.style.display = 'none';
                showMainView();
            }
        }, 1000);
    }

    function showWorkView(catKey, subKey) {
        currentCategoryKey = catKey;
        currentSubServiceKey = subKey;
        const subService = portalData[catKey].subservices[subKey];
        const category = portalData[catKey];

        document.getElementById('work-title').innerText = category.title + ' - ' + subService.name;
        document.getElementById('work-desc').innerText = subService.desc;

        const resBox = document.getElementById('response-container');
        resBox.style.display = 'none';
        resBox.className = 'response-box';
        resBox.innerHTML = '';

        let fieldsHtml = '';
        if (subService.fields) {
            subService.fields.forEach(field => {
                const fieldId = field.toLowerCase().replace(/[^a-z0-9]/g, '_');
                fieldsHtml += `
                    <div class="form-group">
                        <label for="${fieldId}">${field}</label>
                        <input type="text" id="${fieldId}" name="${fieldId}" placeholder="Enter ${field}" required />
                    </div>
                `;
            });
        }
        document.getElementById('form-fields-container').innerHTML = fieldsHtml;

        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        document.getElementById('work-view').classList.add('active');

        document.getElementById('breadcrumb').innerHTML = `
            <span onclick="showMainView()">Home</span> / 
            <span onclick="showSubServices('${catKey}')">${category.title}</span> / 
            <span>${subService.name}</span>
        `;
        closeSearchResults();
    }

    function handleFormSubmit(event) {
        event.preventDefault();
        const resBox = document.getElementById('response-container');
        resBox.style.display = 'none';

        let payload = { action: currentSubServiceKey };
        const inputs = document.querySelectorAll('#form-fields-container input, #form-fields-container select');

        inputs.forEach(input => {
            payload[input.name] = input.value.trim();
        });

        if (currentSubServiceKey === 'voter_link') {
            payload.epic = payload.epic_number || payload.epic || '';
            payload.mobile = payload.mobile_number || payload.mobile || '';
            if (!payload.epic || !payload.mobile) {
                alert('Please enter both EPIC Number and Mobile Number.');
                return;
            }
        }

        if (currentSubServiceKey === 'find_pan') {
            payload.aadhaar_number = payload.aadhaar_number || payload.aadhaar_no || '';
            if (!payload.aadhaar_number) {
                alert('Please enter a valid Aadhaar Number.');
                return;
            }
        }

        resBox.className = "response-box response-success";
        resBox.style.display = "block";
        resBox.innerHTML = "<p>Processing request, please wait...</p>";

        fetch(window.location.href, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
        .then(response => response.json())
        .then(data => handleResponse(data, resBox))
        .catch(error => handleFetchError(error, resBox));
    }

    function handleResponse(data, resBox) {
        if (data.status === "200" || data.status === 200) {
            resBox.className = "response-box response-success";
            resBox.innerHTML = `
                <strong style="font-size: 1.1rem;">✓ ${data.message || 'Request Processed Successfully'}</strong>
                <hr style="border-color: #059669; margin: 10px 0;">
                ${data.ref_id ? `<p style="margin: 4px 0;"><strong>Reference ID:</strong> ${data.ref_id}</p>` : ''}
                ${data.application_no ? `<p style="margin: 4px 0;"><strong>Application No:</strong> ${data.application_no}</p>` : ''}
                ${data.pan ? `<p style="margin: 4px 0;"><strong>Linked PAN:</strong> ${data.pan}</p>` : ''}
                ${data.balance_left ? `<p style="margin: 4px 0;"><strong>Balance Remaining:</strong> ₹${data.balance_left}</p>` : ''}
            `;
        } else {
            resBox.className = "response-box response-error";
            resBox.innerHTML = `
                <strong>✗ Request Failed</strong>
                <p style="margin-top: 5px;">${data.message || 'Failed to submit request.'}</p>
            `;
        }
    }

    function handleFetchError(error, resBox) {
        console.error('API Error:', error);
        resBox.className = "response-box response-error";
        resBox.style.display = "block";
        resBox.innerHTML = `<strong>✗ Error</strong><p>Unable to connect to backend server.</p>`;
    }

    function goBackToSub() {
        if (currentCategoryKey) {
            showSubServices(currentCategoryKey);
        } else {
            showMainView();
        }
    }

    function handleSearchInput() {
        const query = document.getElementById('portal-search-input').value.trim().toLowerCase();
        const resultsBox = document.getElementById('search-results-box');

        if (!query) {
            closeSearchResults();
            return;
        }

        let matches = [];

        for (const [catKey, catVal] of Object.entries(portalData)) {
            if (catVal.title.toLowerCase().includes(query)) {
                matches.push({
                    title: catVal.title,
                    category: 'Main Category',
                    action: () => {
                        if (catVal.type === 'link') {
                            window.location.href = catVal.url;
                        } else {
                            showSubServices(catKey);
                        }
                    }
                });
            }

            if (catVal.subservices) {
                for (const [subKey, subVal] of Object.entries(catVal.subservices)) {
                    if (subVal.name.toLowerCase().includes(query) || (subVal.desc && subVal.desc.toLowerCase().includes(query))) {
                        matches.push({
                            title: `${catVal.title} → ${subVal.name}`,
                            category: subVal.desc || '',
                            action: () => {
                                if (subVal.type === 'link') {
                                    window.location.href = subVal.url;
                                } else if (subVal.type === 'maintenance') {
                                    triggerWorkingScreen(subVal.name);
                                } else {
                                    showWorkView(catKey, subKey);
                                }
                            }
                        });
                    }
                }
            }
        }

        renderSearchResults(matches);
    }

    function renderSearchResults(matches) {
        const resultsBox = document.getElementById('search-results-box');
        if (matches.length === 0) {
            resultsBox.innerHTML = '<div class="search-no-result">No matching services found</div>';
            resultsBox.style.display = 'block';
            return;
        }

        resultsBox.innerHTML = '';
        matches.forEach((item) => {
            const div = document.createElement('div');
            div.className = 'search-result-item';
            div.innerHTML = `
                <div class="res-title">${item.title}</div>
                <div class="res-category">${item.category}</div>
            `;
            div.addEventListener('click', () => {
                item.action();
                closeSearchResults();
            });
            resultsBox.appendChild(div);
        });

        resultsBox.style.display = 'block';
    }

    function executeFirstSearchMatch() {
        const firstItem = document.querySelector('.search-result-item');
        if (firstItem) {
            firstItem.click();
        }
    }

    function closeSearchResults() {
        const resultsBox = document.getElementById('search-results-box');
        resultsBox.style.display = 'none';
        resultsBox.innerHTML = '';
    }

    document.addEventListener('mousedown', function(e) {
        const searchContainer = document.querySelector('.search-container');
        if (searchContainer && !searchContainer.contains(e.target)) {
            closeSearchResults();
        }
    });

    renderMainView();
</script>

</body>
</html>