<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nemmadi Digital Services Portal</title>
    <style>
        :root {
            --bg-color: #0b0f19;
            --card-bg: #111827;
            --card-hover: #1f2937;
            --text-primary: #f3f4f6;
            --text-secondary: #9ca3af;
            --border-color: #374151;
            --accent: #38bdf8;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background-color: var(--bg-color);
            color: var(--text-primary);
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            min-height: 100vh;
        }

        .container {
            max-width: 800px;
            width: 100%;
        }

        header {
            text-align: center;
            margin-bottom: 30px;
        }

        h1 {
            color: var(--accent);
            font-size: 1.8rem;
            margin-bottom: 8px;
        }

        .breadcrumb {
            display: flex;
            gap: 8px;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
            color: var(--text-secondary);
            margin-bottom: 24px;
        }

        .breadcrumb span {
            cursor: pointer;
            color: var(--accent);
        }

        .breadcrumb span:hover {
            text-decoration: underline;
        }

        .view {
            display: none;
        }

        .view.active {
            display: block;
        }

        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
            gap: 24px;
            justify-items: center;
        }

        .service-logo-card {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 16px;
            padding: 24px 16px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s ease;
            width: 100%;
            box-sizing: border-box;
            text-decoration: none;
            color: inherit;
            display: block;
        }

        .service-logo-card:hover {
            background: var(--card-hover);
            transform: translateY(-4px);
            border-color: var(--accent);
            box-shadow: 0 10px 20px rgba(56, 189, 248, 0.1);
        }

        .round-logo {
            width: 72px;
            height: 72px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            font-weight: 700;
            letter-spacing: 0.5px;
            margin: 0 auto 12px auto;
            background: rgba(255, 255, 255, 0.05);
            border: 2px solid var(--border-color);
            color: var(--text-primary);
            transition: border-color 0.3s, color 0.3s;
        }

        .service-logo-card:hover .round-logo {
            border-color: var(--accent);
            color: var(--accent);
        }

        .service-logo-card h3 {
            margin: 0 0 6px 0;
            font-size: 0.95rem;
            font-weight: 600;
        }

        .service-logo-card p {
            margin: 0;
            font-size: 0.75rem;
            color: var(--text-secondary);
            line-height: 1.2;
        }

        .work-panel {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 24px;
        }

        .work-panel h2 {
            margin-top: 0;
            color: var(--accent);
        }

        .form-group {
            margin-bottom: 16px;
        }

        .form-group label {
            display: block;
            font-size: 0.85rem;
            color: var(--text-secondary);
            margin-bottom: 6px;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 10px 14px;
            background: var(--bg-color);
            border: 1px solid var(--border-color);
            border-radius: 6px;
            color: var(--text-primary);
            box-sizing: border-box;
        }

        .btn-action {
            background: var(--accent);
            color: #000;
            border: none;
            padding: 12px 20px;
            font-weight: 600;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            transition: opacity 0.2s;
        }

        .btn-action:hover {
            opacity: 0.9;
        }

        .back-btn {
            background: transparent;
            border: 1px solid var(--border-color);
            color: var(--text-secondary);
            padding: 8px 16px;
            border-radius: 6px;
            cursor: pointer;
            margin-bottom: 16px;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .back-btn:hover {
            background: var(--card-hover);
            color: var(--text-primary);
        }
    </style>
</head>
<body>

<div class="container">
    <header>
        <h1>Nemmadi Digital Services</h1>
        <p style="color: var(--text-secondary); margin: 0;">Select a service category below to proceed</p>
    </header>

    <div class="breadcrumb" id="breadcrumb">
        <span onclick="showMainView()">Home</span>
    </div>

    <!-- VIEW 1: Main Services -->
    <div id="main-view" class="view active">
        <div class="services-grid" id="main-grid-container"></div>
    </div>

    <!-- VIEW 2: Sub-Services Grid -->
    <div id="sub-view" class="view">
        <button class="back-btn" onclick="showMainView()">← Back to Main Services</button>
        <h2 id="sub-service-title" style="margin-bottom: 16px; font-size: 1.3rem;"></h2>
        <div class="services-grid" id="sub-service-container"></div>
    </div>

    <!-- VIEW 3: Service Work / Action Panel -->
    <div id="work-view" class="view">
        <button class="back-btn" onclick="goBackToSub()">← Back to Sub-Services</button>
        <div class="work-panel">
            <h2 id="work-title"></h2>
            <p id="work-desc" style="color: var(--text-secondary); margin-bottom: 20px;"></p>
            
            <form onsubmit="handleFormSubmit(event)">
                <div id="form-fields-container"></div>
                <button type="submit" class="btn-action">Proceed & Submit Work</button>
            </form>
        </div>
    </div>
</div>

<script>
    const portalData = {
        "aadhaar": {
            "title": "Aadhaar Card",
            "icon": "UIDAI",
            "color": "#38bdf8",
            "subservices": {
                "download": {
                    "name": "Download",
                    "short_label": "PDF",
                    "desc": "Official e-Aadhaar download portal.",
                    "type": "link",
                    "url": "https://myaadhaar.uidai.gov.in/"
                },
                "find_pan": {
                    "name": "PAN Find",
                    "short_label": "FIND",
                    "desc": "Locate or verify linked PAN details.",
                    "type": "form",
                    "fields": ["Aadhaar Number"]
                },
                "colour_card": {
                    "name": "Aadhar Colour Card",
                    "short_label": "COLOUR",
                    "desc": "Generate and print colour Aadhar card layout.",
                    "type": "link",
                    "url": "https://sevasindhu.tech/colouraadhar.html"
                }
            }
        },
        "pan": {
            "title": "PAN Card",
            "icon": "INCOME",
            "color": "#f43f5e",
            "subservices": {
                "download": {
                    "name": "Download",
                    "short_label": "e-PAN",
                    "desc": "Instant download of e-PAN card PDF.",
                    "type": "form",
                    "fields": ["PAN Number", "Date of Birth"]
                },
                "find_aadhaar": {
                    "name": "ID Find",
                    "short_label": "LINK",
                    "desc": "Find and verify linked status.",
                    "type": "form",
                    "fields": ["PAN Number", "Registered Mobile Number"]
                }
            }
        },
        "voter": {
            "title": "Voter ID",
            "icon": "ECI",
            "color": "#10b981",
            "subservices": {
                "mobile_link": {
                    "name": "Mobile Link",
                    "short_label": "MOB",
                    "desc": "Link or update mobile number.",
                    "type": "form",
                    "fields": ["EPIC Number", "New Mobile Number", "OTP Verification"]
                },
                "download": {
                    "name": "Download",
                    "short_label": "EPIC",
                    "desc": "Download digital e-EPIC card.",
                    "type": "form",
                    "fields": ["EPIC Number", "Select State"]
                }
            }
        },
        "ration": {
            "title": "Ration Card",
            "icon": "FOOD",
            "color": "#f59e0b",
            "subservices": {
                "bser": {
                    "name": "BSER",
                    "short_label": "BSER",
                    "desc": "Bangalore, Bangalore Rural, Bangalore West",
                    "type": "link",
                    "url": "https://sevasindhu.shop/bser.php"
                },
                "kser": {
                    "name": "KSER",
                    "short_label": "KSER",
                    "desc": "Ballari, Bidar, Chitradurga, Davanagere, Kalaburgi, Kolar, Koppal, Raichur, Shimoga, Tumkur, Chikkaballapura, Ramanagar, Yadgir, Vijayanagara",
                    "type": "link",
                    "url": "https://sevasindhu.shop/kser.php"
                },
                "mser": {
                    "name": "MSER",
                    "short_label": "MSER",
                    "desc": "Bagalkote, Belagavi, Vijayapura, Chamarajanagar, Chikamagalur, Dakshina Kannada, Dharwad, Gadag, Haveri, Hassan, Kodagu, Mandya, Mysuru, Udupi, Uttara Kannada",
                    "type": "link",
                    "url": "https://sevasindhu.shop/mser.php"
                }
            }
        },
        "passport": {
            "title": "Passport Photo Maker",
            "icon": "PHOTO",
            "color": "#ec4899",
            "type": "link",
            "url": "https://sevasindhu.tech/photomaker.html"
        }
    };

    let currentCategoryKey = null;
    let currentSubServiceKey = null;

    function renderMainView() {
        let gridHtml = '';
        for (const [key, cat] of Object.entries(portalData)) {
            if (cat.type === 'link') {
                gridHtml += `
                    <a href="${cat.url}" class="service-logo-card">
                        <div class="round-logo" style="border-color: ${cat.color};">
                            ${cat.icon}
                        </div>
                        <h3>${cat.title}</h3>
                    </a>
                `;
            } else {
                gridHtml += `
                    <div class="service-logo-card" onclick="showSubServices('${key}')">
                        <div class="round-logo" style="border-color: ${cat.color};">
                            ${cat.icon}
                        </div>
                        <h3>${cat.title}</h3>
                    </div>
                `;
            }
        }
        document.getElementById('main-grid-container').innerHTML = gridHtml;
    }

    function showMainView() {
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        document.getElementById('main-view').classList.add('active');
        document.getElementById('breadcrumb').innerHTML = '<span>Home</span>';
    }

    function showSubServices(catKey) {
        currentCategoryKey = catKey;
        const category = portalData[catKey];
        
        document.getElementById('sub-service-title').innerText = category.title + ' Services';
        
        let containerHtml = '';
        for (const [subKey, subVal] of Object.entries(category.subservices)) {
            if (subVal.type === 'link') {
                containerHtml += `
                    <a href="${subVal.url}" class="service-logo-card">
                        <div class="round-logo" style="border-color: ${category.color};">
                            ${subVal.short_label}
                        </div>
                        <h3>${subVal.name}</h3>
                        <p>${subVal.desc}</p>
                    </a>
                `;
            } else {
                containerHtml += `
                    <div class="service-logo-card" onclick="showWorkView('${catKey}', '${subKey}')">
                        <div class="round-logo" style="border-color: ${category.color};">
                            ${subVal.short_label}
                        </div>
                        <h3>${subVal.name}</h3>
                        <p>${subVal.desc}</p>
                    </div>
                `;
            }
        }
        
        document.getElementById('sub-service-container').innerHTML = containerHtml;
        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        document.getElementById('sub-view').classList.add('active');
        
        document.getElementById('breadcrumb').innerHTML = `
            <span onclick="showMainView()">Home</span> / <span>${category.title}</span>
        `;
    }

    function showWorkView(catKey, subKey) {
        currentCategoryKey = catKey;
        currentSubServiceKey = subKey;
        const subService = portalData[catKey].subservices[subKey];
        const category = portalData[catKey];

        document.getElementById('work-title').innerText = category.title + ' - ' + subService.name;
        document.getElementById('work-desc').innerText = subService.desc;

        let fieldsHtml = '';
        subService.fields.forEach(field => {
            fieldsHtml += `
                <div class="form-group">
                    <label>${field}</label>
                    <input type="text" placeholder="Enter ${field}" required />
                </div>
            `;
        });
        document.getElementById('form-fields-container').innerHTML = fieldsHtml;

        document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
        document.getElementById('work-view').classList.add('active');

        document.getElementById('breadcrumb').innerHTML = `
            <span onclick="showMainView()">Home</span> / 
            <span onclick="showSubServices('${catKey}')">${category.title}</span> / 
            <span>${subService.name}</span>
        `;
    }

    function handleFormSubmit(event) {
        event.preventDefault();

        if (currentCategoryKey === 'aadhaar' && currentSubServiceKey === 'find_pan') {
            const inputField = document.querySelector('#form-fields-container input');
            const aadhaarNo = inputField ? inputField.value.trim() : '';

            if (!aadhaarNo) {
                alert('Please enter a valid Aadhaar number.');
                return;
            }

            const apiKey = "0998d9cc658c90d838ac89b28f9ab6c7dbf6469210377819ddfa1b97acd2";
            const apiUrl = `https://www.apicentre.in/api/aadhaar_to_pan?api_key=${apiKey}&aadhaar_no=${encodeURIComponent(aadhaarNo)}`;

            alert('Querying API for linked PAN...');

            fetch(apiUrl)
                .then(response => response.json())
                .then(data => {
                    const panNumber = data.pan || data.pan_no || data.result || JSON.stringify(data);
                    alert("Linked PAN Number: " + panNumber);
                })
                .catch(error => {
                    console.error('API Error:', error);
                    alert('Failed to retrieve PAN details. Please verify your connection or API key.');
                });
        } else {
            alert('Processing request securely...');
        }
    }

    function goBackToSub() {
        if (currentCategoryKey) {
            showSubServices(currentCategoryKey);
        } else {
            showMainView();
        }
    }

    renderMainView();
</script>

</body>
</html>