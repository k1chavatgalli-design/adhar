<!DOCTYPE html>
<html lang="mr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Photo / फोटो अपलोड करा - Resizer</title>
    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Noto+Sans+Devanagari:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', 'Noto Sans Devanagari', sans-serif;
        }
        .drag-area {
            border: 2px dashed #3b82f6;
            transition: all 0.3s ease;
        }
        .drag-area.active {
            border-color: #1d4ed8;
            background-color: #eff6ff;
        }
    </style>
</head>
<body class="bg-slate-50 min-h-screen text-slate-800 flex flex-col justify-between">

    <!-- Header Navigation -->
    <header class="bg-white shadow-sm border-b border-slate-200 sticky top-0 z-50">
        <div class="max-w-6xl mx-auto px-4 py-4 flex flex-wrap justify-between items-center gap-4">
            <div class="flex items-center space-x-3">
                <div class="w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center font-bold text-xl shadow-md shadow-blue-500/20">
                    <i class="fa-solid fa-image"></i>
                </div>
                <div>
                    <h1 class="text-xl font-bold text-slate-900 leading-tight">Upload Photo / <span class="text-blue-600">फोटो अपलोड करा</span></h1>
                    <p class="text-xs text-slate-500">Official Standard Passport Photo Resizer Tool</p>
                </div>
            </div>
            <div class="flex items-center gap-2 text-xs font-semibold text-slate-600 bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200">
                <i class="fa-solid fa-circle-check text-green-500"></i> Auto-Resize: 160px × 212px
            </div>
        </div>
    </header>

    <!-- Main Content Container -->
    <main class="max-w-6xl mx-auto px-4 py-8 w-full flex-1 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- Left Column: Specs & Upload -->
        <div class="lg:col-span-5 flex flex-col gap-6">
            
            <!-- Standard Specification Card (Replicating Image Requirements) -->
            <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 relative overflow-hidden">
                <div class="absolute top-0 right-0 bg-blue-600 text-white text-[10px] font-bold uppercase tracking-wider px-3 py-1 rounded-bl-lg">
                    Standard Spec
                </div>
                <h2 class="text-base font-bold text-slate-900 mb-3 flex items-center gap-2">
                    <i class="fa-solid fa-ruler-combined text-blue-600"></i> Photo Dimension Requirements
                </h2>
                
                <!-- Visual Guideline Diagram -->
                <div class="bg-slate-100 border border-slate-200 rounded-xl p-4 my-3 flex flex-col items-center justify-center relative">
                    <!-- Top Arrow (Width) -->
                    <div class="w-36 flex flex-col items-center mb-1">
                        <span class="text-xs font-semibold text-blue-700 bg-white px-2 py-0.5 rounded shadow-sm border border-blue-200">
                            रुंदी १६० पिक्सेल / Width 160 px
                        </span>
                        <div class="w-full flex items-center justify-between text-blue-600 mt-1">
                            <i class="fa-solid fa-arrow-left text-xs"></i>
                            <div class="h-0.5 w-full bg-blue-500 mx-1"></div>
                            <i class="fa-solid fa-arrow-right text-xs"></i>
                        </div>
                    </div>

                    <!-- Diagram Canvas Container -->
                    <div class="flex items-center gap-2 my-1">
                        <!-- Left Height Label -->
                        <div class="flex flex-col items-center justify-center text-xs text-slate-600 font-medium h-32">
                            <span class="-rotate-90 whitespace-nowrap">Height 200 px - 212 px</span>
                        </div>

                        <!-- Avatar Mockup Box -->
                        <div class="w-28 h-36 border-2 border-dashed border-blue-400 bg-slate-200 rounded-lg flex flex-col items-center justify-end overflow-hidden relative shadow-inner">
                            <i class="fa-solid fa-user text-6xl text-slate-400 -mb-2"></i>
                        </div>

                        <!-- Right Height Label (Marathi) -->
                        <div class="flex flex-col items-center justify-center text-xs text-blue-700 font-semibold h-32">
                            <span class="rotate-90 whitespace-nowrap">उंची २०० ते २१२ पिक्सेल</span>
                        </div>
                    </div>
                </div>

                <!-- Technical summary list -->
                <ul class="text-xs text-slate-600 space-y-2 mt-4 bg-blue-50/50 p-3 rounded-lg border border-blue-100">
                    <li class="flex justify-between border-b border-blue-100/60 pb-1">
                        <span class="font-medium text-slate-700">Width / रुंदी:</span>
                        <span class="font-bold text-blue-800">160 px</span>
                    </li>
                    <li class="flex justify-between border-b border-blue-100/60 pb-1">
                        <span class="font-medium text-slate-700">Height / उंची:</span>
                        <span class="font-bold text-blue-800">200 px to 212 px</span>
                    </li>
                    <li class="flex justify-between">
                        <span class="font-medium text-slate-700">Format / स्वरूप:</span>
                        <span class="font-bold text-slate-800">JPG / JPEG</span>
                    </li>
                </ul>
            </div>

            <!-- Upload Area -->
            <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                <h2 class="text-base font-bold text-slate-900 mb-4 flex items-center gap-2">
                    <i class="fa-solid fa-cloud-arrow-up text-blue-600"></i> Upload Image / फोटो निवडा
                </h2>

                <div id="dropZone" class="drag-area rounded-xl p-6 text-center cursor-pointer bg-slate-50 hover:bg-blue-50/50 transition">
                    <input type="file" id="fileInput" accept="image/*" class="hidden">
                    <div class="w-14 h-14 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-3 shadow-inner">
                        <i class="fa-solid fa-file-image text-2xl"></i>
                    </div>
                    <p class="text-sm font-semibold text-slate-800">Choose File / फोटो निवडा</p>
                    <p class="text-xs text-slate-500 mt-1">Drag & drop or click to browse</p>
                    <span id="fileNameDisplay" class="inline-block mt-3 text-xs font-semibold text-blue-700 bg-blue-100/80 px-3 py-1 rounded-full max-w-full truncate hidden"></span>
                </div>
            </div>

        </div>

        <!-- Right Column: Interactive Editor, Controls & Download -->
        <div class="lg:col-span-7 flex flex-col gap-6">
            
            <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 flex-1 flex flex-col">
                <h2 class="text-base font-bold text-slate-900 mb-4 flex items-center justify-between">
                    <span class="flex items-center gap-2">
                        <i class="fa-solid fa-sliders text-blue-600"></i> Photo Preview & Customization
                    </span>
                    <span id="statusBadge" class="text-xs font-normal text-slate-500 bg-slate-100 px-2.5 py-1 rounded-md">
                        Waiting for upload...
                    </span>
                </h2>

                <!-- Main Preview Area -->
                <div class="flex-1 bg-slate-100 rounded-xl p-6 flex flex-col items-center justify-center min-h-[280px] border border-slate-200 relative overflow-hidden">
                    
                    <!-- Placeholder when no image uploaded -->
                    <div id="previewPlaceholder" class="text-center text-slate-400">
                        <i class="fa-solid fa-image text-5xl mb-2 opacity-50"></i>
                        <p class="text-sm font-medium">No photo selected yet</p>
                        <p class="text-xs text-slate-400">Upload a photo from the left panel</p>
                    </div>

                    <!-- Active Image Preview Container -->
                    <div id="previewWrapper" class="hidden flex flex-col items-center gap-3">
                        <div class="relative p-1 bg-white shadow-md rounded-lg border border-slate-300">
                            <!-- Realtime HTML Canvas Preview -->
                            <canvas id="photoCanvas" class="rounded border border-slate-200 block shadow-sm"></canvas>
                        </div>
                        <div class="text-xs text-slate-500 bg-white px-3 py-1 rounded-full shadow-sm border border-slate-200">
                            Output Size: <span id="currentDimText" class="font-bold text-blue-600">160 x 212 px</span>
                        </div>
                    </div>
                </div>

                <!-- Custom Resolution Controls -->
                <div class="mt-6 pt-5 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label for="inputWidth" class="block text-xs font-semibold text-slate-700 mb-1">
                            Width / रुंदी (px):
                        </label>
                        <input type="number" id="inputWidth" value="160" min="50" max="1000" 
                            class="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 font-semibold text-slate-800">
                    </div>
                    <div>
                        <label for="inputHeight" class="block text-xs font-semibold text-slate-700 mb-1">
                            Height / उंची (px):
                        </label>
                        <input type="number" id="inputHeight" value="212" min="50" max="1000" 
                            class="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/50 focus:border-blue-500 font-semibold text-slate-800">
                    </div>
                </div>

                <!-- Preset Dimensions Buttons -->
                <div class="mt-3 flex flex-wrap gap-2">
                    <span class="text-xs text-slate-500 flex items-center mr-1">Presets:</span>
                    <button type="button" onclick="setDimensions(160, 212)" class="text-xs bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 font-medium px-2.5 py-1 rounded border border-slate-200 transition">
                        160 × 212 px (Standard)
                    </button>
                    <button type="button" onclick="setDimensions(160, 200)" class="text-xs bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 font-medium px-2.5 py-1 rounded border border-slate-200 transition">
                        160 × 200 px (Min Height)
                    </button>
                </div>

                <!-- Download Action Button -->
                <div class="mt-6">
                    <button id="downloadBtn" disabled 
                        class="w-full bg-slate-300 text-slate-500 font-semibold py-3 px-6 rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-not-allowed text-sm">
                        <i class="fa-solid fa-download"></i>
                        Download Resized Photo / फोटो डाउनलोड करा
                    </button>
                </div>

            </div>

        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-white border-t border-slate-200 py-4 text-center text-xs text-slate-500">
        <p>100% Client-side Processing — Your uploaded photo remains private and never leaves your browser.</p>
    </footer>

    <!-- JavaScript Logic -->
    <script>
        // DOM Elements
        const fileInput = document.getElementById('fileInput');
        const dropZone = document.getElementById('dropZone');
        const fileNameDisplay = document.getElementById('fileNameDisplay');
        const previewPlaceholder = document.getElementById('previewPlaceholder');
        const previewWrapper = document.getElementById('previewWrapper');
        const canvas = document.getElementById('photoCanvas');
        const ctx = canvas.getContext('2d');
        const inputWidth = document.getElementById('inputWidth');
        const inputHeight = document.getElementById('inputHeight');
        const currentDimText = document.getElementById('currentDimText');
        const downloadBtn = document.getElementById('downloadBtn');
        const statusBadge = document.getElementById('statusBadge');

        let originalImage = null;
        let originalFileName = "resized_photo.jpg";

        // Click trigger for file input
        dropZone.addEventListener('click', () => fileInput.click());

        // File Selection Handler
        fileInput.addEventListener('change', (e) => {
            const files = e.target.files;
            if (files && files.length > 0) {
                handleFile(files[0]);
            }
        });

        // Drag and Drop listeners
        ['dragenter', 'dragover'].forEach(eventName => {
            dropZone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                dropZone.classList.add('active');
            }, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropZone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                dropZone.classList.remove('active');
            }, false);
        });

        dropZone.addEventListener('drop', (e) => {
            const dt = e.dataTransfer;
            const files = dt.files;
            if (files && files.length > 0) {
                handleFile(files[0]);
            }
        });

        // Process uploaded image file
        function handleFile(file) {
            if (!file.type.match('image.*')) {
                alert('कृपया वैध फोटो फाइली निवडा (Select a valid image file).');
                return;
            }

            originalFileName = file.name.replace(/\.[^/.]+$/, "") + "_resized.jpg";
            fileNameDisplay.textContent = file.name;
            fileNameDisplay.classList.remove('hidden');

            const reader = new FileReader();
            reader.onload = function (event) {
                const img = new Image();
                img.onload = function () {
                    originalImage = img;
                    updatePreview();
                    enableDownloadButton();
                };
                img.src = event.target.result;
            };
            reader.readAsDataURL(file);
        }

        // Draw and Resize on HTML Canvas
        function updatePreview() {
            if (!originalImage) return;

            const targetWidth = parseInt(inputWidth.value, 10) || 160;
            const targetHeight = parseInt(inputHeight.value, 10) || 212;

            // Update canvas dimensions
            canvas.width = targetWidth;
            canvas.height = targetHeight;

            // Clear Canvas
            ctx.clearRect(0, 0, targetWidth, targetHeight);

            // Smooth scaling quality
            ctx.imageSmoothingEnabled = true;
            ctx.imageSmoothingQuality = 'high';

            // Draw image resized to exact specified dimensions
            ctx.drawImage(originalImage, 0, 0, targetWidth, targetHeight);

            // Display updates
            currentDimText.textContent = `${targetWidth} x ${targetHeight} px`;
            
            previewPlaceholder.classList.add('hidden');
            previewWrapper.classList.remove('hidden');

            statusBadge.textContent = "Ready to download";
            statusBadge.className = "text-xs font-semibold text-green-700 bg-green-100 px-2.5 py-1 rounded-md";
        }

        // Quick Preset function
        function setDimensions(w, h) {
            inputWidth.value = w;
            inputHeight.value = h;
            updatePreview();
        }

        // Event listeners for dimension change inputs
        inputWidth.addEventListener('input', updatePreview);
        inputHeight.addEventListener('input', updatePreview);

        // Enable download button once file is ready
        function enableDownloadButton() {
            downloadBtn.disabled = false;
            downloadBtn.className = "w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-6 rounded-xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer text-sm";
        }

        // Download Action Event Handler
        downloadBtn.addEventListener('click', () => {
            if (!originalImage) return;

            // Make sure latest resolution is rendered
            updatePreview();

            // Export Canvas as JPEG image
            const dataUrl = canvas.toDataURL('image/jpeg', 0.92);

            // Execute client-side download without alert
            const link = document.createElement('a');
            link.download = originalFileName;
            link.href = dataUrl;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        });
    </script>
</body>
</html>