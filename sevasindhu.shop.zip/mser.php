<?php
session_start();
error_reporting(E_ALL);

$baseUrl        = "https://ahara.karnataka.gov.in/fcs_verify_mser/";
$otpVerifyUrl   = "https://ahara.karnataka.gov.in/fcs_verify_mser/OTP_VERIFY.aspx";
$captchaImageUrl = "https://ahara.karnataka.gov.in/fcs_verify_mser/CImage.aspx";
$verifyRcUrl    = "https://ahara.karnataka.gov.in/fcs_verify_mser/verify_rationcard.aspx";
$dupRcViewUrl   = "https://ahara.karnataka.gov.in/fcs_verify_mser/ViewRC/dup_rc_view.aspx";

// =========================================================================
// ACTION: CHANGE SERVER SESSION / RESET
// =========================================================================
if (isset($_GET['reset_session']) || isset($_POST['change_session'])) {
    if (!empty($_SESSION['cookie_file']) && file_exists($_SESSION['cookie_file'])) {
        @unlink($_SESSION['cookie_file']);
    }
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000,
            $params["path"], $params["domain"],
            $params["secure"], $params["httponly"]
        );
    }
    session_destroy();
    $selfUrl = strtok($_SERVER["REQUEST_URI"], '?');
    header("Location: " . $selfUrl);
    exit;
}

// =========================================================================
// HELPER: MODERN THEME LAYOUT WRAPPER
// =========================================================================
function renderModernPage($step, $title, $bodyHtml, $errorMsg = '', $infoMsg = '') {
    $rcBadge = !empty($_SESSION['rc_no']) ? htmlspecialchars($_SESSION['rc_no']) : '';
    $stepNames = [
        1 => '1. Enter RC',
        2 => '2. Member',
        3 => '3. Language',
        4 => '4. Captcha',
        5 => '5. OTP Verify',
        6 => '6. Print Card'
    ];
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= htmlspecialchars($title) ?> | Ahara FCS Karnataka</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
        <style>
            :root {
                --primary: #2563eb;
                --primary-hover: #1d4ed8;
                --primary-subtle: #eff6ff;
                --text-main: #0f172a;
                --text-muted: #64748b;
                --bg-canvas: #f8fafc;
                --bg-card: #ffffff;
                --border: #e2e8f0;
                --success: #16a34a;
                --danger: #dc2626;
                --shadow-sm: 0 1px 3px rgba(0,0,0,0.06);
                --shadow-md: 0 10px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04);
            }
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body {
                font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                background: linear-gradient(180deg, #eef2f6 0%, #f8fafc 100%);
                color: var(--text-main);
                min-height: 100vh;
                display: flex;
                flex-direction: column;
            }
            /* Header */
            .navbar {
                background: #0f172a;
                color: #ffffff;
                padding: 14px 28px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                border-bottom: 1px solid rgba(255, 255, 255, 0.1);
                box-shadow: var(--shadow-sm);
            }
            .nav-brand {
                display: flex;
                align-items: center;
                gap: 12px;
                font-size: 16px;
                font-weight: 700;
                letter-spacing: -0.3px;
            }
            .nav-badge {
                background: rgba(37, 99, 235, 0.2);
                color: #60a5fa;
                border: 1px solid rgba(96, 165, 250, 0.3);
                font-size: 11px;
                padding: 3px 8px;
                border-radius: 999px;
                font-weight: 600;
                text-transform: uppercase;
            }
            .nav-actions {
                display: flex;
                align-items: center;
                gap: 12px;
            }
            .status-indicator {
                display: inline-flex;
                align-items: center;
                gap: 6px;
                font-size: 12px;
                color: #94a3b8;
            }
            .status-dot {
                width: 8px;
                height: 8px;
                background-color: var(--success);
                border-radius: 50%;
                box-shadow: 0 0 8px var(--success);
                animation: pulse 2s infinite;
            }
            @keyframes pulse {
                0%, 100% { opacity: 1; transform: scale(1); }
                50% { opacity: 0.5; transform: scale(0.85); }
            }
            .btn-reset-session {
                background: rgba(239, 68, 68, 0.12);
                color: #f87171;
                border: 1px solid rgba(248, 113, 113, 0.3);
                padding: 7px 14px;
                font-size: 13px;
                font-weight: 600;
                border-radius: 6px;
                cursor: pointer;
                text-decoration: none;
                transition: all 0.2s ease;
                display: inline-flex;
                align-items: center;
                gap: 6px;
            }
            .btn-reset-session:hover {
                background: #dc2626;
                color: #ffffff;
                border-color: #dc2626;
            }
            /* Main Layout */
            .main-container {
                flex: 1;
                max-width: 620px;
                width: 100%;
                margin: 40px auto;
                padding: 0 20px;
            }
            /* Step Progress Bar */
            .progress-stepper {
                display: flex;
                justify-content: space-between;
                margin-bottom: 24px;
                background: #ffffff;
                padding: 12px 16px;
                border-radius: 12px;
                border: 1px solid var(--border);
                box-shadow: var(--shadow-sm);
            }
            .step-item {
                font-size: 12px;
                font-weight: 600;
                color: var(--text-muted);
                display: flex;
                align-items: center;
                gap: 6px;
            }
            .step-item.active {
                color: var(--primary);
            }
            .step-item.completed {
                color: var(--success);
            }
            /* Card */
            .card {
                background: var(--bg-card);
                border-radius: 16px;
                border: 1px solid var(--border);
                box-shadow: var(--shadow-md);
                padding: 32px;
                position: relative;
            }
            .card-header {
                text-align: center;
                margin-bottom: 24px;
            }
            .card-title {
                font-size: 20px;
                font-weight: 700;
                color: var(--text-main);
                letter-spacing: -0.4px;
            }
            .card-subtitle {
                font-size: 13px;
                color: var(--text-muted);
                margin-top: 6px;
                line-height: 1.5;
            }
            /* Alerts */
            .alert {
                padding: 12px 16px;
                border-radius: 8px;
                font-size: 13px;
                line-height: 1.4;
                margin-bottom: 20px;
                display: flex;
                align-items: flex-start;
                gap: 10px;
            }
            .alert-error {
                background: #fef2f2;
                color: #991b1b;
                border: 1px solid #fecaca;
            }
            .alert-info {
                background: #f0fdf4;
                color: #166534;
                border: 1px solid #bbf7d0;
            }
            /* Form Elements */
            .form-group {
                margin-bottom: 18px;
                text-align: left;
            }
            label {
                display: block;
                font-size: 13px;
                font-weight: 600;
                color: #334155;
                margin-bottom: 6px;
            }
            input[type="text"], select {
                width: 100%;
                padding: 12px 14px;
                font-size: 15px;
                border: 1.5px solid var(--border);
                border-radius: 8px;
                color: var(--text-main);
                background: #ffffff;
                transition: border-color 0.2s, box-shadow 0.2s;
                font-family: inherit;
            }
            input[type="text"]:focus, select:focus {
                outline: none;
                border-color: var(--primary);
                box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15);
            }
            .input-otp {
                font-size: 24px !important;
                letter-spacing: 10px;
                text-align: center;
                font-weight: 700;
            }
            .btn-primary {
                width: 100%;
                background: var(--primary);
                color: #ffffff;
                border: none;
                padding: 13px 20px;
                font-size: 15px;
                font-weight: 600;
                border-radius: 8px;
                cursor: pointer;
                transition: background 0.2s, transform 0.1s;
                display: inline-flex;
                justify-content: center;
                align-items: center;
                gap: 8px;
            }
            .btn-primary:hover {
                background: var(--primary-hover);
            }
            .btn-primary:active {
                transform: scale(0.99);
            }
            /* District pill box */
            .districts-pill {
                background: var(--primary-subtle);
                border: 1px solid #dbeafe;
                padding: 10px 14px;
                border-radius: 8px;
                font-size: 11px;
                color: #1e40af;
                line-height: 1.5;
                margin-bottom: 20px;
                text-align: center;
            }
            /* Radio language cards */
            .radio-group {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 12px;
                margin-bottom: 20px;
            }
            .radio-card {
                border: 1.5px solid var(--border);
                padding: 14px;
                border-radius: 8px;
                cursor: pointer;
                display: flex;
                align-items: center;
                gap: 10px;
                font-weight: 600;
                font-size: 14px;
                transition: all 0.2s;
            }
            .radio-card:hover {
                border-color: var(--primary);
                background: var(--primary-subtle);
            }
            .radio-card input {
                accent-color: var(--primary);
            }
            /* Captcha container */
            .captcha-box {
                background: #f1f5f9;
                border: 1px solid var(--border);
                border-radius: 8px;
                padding: 12px;
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 10px;
                margin-bottom: 16px;
            }
            .captcha-img {
                border-radius: 6px;
                background: #ffffff;
                padding: 4px;
                border: 1px solid #cbd5e1;
            }
            .footer-info {
                text-align: center;
                font-size: 12px;
                color: var(--text-muted);
                margin-top: 20px;
            }
            .footer-info a {
                color: var(--primary);
                text-decoration: none;
                font-weight: 600;
            }
        </style>
    </head>
    <body>
        <nav class="navbar">
            <div class="nav-brand">
                <span>🏛️ FCS Karnataka</span>
                <span class="nav-badge">M-Server</span>
                <?php if ($rcBadge): ?>
                    <span style="font-size:12px; color:#cbd5e1; font-weight:normal;">| RC: <strong><?= $rcBadge ?></strong></span>
                <?php endif; ?>
            </div>
            <div class="nav-actions">
                <div class="status-indicator">
                    <span class="status-dot"></span>
                    <span>Server Connected</span>
                </div>
                <a href="?reset_session=1" class="btn-reset-session" title="Clean cookies and initialize new session with Ahara server">
                    🔄 Change Server Session
                </a>
            </div>
        </nav>

        <main class="main-container">
            <div class="progress-stepper">
                <?php foreach ($stepNames as $num => $label): ?>
                    <span class="step-item <?= $num === $step ? 'active' : ($num < $step ? 'completed' : '') ?>">
                        <?= $num < $step ? '✓' : $num . '.' ?> <?= explode('. ', $label)[1] ?>
                    </span>
                <?php endforeach; ?>
            </div>

            <div class="card">
                <?php if (!empty($errorMsg)): ?>
                    <div class="alert alert-error">
                        <span>⚠️</span>
                        <div><?= $errorMsg ?></div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($infoMsg)): ?>
                    <div class="alert alert-info">
                        <span>ℹ️</span>
                        <div><?= $infoMsg ?></div>
                    </div>
                <?php endif; ?>

                <?= $bodyHtml ?>
            </div>

            <div class="footer-info">
                Need a fresh connection or server timed out? 
                <a href="?reset_session=1">Click here to Change Server Session</a>
            </div>
        </main>
    </body>
    </html>
    <?php
}

// =========================================================================
// STEP 6: VERIFY OTP -> RETRIEVE CARD -> GENERATE OFFICIAL BPL_PRINT.HTML
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_final_otp'])) {
    $otpCode = trim($_POST['otp_code']);
    $cookieFile = $_SESSION['cookie_file'] ?? '';
    $vs = $_SESSION['vs_otp'] ?? '';
    $ev = $_SESSION['ev_otp'] ?? '';
    $vsg = $_SESSION['vsg'] ?? '58FA0D95';
    $rcNo = $_SESSION['rc_no'] ?? '';
    $selectedMember = $_SESSION['selected_member'] ?? '';
    $selectedLang = $_SESSION['selected_lang'] ?? 'E';

    if (empty($otpCode) || empty($cookieFile) || empty($vs)) {
        renderModernPage(5, "Session Expired", '
            <div class="card-header">
                <h2 class="card-title">Session Expired</h2>
                <p class="card-subtitle">Your server session expired or OTP context was lost.</p>
            </div>
            <a href="?reset_session=1" class="btn-primary">🔄 Change Session & Restart</a>
        ', 'Session context missing. Please renew the server session.');
        exit;
    }

    // 6.1: Submit OTP with exact browser signature
    $postDataOtp = http_build_query([
        '__EVENTTARGET' => 'ctl00$ContentPlaceHolder1$btn_opt',
        '__EVENTARGUMENT' => '',
        '__LASTFOCUS' => '',
        '__VIEWSTATE' => $vs,
        '__VIEWSTATEGENERATOR' => $vsg,
        '__EVENTVALIDATION' => $ev,
        'ctl00$ContentPlaceHolder1$hidBioInfo' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5' => '',
        'ctl00$ContentPlaceHolder1$ddl_mems_detls' => $selectedMember,
        'ctl00$ContentPlaceHolder1$rbl_lang' => $selectedLang,
        'ctl00$ContentPlaceHolder1$txt_captcha' => '',
        'ctl00$ContentPlaceHolder1$rblAadhaarConsent' => 'Y',
        'ctl00$ContentPlaceHolder1$txt_otp' => $otpCode
    ]);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $otpVerifyUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postDataOtp);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_ENCODING, "");
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Host: ahara.karnataka.gov.in',
        'Cache-Control: max-age=0',
        'Origin: https://ahara.karnataka.gov.in',
        'Content-Type: application/x-www-form-urlencoded',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36',
        'Referer: ' . $otpVerifyUrl,
        'Connection: keep-alive'
    ]);
    $resOtpPage = curl_exec($ch);
    curl_close($ch);

    // 6.2: Fetch verify_rationcard.aspx to establish landing state
    $chVerify = curl_init();
    curl_setopt($chVerify, CURLOPT_URL, $verifyRcUrl);
    curl_setopt($chVerify, CURLOPT_HTTPGET, true);
    curl_setopt($chVerify, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($chVerify, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($chVerify, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($chVerify, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($chVerify, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($chVerify, CURLOPT_ENCODING, "");
    curl_setopt($chVerify, CURLOPT_HTTPHEADER, [
        'Host: ahara.karnataka.gov.in',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36',
        'Referer: ' . $otpVerifyUrl,
        'Connection: keep-alive'
    ]);
    $verifyHtml = curl_exec($chVerify);
    curl_close($chVerify);

    file_put_contents(__DIR__ . '/verify_rationcard.html', $verifyHtml);

    // Extract ViewState & EventValidation from verify_rationcard.aspx
    $domV = new DOMDocument(); @$domV->loadHTML($verifyHtml);
    $xpathV = new DOMXPath($domV);
    $vsVerify = $xpathV->query("//input[@id='__VIEWSTATE']")->item(0)?->getAttribute('value') ?? '';
    $vsgVerify = $xpathV->query("//input[@id='__VIEWSTATEGENERATOR']")->item(0)?->getAttribute('value') ?? 'DE58201B';
    $evVerify = $xpathV->query("//input[@id='__EVENTVALIDATION']")->item(0)?->getAttribute('value') ?? '';

    // 6.3: Postback for lnkRCDetails to initialize session keys
    $postDataLnk = http_build_query([
        '__EVENTTARGET' => 'lnkRCDetails',
        '__EVENTARGUMENT' => '',
        '__LASTFOCUS' => '',
        '__VIEWSTATE' => $vsVerify,
        '__VIEWSTATEGENERATOR' => $vsgVerify,
        '__EVENTVALIDATION' => $evVerify,
        'txt_rc_no' => $rcNo
    ]);

    $chLnk = curl_init();
    curl_setopt($chLnk, CURLOPT_URL, $verifyRcUrl);
    curl_setopt($chLnk, CURLOPT_POST, true);
    curl_setopt($chLnk, CURLOPT_POSTFIELDS, $postDataLnk);
    curl_setopt($chLnk, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($chLnk, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($chLnk, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($chLnk, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($chLnk, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($chLnk, CURLOPT_ENCODING, "");
    curl_setopt($chLnk, CURLOPT_HTTPHEADER, [
        'Host: ahara.karnataka.gov.in',
        'Origin: https://ahara.karnataka.gov.in',
        'Content-Type: application/x-www-form-urlencoded',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36',
        'Referer: ' . $verifyRcUrl,
        'Connection: keep-alive'
    ]);
    $resAfterLnk = curl_exec($chLnk);
    curl_close($chLnk);

    // 6.4: Fetch final populated dup_rc_view.aspx
    $chDup = curl_init();
    curl_setopt($chDup, CURLOPT_URL, $dupRcViewUrl);
    curl_setopt($chDup, CURLOPT_HTTPGET, true);
    curl_setopt($chDup, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($chDup, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($chDup, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($chDup, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($chDup, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($chDup, CURLOPT_ENCODING, "");
    curl_setopt($chDup, CURLOPT_HTTPHEADER, [
        'Host: ahara.karnataka.gov.in',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36',
        'Referer: ' . $verifyRcUrl,
        'Connection: keep-alive'
    ]);
    $dupRcResponse = curl_exec($chDup);
    curl_close($chDup);

    $hasPopulatedCard = (stripos($dupRcResponse, 'Incorrect RC!') === false && stripos($dupRcResponse, 'tblRCard') !== false);
    $rawCardHtml = $hasPopulatedCard ? $dupRcResponse : (stripos($resAfterLnk, 'tblRCard') !== false ? $resAfterLnk : $verifyHtml);

    // 6.5: Strip specimen watermark
    $rawCardHtml = preg_replace('/<div[^>]*>\s*<img[^>]*specimen\.png[^>]*>\s*<\/div>/is', '', $rawCardHtml);
    $rawCardHtml = preg_replace('/<img[^>]*specimen\.png[^>]*>/is', '', $rawCardHtml);
    $rawCardHtml = preg_replace('/<img[^>]*id=["\']Img1["\'][^>]*>/is', '', $rawCardHtml);
    $rawCardHtml = preg_replace('/<img[^>]*id=["\']im["\'][^>]*>/is', '', $rawCardHtml);

    // 6.6: Download & embed member photos as base64
    if (preg_match_all('/src=["\'](get_rc_img\.aspx\?[^"\']+)["\']/i', $rawCardHtml, $imgMatches)) {
        $uniqueImgPaths = array_unique($imgMatches[1]);
        foreach ($uniqueImgPaths as $relImgPath) {
            $fullImgUrl = "https://ahara.karnataka.gov.in/fcs_verify_mser/ViewRC/" . html_entity_decode($relImgPath);
            $chImgFetch = curl_init();
            curl_setopt($chImgFetch, CURLOPT_URL, $fullImgUrl);
            curl_setopt($chImgFetch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($chImgFetch, CURLOPT_COOKIEFILE, $cookieFile);
            curl_setopt($chImgFetch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($chImgFetch, CURLOPT_HTTPHEADER, [
                'Host: ahara.karnataka.gov.in',
                'Referer: ' . $dupRcViewUrl,
                'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            ]);
            $rawImgBytes = curl_exec($chImgFetch);
            $imgHttpCode = curl_getinfo($chImgFetch, CURLINFO_HTTP_CODE);
            curl_close($chImgFetch);

            if ($imgHttpCode === 200 && !empty($rawImgBytes) && strlen($rawImgBytes) > 100) {
                $base64Img = 'data:image/jpeg;base64,' . base64_encode($rawImgBytes);
                $rawCardHtml = str_replace($relImgPath, $base64Img, $rawCardHtml);
            }
        }
    }

    // 6.7: Inline Government Emblem as Base64
    $govtLogoRel = '../Images/govtlogo.jpg';
    if (strpos($rawCardHtml, $govtLogoRel) !== false) {
        $chLogo = curl_init();
        curl_setopt($chLogo, CURLOPT_URL, 'https://ahara.karnataka.gov.in/fcs_verify_mser/Images/govtlogo.jpg');
        curl_setopt($chLogo, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($chLogo, CURLOPT_SSL_VERIFYPEER, false);
        $logoBytes = curl_exec($chLogo);
        $logoHttpCode = curl_getinfo($chLogo, CURLINFO_HTTP_CODE);
        curl_close($chLogo);
        if ($logoHttpCode === 200 && !empty($logoBytes)) {
            $base64Logo = 'data:image/jpeg;base64,' . base64_encode($logoBytes);
            $rawCardHtml = str_replace($govtLogoRel, $base64Logo, $rawCardHtml);
        }
    }

    // Clean up temporary cookies
    @unlink($cookieFile);

    // 6.8: Inject official disclaimer table & styling
    $disclaimerTable = '<table style="margin-top: 15px;">
            <tbody><tr>
                <td align="center" style="width: 843.7px;font-size:8pt;font-family: Verdana;">Disclaimer: This Ration card is issued only for the purpose of drawing entitled quantity of Food grains from the Fair Price shop by the card holder. The Personal details of the card holder are based on self declaration of the card holder. The department of Food, Civil Supplies and Consumer Affairs Department, does not certify the correctness of the particulars furnished.</td>
            </tr>
        </tbody></table>';

    $rawCardHtml = preg_replace('/<table[^>]*>\s*<tr>\s*<td[^>]*align=["\']center["\'][^>]*>\s*<input[^>]*btnExit[^>]*>.*?<\/table>/is', $disclaimerTable, $rawCardHtml);

    if (stripos($rawCardHtml, '<div id="rc-container">') === false && stripos($rawCardHtml, '<table id="tblRCard"') !== false) {
        $rawCardHtml = preg_replace('/(<center>\s*)(<table id="tblRCard".*?<\/table>\s*<table.*?<\/table>)(\s*<\/center>)/is', '<div id="rc-container"><center>$2</center></div>', $rawCardHtml);
    }

    // Embed jQuery and print engine
    $bplPrintEngine = '
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    function _x(STR_XPATH) {
        var xresult = document.evaluate(STR_XPATH, document, null, XPathResult.ANY_TYPE, null);
        var xnodes = [];
        var xres;
        while (xres = xresult.iterateNext()) {
            xnodes.push(xres);
        }
        return xnodes;
    }

    $(document).ready(function() {
        var card_type = $("#lblCardType1").text();

        if (card_type.indexOf("Antyodaya") !== -1) {
            $("<span id=\"Label16\" style=\"font-size:18pt;font-weight:bold;\">AAY</span><div style=\"height:1px; clear:both\"></div>").insertBefore("#lblAckNo");
            $("#tblRCard").attr("style", "font-family: Verdana; font-size: 8pt; height: 566.93px; vertical-align: top;padding-top: 20px;");
            $("#lblCardType1").html("Antyodaya Anna Yojane Not Eligible for Kerosene");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[2]")).attr("style", "width: 47.79px;height: 570px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]")).attr("style", "border: 1px solid #F5A9A9;padding: 0px;background-color: #F5A9A9;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr[1]/td[3]/table/tbody/tr[1]/td/table")).attr("style", "height: 100px;background-color:#FA5858;color:white !important;border-radius:0px 0px 20px 20px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[4]/td/table")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[5]")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]")).attr("style", "width: 380.95px; height: 100%; padding-left: 20px;border: 1px solid #F5A9A9;padding: 5px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/table")).attr("style", "height: 431.69px; width: 331.63px;border: 5px double #F5A9A9;");
            $("#Table1").attr("style", "width: 360.63px; height: 110px; font-size: 8pt;background-color: #F5A9A9;color: #000;border-radius: 20px 20px 0px 0px;margin-top:30px");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[3]/td/table/tbody/tr/td")).attr("style", "border-top: 1px solid #716b83;border-bottom: 1px solid #716b83;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[7]/td")).attr("style", "border-top: 1px solid #716b83;border-bottom: 1px solid #716b83;");
            $(_x("//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[1]/td/table/tbody/tr[1]/td/table")).attr("style", "color:white;");
            $(_x("//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[1]/td/table/tbody/tr[2]/td/table/tbody/tr/td/table")).attr("style", "color:white;");
        } else if (card_type.indexOf("Non-Priority") !== -1 || card_type.indexOf("NPHH") !== -1) {
            $("<span id=\"Label16\" style=\"font-size:18pt;font-weight:bold;\">NPHH</span><div style=\"height:1px; clear:both\"></div>").insertBefore("#lblAckNo");
            $("#tblRCard").attr("style", "font-family: Verdana; font-size: 8pt; height: 566.93px; vertical-align: top;padding-top: 20px;");
            $("#lblCardType1").html("Non Priority Household Not Eligible for Kerosene Opted to draw Ration");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[2]")).attr("style", "width: 47.79px;height: 570px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]")).attr("style", "border: 1px solid #C8C4E7;padding: 0px;background-color: #C8C4E7;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr[1]/td[3]/table/tbody/tr[1]/td/table")).attr("style", "height: 100px;background-color:#6D87D2;color:white !important;border-radius:0px 0px 20px 20px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[4]/td/table")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[5]")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]")).attr("style", "width: 380.95px; height: 100%; padding-left: 20px;border: 1px solid #C8C4E7;padding: 5px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/table")).attr("style", "height: 431.69px; width: 331.63px;border: 5px double #C8C4E7;");
            $("#Table1").attr("style", "width: 360.63px; height: 110px; font-size: 8pt;background-color: #C8C4E7;color: #000;border-radius: 20px 20px 0px 0px;margin-top:30px");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[3]/td/table/tbody/tr/td")).attr("style", "border-top: 1px solid #716b83;border-bottom: 1px solid #716b83;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[7]/td")).attr("style", "border-top: 1px solid #716b83;border-bottom: 1px solid #716b83;");
            $(_x("//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[1]/td/table/tbody/tr[1]/td/table")).attr("style", "color:white;");
            $(_x("//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[1]/td/table/tbody/tr[2]/td/table/tbody/tr/td/table")).attr("style", "color:white;");
        } else {
            // Default PHH (Green theme)
            $("<span id=\"Label16\" style=\"font-size:18pt;font-weight:bold;\">PHH</span><div style=\"height:1px; clear:both\"></div>").insertBefore("#lblAckNo");
            $("#tblRCard").attr("style", "font-family: Verdana; font-size: 8pt; height: 566.93px; vertical-align: top;padding-top: 20px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[2]")).attr("style", "width: 47.79px;height: 570px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]")).attr("style", "border: 1px solid #7eab74;padding: 0px;background-color: #aabd9d;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr[1]/td[3]/table/tbody/tr[1]/td/table")).attr("style", "height: 100px;background-color:#3f652a;color: white !important;border-radius:0px 0px 20px 20px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[4]/td/table")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[5]")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]")).attr("style", "width: 380.95px; height: 100%; padding-left: 20px;border: 1px solid #7eab74;padding: 5px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/table")).attr("style", "height: 431.69px; width: 331.63px;border: 5px double #7eab74;");
            $("#Table1").attr("style", "width: 360.63px; height: 110px; font-size: 8pt;background-color: #aabd9d;color: #000;border-radius: 20px 20px 0px 0px;margin-top:30px");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[3]/td/table/tbody/tr/td")).attr("style", "border-top: 1px solid #716b83;border-bottom: 1px solid #716b83;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[7]/td")).attr("style", "border-top: 1px solid #716b83;border-bottom: 1px solid #716b83;");
            $(_x("//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[1]/td/table/tbody/tr[1]/td/table")).attr("style", "color:white;");
            $(_x("//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[1]/td/table/tbody/tr[2]/td/table/tbody/tr/td/table")).attr("style", "color:white;");
        }

        $(_x("/html/.//*[@id=\"Table3\"]/tbody/tr/td[1]")).attr("style", "width: 213px;");
        $("#lblPhNo").attr("style", "font-size: 8pt;");
    });

    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var w = window.open();
        w.document.write("<html><head><title>Print Ration Card</title>");
        w.document.write("<style>" + document.getElementById("style").innerHTML + "</style>");
        w.document.write("<style>@page { size: A4; margin: 2mm; }</style>");
        w.document.write("</head><body><center>");
        w.document.write(printContents);
        w.document.write("</center></body></html>");
        w.document.close();
        w.focus();
        setTimeout(function() {
            w.print();
            w.close();
        }, 350);
    }
    </script>
    <style id="style" type="text/css">
        #tblRCard > tbody > tr > td > table > tbody > tr > td:nth-child(3) > table > tbody > tr:nth-child(1) > td > table { color: white !important; }
        #tblRCard > tbody > tr > td > table > tbody > tr > td:nth-child(3) > table > tbody > tr:nth-child(1) > td > table > tbody > tr:nth-child(1) > td > table { color: white !important; }
        #tblRCard > tbody > tr > td > table > tbody > tr > td:nth-child(3) > table > tbody > tr:nth-child(1) > td > table > tbody > tr:nth-child(2) > td > table > tbody > tr > td > table { color: white !important; }
    </style>
    <style type="text/css" media="print">
        @page { size: A4; margin: 2mm; }
        #no-print-toolbar, #print-content { display: none !important; }
    </style>
    <center>
        <div id="print-content" style="margin: 25px 0; font-family: \'Plus Jakarta Sans\', Arial, sans-serif;">
            <input type="button" onclick="printDiv(\'rc-container\')" value="🖨️ Print Ration Card" style="background: #16a34a; color: white; border: none; padding: 12px 28px; font-size: 15px; font-weight: 700; border-radius: 8px; cursor: pointer; margin-right: 12px; box-shadow: 0 4px 12px rgba(22, 163, 74, 0.25);">
            <input type="button" onclick="window.location.href=\'?reset_session=1\'" value="🔄 Change Session / New Search" style="background: #0f172a; color: white; border: none; padding: 12px 22px; font-size: 15px; font-weight: 600; border-radius: 8px; cursor: pointer;">
        </div>
    </center>
    ';

    if (stripos($rawCardHtml, '</body>') !== false) {
        $rawCardHtml = str_ireplace('</body>', $bplPrintEngine . '</body>', $rawCardHtml);
    } else {
        $rawCardHtml .= $bplPrintEngine;
    }

    file_put_contents(__DIR__ . '/BPL_Print.html', $rawCardHtml);
    file_put_contents(__DIR__ . '/dup_rc_view.html', $rawCardHtml);

    echo $rawCardHtml;
    exit;
}

// =========================================================================
// STEP 5: CAPTCHA SUBMIT -> AUTO CONSENT -> AUTO AUTH TYPE -> RENDER OTP
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_captcha'])) {
    $captchaCode = trim($_POST['captcha_code']);
    $cookieFile = $_SESSION['cookie_file'] ?? '';
    $vs = $_SESSION['vs_captcha'] ?? '';
    $ev = $_SESSION['ev_captcha'] ?? '';
    $vsg = $_SESSION['vsg'] ?? '58FA0D95';
    $rcNo = $_SESSION['rc_no'] ?? '';
    $selectedMember = $_SESSION['selected_member'] ?? '';
    $selectedLang = $_SESSION['selected_lang'] ?? 'E';

    if (empty($captchaCode) || empty($cookieFile) || empty($vs)) {
        renderModernPage(4, "Session Expired", '
            <div class="card-header">
                <h2 class="card-title">Captcha Session Expired</h2>
            </div>
            <a href="?reset_session=1" class="btn-primary">🔄 Change Session & Retry</a>
        ', 'Missing captcha context or invalid tokens.');
        exit;
    }

    // 5.1: Submit Captcha
    $postDataCaptcha = http_build_query([
        '__EVENTTARGET' => '',
        '__EVENTARGUMENT' => '',
        '__LASTFOCUS' => '',
        '__VIEWSTATE' => $vs,
        '__VIEWSTATEGENERATOR' => $vsg,
        '__EVENTVALIDATION' => $ev,
        'ctl00$ContentPlaceHolder1$hidBioInfo' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5' => '',
        'ctl00$ContentPlaceHolder1$txt_rc_no' => $rcNo,
        'ctl00$ContentPlaceHolder1$ddl_mems_detls' => $selectedMember,
        'ctl00$ContentPlaceHolder1$rbl_lang' => $selectedLang,
        'ctl00$ContentPlaceHolder1$txt_captcha' => $captchaCode,
        'ctl00$ContentPlaceHolder1$btn_captcha' => 'GO'
    ]);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $otpVerifyUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postDataCaptcha);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Origin: https://ahara.karnataka.gov.in',
        'Referer: ' . $otpVerifyUrl
    ]);

    $resConsentPage = curl_exec($ch);

    $dom = new DOMDocument(); @$dom->loadHTML($resConsentPage);
    $xpath = new DOMXPath($dom);
    $vsConsent = $xpath->query("//input[@id='__VIEWSTATE']")->item(0)?->getAttribute('value') ?? '';
    $evConsent = $xpath->query("//input[@id='__EVENTVALIDATION']")->item(0)?->getAttribute('value') ?? '';

    if (empty($vsConsent)) {
        renderModernPage(4, "Invalid Captcha", '
            <div class="card-header">
                <h2 class="card-title">Invalid Captcha Entered</h2>
                <p class="card-subtitle">The captcha code entered did not match the image.</p>
            </div>
            <a href="?reset_session=1" class="btn-primary">🔄 Change Session & Retry</a>
        ', 'The server rejected the captcha. Please restart with a fresh session.');
        exit;
    }

    // 5.2: Auto-Trigger Aadhaar Consent ("Y")
    $postDataConsent = http_build_query([
        '__EVENTTARGET' => 'ctl00$ContentPlaceHolder1$rblAadhaarConsent$0',
        '__EVENTARGUMENT' => '',
        '__LASTFOCUS' => '',
        '__VIEWSTATE' => $vsConsent,
        '__VIEWSTATEGENERATOR' => $vsg,
        '__EVENTVALIDATION' => $evConsent,
        'ctl00$ContentPlaceHolder1$hidBioInfo' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5' => '',
        'ctl00$ContentPlaceHolder1$txt_rc_no' => $rcNo,
        'ctl00$ContentPlaceHolder1$ddl_mems_detls' => $selectedMember,
        'ctl00$ContentPlaceHolder1$rbl_lang' => $selectedLang,
        'ctl00$ContentPlaceHolder1$txt_captcha' => '',
        'ctl00$ContentPlaceHolder1$rblAadhaarConsent' => 'Y'
    ]);

    curl_setopt($ch, CURLOPT_POSTFIELDS, $postDataConsent);
    $resAuthTypePage = curl_exec($ch);

    $domAuth = new DOMDocument(); @$domAuth->loadHTML($resAuthTypePage);
    $xpathAuth = new DOMXPath($domAuth);
    $vsAuth = $xpathAuth->query("//input[@id='__VIEWSTATE']")->item(0)?->getAttribute('value') ?? '';
    $evAuth = $xpathAuth->query("//input[@id='__EVENTVALIDATION']")->item(0)?->getAttribute('value') ?? '';

    // 5.3: Auto-Trigger Auth Type ("O" = OTP)
    $postDataAuthType = http_build_query([
        '__EVENTTARGET' => 'ctl00$ContentPlaceHolder1$rbl_auth_type$0',
        '__EVENTARGUMENT' => '',
        '__LASTFOCUS' => '',
        '__VIEWSTATE' => $vsAuth,
        '__VIEWSTATEGENERATOR' => $vsg,
        '__EVENTVALIDATION' => $evAuth,
        'ctl00$ContentPlaceHolder1$hidBioInfo' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5' => '',
        'ctl00$ContentPlaceHolder1$txt_rc_no' => $rcNo,
        'ctl00$ContentPlaceHolder1$ddl_mems_detls' => $selectedMember,
        'ctl00$ContentPlaceHolder1$rbl_lang' => $selectedLang,
        'ctl00$ContentPlaceHolder1$txt_captcha' => '',
        'ctl00$ContentPlaceHolder1$rblAadhaarConsent' => 'Y',
        'ctl00$ContentPlaceHolder1$rbl_auth_type' => 'O'
    ]);

    curl_setopt($ch, CURLOPT_POSTFIELDS, $postDataAuthType);
    $resOtpPage = curl_exec($ch);
    curl_close($ch);

    // Extract ViewState & EventValidation for final OTP submission
    $domOtp = new DOMDocument(); @$domOtp->loadHTML($resOtpPage);
    $xpathOtp = new DOMXPath($domOtp);
    $_SESSION['vs_otp'] = $xpathOtp->query("//input[@id='__VIEWSTATE']")->item(0)?->getAttribute('value') ?? '';
    $_SESSION['ev_otp'] = $xpathOtp->query("//input[@id='__EVENTVALIDATION']")->item(0)?->getAttribute('value') ?? '';

    ob_start();
    ?>
    <div class="card-header">
        <h2 class="card-title">Enter Aadhaar OTP</h2>
        <p class="card-subtitle">OTP ನಮೂದಿಸಿ - Sent to mobile linked with Aadhaar</p>
    </div>
    <form method="POST">
        <div class="form-group">
            <label>6-Digit Verification Code</label>
            <input type="text" name="otp_code" class="input-otp" placeholder="------" required maxlength="6" pattern="[0-9]{6}" autocomplete="off" autofocus>
        </div>
        <button type="submit" name="submit_final_otp" class="btn-primary">
            ✓ Verify OTP & Download Card
        </button>
    </form>
    <?php
    $bodyHtml = ob_get_clean();
    renderModernPage(5, "Enter OTP", $bodyHtml, '', 'SMS Dispatched! An OTP was sent to the UIDAI-registered mobile number of the selected member.');
    exit;
}

// =========================================================================
// STEP 4: SUBMIT LANGUAGE & FETCH CAPTCHA
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_lang'])) {
    $selectedLang = trim($_POST['lang_val'] ?? 'E');
    $cookieFile = $_SESSION['cookie_file'] ?? '';
    $vs = $_SESSION['vs_lang'] ?? '';
    $ev = $_SESSION['ev_lang'] ?? '';
    $vsg = $_SESSION['vsg'] ?? '58FA0D95';
    $selectedMember = $_SESSION['selected_member'] ?? '';
    $rcNo = $_SESSION['rc_no'] ?? '';

    $_SESSION['selected_lang'] = $selectedLang;

    $eventTarget = ($selectedLang === 'K') 
        ? 'ctl00$ContentPlaceHolder1$rbl_lang$1' 
        : 'ctl00$ContentPlaceHolder1$rbl_lang$0';

    $postData = http_build_query([
        '__EVENTTARGET' => $eventTarget,
        '__EVENTARGUMENT' => '',
        '__LASTFOCUS' => '',
        '__VIEWSTATE' => $vs,
        '__VIEWSTATEGENERATOR' => $vsg,
        '__EVENTVALIDATION' => $ev,
        'ctl00$ContentPlaceHolder1$hidBioInfo' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5' => '',
        'ctl00$ContentPlaceHolder1$ddl_mems_detls' => $selectedMember,
        'ctl00$ContentPlaceHolder1$rbl_lang' => $selectedLang
    ]);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $otpVerifyUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Origin: https://ahara.karnataka.gov.in',
        'Referer: ' . $otpVerifyUrl
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    $dom = new DOMDocument(); @$dom->loadHTML($response);
    $xpath = new DOMXPath($dom);

    $_SESSION['vs_captcha'] = $xpath->query("//input[@id='__VIEWSTATE']")->item(0)?->getAttribute('value') ?? '';
    $_SESSION['ev_captcha'] = $xpath->query("//input[@id='__EVENTVALIDATION']")->item(0)?->getAttribute('value') ?? '';

    // Fetch Captcha Image using active session cookie
    $chImg = curl_init();
    curl_setopt($chImg, CURLOPT_URL, $captchaImageUrl);
    curl_setopt($chImg, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($chImg, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($chImg, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($chImg, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($chImg, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');
    curl_setopt($chImg, CURLOPT_REFERER, $otpVerifyUrl);
    $captchaBytes = curl_exec($chImg);
    curl_close($chImg);

    $captchaBase64 = base64_encode($captchaBytes);

    ob_start();
    ?>
    <div class="card-header">
        <h2 class="card-title">Security Verification</h2>
        <p class="card-subtitle">ಕ್ಯಾಪ್ಚಾ ನಮೂದಿಸಿ - Solve the captcha below to request OTP</p>
    </div>
    <form method="POST">
        <div class="captcha-box">
            <img class="captcha-img" src="data:image/jpeg;base64,<?= $captchaBase64 ?>" alt="Security Captcha" height="50">
        </div>
        <div class="form-group">
            <label>Enter Captcha Characters</label>
            <input type="text" name="captcha_code" placeholder="Enter characters above" required maxlength="6" autocomplete="off" autofocus style="text-align:center; font-weight:700; letter-spacing: 3px;">
        </div>
        <button type="submit" name="submit_captcha" class="btn-primary">
            ✓ Submit Captcha & Send OTP
        </button>
    </form>
    <?php
    $bodyHtml = ob_get_clean();
    renderModernPage(4, "Enter Captcha", $bodyHtml);
    exit;
}

// =========================================================================
// STEP 3: SUBMIT MEMBER (REVEALS LANGUAGE)
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_member'])) {
    $selectedMemberVal = trim($_POST['member_val']);
    $cookieFile = $_SESSION['cookie_file'] ?? '';
    $vs = $_SESSION['vs_member'] ?? '';
    $ev = $_SESSION['ev_member'] ?? '';
    $vsg = $_SESSION['vsg'] ?? '58FA0D95';
    $rcNo = $_SESSION['rc_no'] ?? '';

    if (empty($selectedMemberVal) || empty($cookieFile) || empty($vs)) {
        renderModernPage(2, "Server Timeout", '
            <div class="card-header">
                <h2 class="card-title">Server Communication Error</h2>
                <p class="card-subtitle">Unable to submit selected member to the government server.</p>
            </div>
            <a href="?reset_session=1" class="btn-primary">🔄 Change Session & Reconnect</a>
        ', 'Session context expired. Please reset.');
        exit;
    }

    $_SESSION['selected_member'] = $selectedMemberVal;

    $postData = http_build_query([
        '__EVENTTARGET' => '',
        '__EVENTARGUMENT' => '',
        '__LASTFOCUS' => '',
        '__VIEWSTATE' => $vs,
        '__VIEWSTATEGENERATOR' => $vsg,
        '__EVENTVALIDATION' => $ev,
        'ctl00$ContentPlaceHolder1$hidBioInfo' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5' => '',
        'ctl00$ContentPlaceHolder1$txt_rc_no' => $rcNo,
        'ctl00$ContentPlaceHolder1$ddl_mems_detls' => $selectedMemberVal,
        'ctl00$ContentPlaceHolder1$btn_mbrs' => 'GO'
    ]);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $otpVerifyUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Origin: https://ahara.karnataka.gov.in',
        'Referer: ' . $otpVerifyUrl
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    $dom = new DOMDocument(); @$dom->loadHTML($response);
    $xpath = new DOMXPath($dom);

    $_SESSION['vs_lang'] = $xpath->query("//input[@id='__VIEWSTATE']")->item(0)?->getAttribute('value') ?? '';
    $_SESSION['ev_lang'] = $xpath->query("//input[@id='__EVENTVALIDATION']")->item(0)?->getAttribute('value') ?? '';

    ob_start();
    ?>
    <div class="card-header">
        <h2 class="card-title">Choose Preferred Language</h2>
        <p class="card-subtitle">ಭಾಷೆಯನ್ನು ಆಯ್ಕೆ ಮಾಡಿ - Select language for Aadhaar authentication</p>
    </div>
    <form method="POST">
        <div class="radio-group">
            <label class="radio-card">
                <input type="radio" name="lang_val" value="E" checked>
                <div>
                    <div>English</div>
                    <small style="color:var(--text-muted); font-size:11px;">Default portal view</small>
                </div>
            </label>
            <label class="radio-card">
                <input type="radio" name="lang_val" value="K">
                <div>
                    <div>ಕನ್ನಡ (Kannada)</div>
                    <small style="color:var(--text-muted); font-size:11px;">ಕನ್ನಡ ಆವೃತ್ತಿ</small>
                </div>
            </label>
        </div>
        <button type="submit" name="submit_lang" class="btn-primary">
            Continue to Captcha →
        </button>
    </form>
    <?php
    $bodyHtml = ob_get_clean();
    renderModernPage(3, "Choose Language", $bodyHtml);
    exit;
}

// =========================================================================
// STEP 2: HANDLE RC SUBMISSION & PARSE MEMBERS
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_rc'])) {
    $rationCardNumber = trim($_POST['rc_no']);
    $cookieFile = $_SESSION['cookie_file'] ?? '';
    $vs = $_SESSION['vs2'] ?? '';
    $ev = $_SESSION['ev2'] ?? '';
    $vsg = $_SESSION['vsg'] ?? '58FA0D95';

    if (empty($rationCardNumber) || empty($cookieFile) || empty($vs)) {
        renderModernPage(1, "Server Error", '
            <div class="card-header">
                <h2 class="card-title">Government Server Unreachable</h2>
                <p class="card-subtitle">The Ahara server dropped the initial connection session.</p>
            </div>
            <a href="?reset_session=1" class="btn-primary">🔄 Change Session & Retry</a>
        ', 'Failed to communicate with Ahara FCS. Please change server session.');
        exit;
    }

    $_SESSION['rc_no'] = $rationCardNumber;

    $postData = http_build_query([
        '__EVENTTARGET' => '',
        '__EVENTARGUMENT' => '',
        '__LASTFOCUS' => '',
        '__VIEWSTATE' => $vs,
        '__VIEWSTATEGENERATOR' => $vsg,
        '__EVENTVALIDATION' => $ev,
        'ctl00$ContentPlaceHolder1$hidBioInfo' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5' => '',
        'ctl00$ContentPlaceHolder1$rbl_sel_ver_type' => 'WO',
        'ctl00$ContentPlaceHolder1$txt_rc_no' => $rationCardNumber,
        'ctl00$ContentPlaceHolder1$btn_rc' => 'GO'
    ]);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $otpVerifyUrl);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
    curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/x-www-form-urlencoded',
        'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Origin: https://ahara.karnataka.gov.in',
        'Referer: ' . $otpVerifyUrl
    ]);

    $response = curl_exec($ch);
    curl_close($ch);

    $dom = new DOMDocument(); @$dom->loadHTML($response);
    $xpath = new DOMXPath($dom);

    $_SESSION['vs_member'] = $xpath->query("//input[@id='__VIEWSTATE']")->item(0)?->getAttribute('value') ?? '';
    $_SESSION['ev_member'] = $xpath->query("//input[@id='__EVENTVALIDATION']")->item(0)?->getAttribute('value') ?? '';

    $options = $xpath->query("//select[@id='ContentPlaceHolder1_ddl_mems_detls']/option | //select[contains(@name, 'ddl_mems_detls')]/option");

    if ($options->length <= 1) {
        renderModernPage(1, "No Members Found", '
            <div class="card-header">
                <h2 class="card-title">Invalid Card or No Members</h2>
                <p class="card-subtitle">No linked family members found for RC: <strong>' . htmlspecialchars($rationCardNumber) . '</strong></p>
            </div>
            <a href="?reset_session=1" class="btn-primary">🔄 Change Session / Try Another RC</a>
        ', 'Card not found in M-Server districts or server returned empty list.');
        exit;
    }

    ob_start();
    ?>
    <div class="card-header">
        <h2 class="card-title">Select Family Member</h2>
        <p class="card-subtitle">Choose a member whose Aadhaar mobile receives OTP</p>
    </div>
    <form method="POST">
        <div class="form-group">
            <label>Registered Card Members</label>
            <select name="member_val" required>
                <option value="">-- Choose Member Name & UID --</option>
                <?php
                foreach ($options as $opt) {
                    $val = $opt->getAttribute('value');
                    $text = trim($opt->nodeValue);
                    if (!empty($val) && $val !== '-2') {
                        echo "<option value=\"" . htmlspecialchars($val) . "\">" . htmlspecialchars($text) . "</option>";
                    }
                }
                ?>
            </select>
        </div>
        <button type="submit" name="submit_member" class="btn-primary">
            Confirm Member & Continue →
        </button>
    </form>
    <?php
    $bodyHtml = ob_get_clean();
    renderModernPage(2, "Select Member", $bodyHtml);
    exit;
}

// =========================================================================
// STEP 1: INITIALIZE BASE SESSION TOKENS WITH GOVERNMENT SERVER
// =========================================================================
$cookieFile = tempnam(sys_get_temp_dir(), 'net_cookie');
$ch = curl_init();
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_COOKIEJAR, $cookieFile);
curl_setopt($ch, CURLOPT_COOKIEFILE, $cookieFile);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36');

// 1.1: GET Base URL
curl_setopt($ch, CURLOPT_URL, $baseUrl);
$res1 = curl_exec($ch);

$dom = new DOMDocument(); @$dom->loadHTML($res1);
$xpath = new DOMXPath($dom);
$vs1 = $xpath->query("//input[@id='__VIEWSTATE']")->item(0)?->getAttribute('value') ?? '';
$ev1 = $xpath->query("//input[@id='__EVENTVALIDATION']")->item(0)?->getAttribute('value') ?? '';

// 1.2: POST to get main interface page
curl_setopt($ch, CURLOPT_URL, $baseUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    '__VIEWSTATE' => $vs1, 
    '__EVENTVALIDATION' => $ev1, 
    'ctl00$ContentPlaceHolder1$Button2' => 'Submit'
]));
$res2 = curl_exec($ch);

$dom2 = new DOMDocument(); @$dom2->loadHTML($res2);
$xpath2 = new DOMXPath($dom2);
$vs2 = $xpath2->query("//input[@id='__VIEWSTATE']")->item(0)?->getAttribute('value') ?? '';
$ev2 = $xpath2->query("//input[@id='__EVENTVALIDATION']")->item(0)?->getAttribute('value') ?? '';
$vsg2 = $xpath2->query("//input[@id='__VIEWSTATEGENERATOR']")->item(0)?->getAttribute('value') ?? '58FA0D95';

// 1.3: Trigger 'With OTP' (WO) on OTP_VERIFY.aspx
curl_setopt($ch, CURLOPT_URL, $otpVerifyUrl);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    '__EVENTTARGET' => 'ctl00$ContentPlaceHolder1$rbl_sel_ver_type$0',
    '__VIEWSTATE' => $vs2,
    '__VIEWSTATEGENERATOR' => $vsg2,
    '__EVENTVALIDATION' => $ev2,
    'ctl00$ContentPlaceHolder1$rbl_sel_ver_type' => 'WO'
]));
$res3 = curl_exec($ch);
curl_close($ch);

$dom3 = new DOMDocument(); @$dom3->loadHTML($res3);
$xpath3 = new DOMXPath($dom3);
$_SESSION['vs2'] = $xpath3->query("//input[@id='__VIEWSTATE']")->item(0)?->getAttribute('value') ?? '';
$_SESSION['ev2'] = $xpath3->query("//input[@id='__EVENTVALIDATION']")->item(0)?->getAttribute('value') ?? '';
$_SESSION['vsg'] = $vsg2;
$_SESSION['cookie_file'] = $cookieFile;

ob_start();
?>
<div class="card-header">
    <h2 class="card-title">M-Server Ration Card Search</h2>
    <p class="card-subtitle">Food, Civil Supplies & Consumer Affairs Department, Karnataka</p>
</div>

<div class="districts-pill">
    <strong>Supported Districts:</strong> Bagalkote, Belagavi, Vijayapura, Chamarajanagar, Chikamagalur, Dakshina Kannada, Dharwad, Gadag, Haveri, Hassan, Kodagu, Mandya, Mysuru, Udupi, Uttara Kannada
</div>

<form method="POST">
    <div class="form-group">
        <label>Ration Card Number (RC No.)</label>
        <input type="text" name="rc_no" placeholder="e.g. 101000XXXXXX" required maxlength="15" autocomplete="off" autofocus>
    </div>
    <button type="submit" name="submit_rc" class="btn-primary">
        🔍 Search Members on M-Server
    </button>
</form>
<?php
$bodyHtml = ob_get_clean();
renderModernPage(1, "Ration Card Search", $bodyHtml);
?>