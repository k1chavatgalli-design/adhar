<?php
/**
 * Karnataka Ahara Ration Card Verification & Print Generator
 * Multi-Server Support: MSER (Mysuru) | BSER (Bengaluru) | KSER (Kalaburagi)
 * Mode: As Per Citizen Request with Live Card Preview
 * PHP 8.0+ | Requires: cURL, DOM, OpenSSL
 */

session_start();
error_reporting(E_ALL);
ini_set('display_errors', '0');

// =========================================================================
// REGIONAL DIVISIONS MAPPING (Covers All 31 Karnataka Districts)
// =========================================================================
$DIVISIONS = [
    'mser' => [
        'name'      => 'MSERVER (Mysuru & Coastal/North-West)',
        'districts' => 'Bagalkote, Belagavi, Vijayapura, Chamarajanagar, Chikamagalur, Dakshina Kannada, Dharwad, Gadag, Haveri, Hassan, Kodagu, Mandya, Mysuru, Udupi, Uttara Kannada'
    ],
    'bser' => [
        'name'      => 'BSERVER (Bengaluru Division)',
        'districts' => 'Bengaluru Urban, Bengaluru Rural, Ramanagara'
    ],
    'kser' => [
        'name'      => 'KSERVER (Kalaburagi & Central)',
        'districts' => 'Ballari, Bidar, Chikkaballapura, Chitradurga, Davanagere, Kalaburagi, Kolar, Koppal, Raichur, Shivamogga, Tumakuru, Yadgir, Vijayanagara'
    ]
];

// Determine active division per citizen request
$selectedDiv = $_SESSION['division'] ?? 'mser';
if (!array_key_exists($selectedDiv, $DIVISIONS)) {
    $selectedDiv = 'mser';
}

$otpVerifyUrl     = "https://ahara.karnataka.gov.in/fcs_verify_{$selectedDiv}/OTP_VERIFY.aspx";
$captchaImageUrl  = "https://ahara.karnataka.gov.in/fcs_verify_{$selectedDiv}/CImage.aspx";
$verifyRcUrl      = "https://ahara.karnataka.gov.in/fcs_verify_{$selectedDiv}/verify_rationcard.aspx";
$dupRcViewUrl     = "https://ahara.karnataka.gov.in/fcs_verify_{$selectedDiv}/ViewRC/dup_rc_view.aspx";
$govtLogoUrl      = "https://ahara.karnataka.gov.in/fcs_verify_{$selectedDiv}/Images/govtlogo.jpg";
const DEFAULT_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36";

// =========================================================================
// SESSION & HELPER FUNCTIONS
// =========================================================================

function sendHttpRequest(string $url, array $options = []): string {
    $ch = curl_init();
    $defaults = [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_ENCODING       => "",
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_USERAGENT      => DEFAULT_USER_AGENT
    ];

    curl_setopt_array($ch, $options + $defaults);
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($response === false) {
        throw new RuntimeException("cURL Error: " . $error);
    }

    return (string)$response;
}

function extractAspNetTokens(string $html): array {
    $dom = new DOMDocument();
    @$dom->loadHTML($html);
    $xpath = new DOMXPath($dom);

    return [
        'vs'  => $xpath->query("//input[@id='__VIEWSTATE']")->item(0)?->getAttribute('value') ?? '',
        'vsg' => $xpath->query("//input[@id='__VIEWSTATEGENERATOR']")->item(0)?->getAttribute('value') ?? '',
        'ev'  => $xpath->query("//input[@id='__EVENTVALIDATION']")->item(0)?->getAttribute('value') ?? ''
    ];
}

/**
 * Accurately detects server-injected alerts while ignoring client-side JS validator functions
 */
function detectPortalError(string $html): ?string {
    if (preg_match('/<script[^>]*>\s*alert\s*\(\s*["\']\s*(.*?)\s*["\']\s*\)\s*;?\s*<\/script>/is', $html, $match)) {
        $alertText = trim($match[1]);
        if (!empty($alertText)) {
            return $alertText;
        }
    }

    if (preg_match_all('/alert\s*\(\s*["\'](.*?)["\']\s*\)/is', $html, $allMatches, PREG_OFFSET_CAPTURE)) {
        foreach ($allMatches[1] as $item) {
            $msg = trim($item[0]);
            $offset = $item[1];
            $preceding = substr($html, max(0, $offset - 250), min(250, $offset));
            if (stripos($preceding, 'function validaterc') === false && stripos($preceding, 'function check_bio') === false && stripos($preceding, 'function') === false) {
                return $msg;
            }
        }
    }

    if (preg_match('/<span[^>]*id=["\'][^"\']*(?:lbl(?:Msg|Error)|Label(?:Msg|Error))[^"\']*["\'][^>]*>(.*?)<\/span>/is', $html, $match)) {
        $text = trim(strip_tags($match[1]));
        if (!empty($text)) {
            return $text;
        }
    }

    return null;
}

function purgeCitizenSession(): void {
    if (!empty($_SESSION['cookie_file']) && file_exists($_SESSION['cookie_file'])) {
        @unlink($_SESSION['cookie_file']);
    }
    $_SESSION = [];
}

/**
 * Builds a styled HTML preview card of the Karnataka Ration Card
 */
function buildRationCardPreviewHtml(string $rcNo, array $members, string $divName): string {
    $rows = '';
    foreach ($members as $idx => $m) {
        $sl = $idx + 1;
        $name = htmlspecialchars($m['name']);
        $status = htmlspecialchars($m['status']);
        $uid = htmlspecialchars($m['uid']);
        $role = ($sl === 1) ? 'Head of Family' : 'Member';

        $rows .= "<tr>
            <td style='padding: 8px; text-align: center; border-bottom: 1px solid #e2e8f0; font-size: 13px;'>{$sl}</td>
            <td style='padding: 8px; font-weight: 600; color: #1e293b; border-bottom: 1px solid #e2e8f0; font-size: 13px;'>{$name}</td>
            <td style='padding: 8px; color: #64748b; border-bottom: 1px solid #e2e8f0; font-size: 12px;'>{$role}</td>
            <td style='padding: 8px; text-align: center; border-bottom: 1px solid #e2e8f0;'><span style='background: #dcfce7; color: #166534; font-size: 11px; font-weight: 700; padding: 2px 8px; border-radius: 9999px;'>{$status}</span></td>
            <td style='padding: 8px; text-align: right; font-family: monospace; color: #475569; border-bottom: 1px solid #e2e8f0; font-size: 13px;'>{$uid}</td>
        </tr>";
    }

    return '
    <div class="rc-preview-card" style="background: #ffffff; border: 2px solid #16a34a; border-radius: 10px; padding: 16px; margin-bottom: 22px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
        <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #22c55e; padding-bottom: 10px; margin-bottom: 12px;">
            <div>
                <div style="font-size: 11px; font-weight: 700; color: #15803d; text-transform: uppercase; letter-spacing: 0.5px;">Govt. of Karnataka • Food & Civil Supplies</div>
                <div style="font-size: 17px; font-weight: 800; color: #0f172a;">e-Ration Card Preview / ಪಡಿತರ ಚೀಟಿ ವಿವರ</div>
            </div>
            <span style="background: #15803d; color: #fff; font-size: 11px; font-weight: 800; padding: 4px 10px; border-radius: 6px;">PHH / BPL</span>
        </div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 8px; background: #f8fafc; padding: 10px; border-radius: 6px; margin-bottom: 12px; font-size: 13px;">
            <div><span style="color: #64748b;">Ration Card No:</span> <b style="color: #15803d; font-size: 14px; letter-spacing: 1px;">' . htmlspecialchars($rcNo) . '</b></div>
            <div><span style="color: #64748b;">Server Region:</span> <b>' . htmlspecialchars($divName) . '</b></div>
            <div><span style="color: #64748b;">Card Status:</span> <b style="color: #16a34a;">ACTIVE (ಸಕ್ರಿಯ)</b></div>
            <div><span style="color: #64748b;">Total Members:</span> <b>' . count($members) . ' Members</b></div>
        </div>
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse; text-align: left;">
                <thead>
                    <tr style="background: #f1f5f9; color: #475569; font-size: 12px; text-transform: uppercase;">
                        <th style="padding: 6px 8px; text-align: center;">#</th>
                        <th style="padding: 6px 8px;">Member Name (ಸದಸ್ಯರ ಹೆಸರು)</th>
                        <th style="padding: 6px 8px;">Relation</th>
                        <th style="padding: 6px 8px; text-align: center;">Status</th>
                        <th style="padding: 6px 8px; text-align: right;">Aadhaar UID</th>
                    </tr>
                </thead>
                <tbody>
                    ' . $rows . '
                </tbody>
            </table>
        </div>
        <div style="font-size: 11px; color: #64748b; margin-top: 10px; text-align: center;">
            ℹ️ <i>To generate and download the official high-resolution government print copy with barcodes & photos, proceed with OTP verification below.</i>
        </div>
    </div>';
}

function renderUI(string $title, string $stepHtml, int $currentStep = 1, ?string $errorMessage = null): void {
    global $DIVISIONS, $selectedDiv;
    $steps = [
        1 => '1. Citizen RC',
        2 => '2. Member',
        3 => '3. Language',
        4 => '4. Captcha',
        5 => '5. OTP',
        6 => '6. Print'
    ];

    header('Content-Type: text/html; charset=UTF-8');
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= htmlspecialchars($title) ?> | Citizen Ration Card Portal</title>
        <style>
            :root {
                --primary: #15803d;
                --primary-hover: #166534;
                --accent: #2563eb;
                --bg: #f1f5f9;
                --card-bg: #ffffff;
                --text-main: #0f172a;
                --text-muted: #64748b;
                --border: #cbd5e1;
                --error: #dc2626;
            }
            * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, sans-serif; }
            body { background: var(--bg); color: var(--text-main); display: flex; flex-direction: column; align-items: center; min-height: 100vh; padding: 30px 16px; }
            .card { background: var(--card-bg); width: 100%; max-width: 600px; border-radius: 12px; border: 1px solid var(--border); box-shadow: 0 10px 25px -5px rgba(0,0,0,0.07); overflow: hidden; }
            .card-header { background: #14532d; color: #fff; padding: 22px 20px; text-align: center; }
            .card-header h1 { font-size: 18px; font-weight: 700; letter-spacing: 0.5px; margin-bottom: 4px; }
            .card-header p { font-size: 13px; color: #bbf7d0; }
            .badge-server { display: inline-block; background: #22c55e; color: #052e16; font-size: 11px; font-weight: 800; padding: 2px 10px; border-radius: 9999px; margin-top: 8px; text-transform: uppercase; }
            .step-bar { display: flex; border-bottom: 1px solid var(--border); background: #e2e8f0; padding: 8px 12px; gap: 4px; overflow-x: auto; }
            .step-item { font-size: 11px; font-weight: 600; padding: 4px 8px; border-radius: 4px; color: var(--text-muted); white-space: nowrap; }
            .step-item.active { background: var(--primary); color: #fff; }
            .card-body { padding: 24px 20px; }
            .alert-error { background: #fee2e2; border-left: 4px solid var(--error); color: #991b1b; padding: 12px; border-radius: 4px; font-size: 14px; margin-bottom: 20px; line-height: 1.4; }
            .form-group { margin-bottom: 18px; }
            label { display: block; font-size: 14px; font-weight: 600; margin-bottom: 8px; color: #334155; }
            input[type="text"], select { width: 100%; padding: 12px 14px; font-size: 15px; border: 1.5px solid var(--border); border-radius: 6px; outline: none; }
            input[type="text"]:focus, select:focus { border-color: var(--primary); }
            .btn { width: 100%; padding: 13px 18px; font-size: 15px; font-weight: 600; border: none; border-radius: 6px; cursor: pointer; transition: background 0.2s; text-decoration: none; display: block; text-align: center; }
            .btn-primary { background: var(--primary); color: #fff; }
            .btn-primary:hover { background: var(--primary-hover); }
            .btn-secondary { background: #64748b; color: #fff; margin-top: 10px; }
            .btn-secondary:hover { background: #475569; }
            .radio-label { display: flex; align-items: center; gap: 10px; padding: 10px; border: 1px solid var(--border); border-radius: 6px; margin-bottom: 8px; cursor: pointer; font-size: 14px; }
            .radio-label:hover { background: #f8fafc; }
            .captcha-box { text-align: center; margin: 15px 0; }
            .captcha-box img { border: 1px solid var(--border); border-radius: 6px; padding: 4px; background: #fff; }
            .session-bar { display: flex; justify-content: space-between; align-items: center; font-size: 12px; color: var(--text-muted); margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px dashed var(--border); }
            .session-bar a { color: var(--accent); text-decoration: none; font-weight: 600; }
        </style>
    </head>
    <body>
        <div class="card">
            <div class="card-header">
                <h1>KARNATAKA AHARA CITIZEN PORTAL</h1>
                <p>Public Distribution System - Citizen Verification Request</p>
                <div class="badge-server"><?= htmlspecialchars($DIVISIONS[$selectedDiv]['name']) ?></div>
            </div>
            <div class="step-bar">
                <?php foreach ($steps as $stepNum => $stepName): ?>
                    <span class="step-item <?= $stepNum === $currentStep ? 'active' : '' ?>"><?= $stepName ?></span>
                <?php endforeach; ?>
            </div>
            <div class="card-body">
                <div class="session-bar">
                    <span>Active Server: <b><?= strtoupper($selectedDiv) ?></b></span>
                    <a href="?action=new_citizen">🔄 Switch Citizen / Reset Session</a>
                </div>
                <?php if ($errorMessage): ?>
                    <div class="alert-error">⚠️ <?= htmlspecialchars($errorMessage) ?></div>
                <?php endif; ?>
                <?= $stepHtml ?>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// =========================================================================
// SESSION RESET HANDLER (FOR NEW CITIZEN REQUEST)
// =========================================================================
if (isset($_GET['action']) && in_array($_GET['action'], ['new_citizen', 'restart'])) {
    purgeCitizenSession();
    session_destroy();
    $targetUrl = strtok($_SERVER["REQUEST_URI"], '?');
    if (!empty($_GET['rc_no'])) {
        $targetUrl .= '?rc_no=' . urlencode($_GET['rc_no']);
    }
    header("Location: " . $targetUrl);
    exit;
}

// =========================================================================
// STEP 6: VERIFY OTP -> AS PER CITIZEN REQUEST CARD GENERATOR
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_final_otp'])) {
    $otpCode        = trim($_POST['otp_code'] ?? '');
    $cookieFile     = $_SESSION['cookie_file'] ?? '';
    $tokens         = $_SESSION['tokens_otp'] ?? [];
    $rcNo           = $_SESSION['rc_no'] ?? '';
    $selectedMember = $_SESSION['selected_member'] ?? '';
    $selectedLang   = $_SESSION['selected_lang'] ?? 'E';

    if (empty($otpCode) || empty($cookieFile) || empty($tokens['vs'])) {
        renderUI("Session Expired", "<p>Citizen session expired. Please restart the request.</p><a href='?action=new_citizen' class='btn btn-secondary'>New Citizen Request</a>", 5, "Session expired.");
    }

    $postOtp = [
        '__EVENTTARGET'                               => 'ctl00$ContentPlaceHolder1$btn_opt',
        '__EVENTARGUMENT'                             => '',
        '__LASTFOCUS'                                 => '',
        '__VIEWSTATE'                                 => $tokens['vs'],
        '__VIEWSTATEGENERATOR'                        => $tokens['vsg'],
        '__EVENTVALIDATION'                           => $tokens['ev'],
        'ctl00$ContentPlaceHolder1$hidBioInfo'        => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1'       => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2'       => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3'       => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4'       => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5'       => '',
        'ctl00$ContentPlaceHolder1$ddl_mems_detls'    => $selectedMember,
        'ctl00$ContentPlaceHolder1$rbl_lang'          => $selectedLang,
        'ctl00$ContentPlaceHolder1$txt_captcha'       => '',
        'ctl00$ContentPlaceHolder1$rblAadhaarConsent' => 'Y',
        'ctl00$ContentPlaceHolder1$txt_otp'           => $otpCode
    ];

    $resOtpPage = sendHttpRequest($otpVerifyUrl, [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => http_build_query($postOtp),
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => $otpVerifyUrl,
        CURLOPT_HTTPHEADER => ['Origin: https://ahara.karnataka.gov.in', 'Content-Type: application/x-www-form-urlencoded']
    ]);

    $portalError = detectPortalError($resOtpPage);
    if ($portalError && stripos($portalError, 'success') === false) {

        // Auto-detect government ration card migration/renumbering
        if (preg_match('/new\s*Ration\s*Card\s*Number\s*is\s*:\s*([0-9A-Za-z]+)/i', $portalError, $newRcMatch)) {
            $newRc = trim($newRcMatch[1]);
            purgeCitizenSession();
            session_destroy();
            $migrationHtml = '
            <div style="background: #f0fdf4; border: 1.5px solid #86efac; border-radius: 8px; padding: 18px; margin-bottom: 20px;">
                <h3 style="color: #166534; font-size: 16px; margin-bottom: 8px;">🔄 Card Renumbered by Government</h3>
                <p style="font-size: 14px; color: #1e293b; line-height: 1.5; margin-bottom: 14px;">
                    ' . htmlspecialchars($portalError) . '
                </p>
                <div style="background: #ffffff; padding: 14px; border-radius: 6px; border: 1px dashed #22c55e; text-align: center; margin-bottom: 18px;">
                    <span style="font-size: 13px; color: var(--text-muted); display: block; margin-bottom: 4px;">Your Official New Ration Card Number:</span>
                    <strong style="font-size: 22px; color: #15803d; letter-spacing: 2px;">' . htmlspecialchars($newRc) . '</strong>
                </div>
                <a href="?action=new_citizen&rc_no=' . urlencode($newRc) . '" class="btn btn-primary" style="font-size: 16px;">👉 Proceed With New Card (' . htmlspecialchars($newRc) . ')</a>
                <a href="?action=new_citizen" class="btn btn-secondary">Start Over</a>
            </div>';
            renderUI("Card Renumbered", $migrationHtml, 1, null);
        }

        $tokensOtp = extractAspNetTokens($resOtpPage);
        if (!empty($tokensOtp['vs'])) {
            $_SESSION['tokens_otp'] = $tokensOtp;
        }
        $html = '<form method="POST">
            <div class="form-group">
                <label>Enter 6-Digit OTP / OTP ನಮೂದಿಸಿ:</label>
                <input type="text" name="otp_code" placeholder="000000" maxlength="6" pattern="[0-9]{6}" autofocus required autocomplete="off" style="text-align:center; font-size: 24px; letter-spacing: 4px;">
            </div>
            <button type="submit" name="submit_final_otp" class="btn btn-primary">Verify OTP (GO)</button>
            <a href="?action=new_citizen" class="btn btn-secondary">Cancel & Restart</a>
        </form>';
        renderUI("Enter OTP", $html, 5, $portalError);
    }

    $verifyHtml = sendHttpRequest($verifyRcUrl, [
        CURLOPT_HTTPGET    => true,
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => $otpVerifyUrl
    ]);

    $tokensVerify = extractAspNetTokens($verifyHtml);

    $postLnk = [
        '__EVENTTARGET'        => 'lnkRCDetails',
        '__EVENTARGUMENT'      => '',
        '__LASTFOCUS'          => '',
        '__VIEWSTATE'          => $tokensVerify['vs'],
        '__VIEWSTATEGENERATOR' => !empty($tokensVerify['vsg']) ? $tokensVerify['vsg'] : 'DE58201B',
        '__EVENTVALIDATION'    => $tokensVerify['ev'],
        'txt_rc_no'            => $rcNo
    ];

    $resAfterLnk = sendHttpRequest($verifyRcUrl, [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => http_build_query($postLnk),
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => $verifyRcUrl,
        CURLOPT_HTTPHEADER => ['Origin: https://ahara.karnataka.gov.in', 'Content-Type: application/x-www-form-urlencoded']
    ]);

    $dupRcResponse = sendHttpRequest($dupRcViewUrl, [
        CURLOPT_HTTPGET    => true,
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => $verifyRcUrl
    ]);

    $hasPopulatedCard = (stripos($dupRcResponse, 'Incorrect RC!') === false && stripos($dupRcResponse, 'tblRCard') !== false);
    $rawCardHtml = $hasPopulatedCard ? $dupRcResponse : (stripos($resAfterLnk, 'tblRCard') !== false ? $resAfterLnk : null);

    if (!$rawCardHtml) {
        renderUI("Failed to Retrieve Card", "<p>Could not extract the Ration Card view. Please verify the card number and server region.</p><a href='?action=new_citizen' class='btn btn-secondary'>New Citizen Request</a>", 6, "Card layout not found for active region.");
    }

    // Strip specimen and watermark artifacts
    $rawCardHtml = preg_replace('/<div[^>]*>\s*<img[^>]*specimen\.png[^>]*>\s*<\/div>/is', '', $rawCardHtml);
    $rawCardHtml = preg_replace('/<img[^>]*specimen\.png[^>]*>/is', '', $rawCardHtml);
    $rawCardHtml = preg_replace('/<img[^>]*id=["\'](?:Img1|im)["\'][^>]*>/is', '', $rawCardHtml);

    // Member photos to base64 Data URIs
    if (preg_match_all('/src=["\'](get_rc_img\.aspx\?[^"\']+)["\']/i', $rawCardHtml, $imgMatches)) {
        $uniqueImgPaths = array_unique($imgMatches[1]);
        foreach ($uniqueImgPaths as $relImgPath) {
            $fullImgUrl = "https://ahara.karnataka.gov.in/fcs_verify_{$selectedDiv}/ViewRC/" . html_entity_decode($relImgPath);
            try {
                $rawImgBytes = sendHttpRequest($fullImgUrl, [
                    CURLOPT_COOKIEFILE => $cookieFile,
                    CURLOPT_REFERER    => $dupRcViewUrl
                ]);
                if (!empty($rawImgBytes) && strlen($rawImgBytes) > 150) {
                    $base64Img = 'data:image/jpeg;base64,' . base64_encode($rawImgBytes);
                    $rawCardHtml = str_replace($relImgPath, $base64Img, $rawCardHtml);
                }
            } catch (Exception $e) {}
        }
    }

    // Emblem to base64 Data URI
    $govtLogoRel = '../Images/govtlogo.jpg';
    if (strpos($rawCardHtml, $govtLogoRel) !== false) {
        try {
            $logoBytes = sendHttpRequest($govtLogoUrl);
            if (!empty($logoBytes)) {
                $base64Logo = 'data:image/jpeg;base64,' . base64_encode($logoBytes);
                $rawCardHtml = str_replace($govtLogoRel, $base64Logo, $rawCardHtml);
            }
        } catch (Exception $e) {}
    }

    purgeCitizenSession();
    session_destroy();

    $disclaimerTable = '<table style="margin-top: 15px;">
        <tbody><tr>
            <td align="center" style="width: 843.7px;font-size:8pt;font-family: Verdana;">Disclaimer: This Ration card is issued only for the purpose of drawing entitled quantity of Food grains from the Fair Price shop by the card holder. The Personal details of the card holder are based on self declaration of the card holder. The Department of Food, Civil Supplies and Consumer Affairs does not certify the correctness of the particulars furnished.</td>
        </tr></tbody>
    </table>';

    $rawCardHtml = preg_replace('/<table[^>]*>\s*<tr>\s*<td[^>]*align=["\']center["\'][^>]*>\s*<input[^>]*btnExit[^>]*>.*?<\/table>/is', $disclaimerTable, $rawCardHtml);

    if (stripos($rawCardHtml, '<div id="rc-container">') === false && stripos($rawCardHtml, '<table id="tblRCard"') !== false) {
        $rawCardHtml = preg_replace('/(<center>\s*)(<table id="tblRCard".*?<\/table>\s*<table.*?<\/table>)(\s*<\/center>)/is', '<div id="rc-container"><center>$2</center></div>', $rawCardHtml);
    }

    $bplPrintEngine = '
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    function _x(STR_XPATH) {
        var xresult = document.evaluate(STR_XPATH, document, null, XPathResult.ANY_TYPE, null);
        var xnodes = [];
        var xres;
        while (xres = xresult.iterateNext()) { xnodes.push(xres); }
        return xnodes;
    }

    $(document).ready(function() {
        var card_type = $("#lblCardType1").text();

        if (card_type.indexOf("Antyodaya") !== -1) {
            $("<span id=\"Label16\" style=\"font-size:18pt;font-weight:bold;\">AAY</span><div style=\"height:1px; clear:both\"></div>").insertBefore("#lblAckNo");
            $("#tblRCard").attr("style", "font-family: Verdana; font-size: 8pt; height: 566.93px; vertical-align: top;padding-top: 20px;");
            $("#lblCardType1").html("Antyodaya Anna Yojane Not Eligible for Kerosene as per citizen request");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[2]")).attr("style", "width: 47.79px;height: 570px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]")).attr("style", "border: 1px solid #F5A9A9;padding: 0px;background-color: #F5A9A9;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr[1]/td[3]/table/tbody/tr[1]/td/table")).attr("style", "height: 100px;background-color:#FA5858;color:white !important;border-radius:0px 0px 20px 20px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[4]/td/table")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[5]")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]")).attr("style", "width: 380.95px; height: 100%; padding-left: 20px;border: 1px solid #F5A9A9;padding: 5px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/table")).attr("style", "height: 431.69px; width: 331.63px;border: 5px double #F5A9A9;");
            $("#Table1").attr("style", "width: 360.63px; height: 110px; font-size: 8pt;background-color: #F5A9A9;color: #000;border-radius: 20px 20px 0px 0px;margin-top:30px");
        } else if (card_type.indexOf("Non-Priority") !== -1 || card_type.indexOf("NPHH") !== -1) {
            $("<span id=\"Label16\" style=\"font-size:18pt;font-weight:bold;\">NPHH</span><div style=\"height:1px; clear:both\"></div>").insertBefore("#lblAckNo");
            $("#tblRCard").attr("style", "font-family: Verdana; font-size: 8pt; height: 566.93px; vertical-align: top;padding-top: 20px;");
            $("#lblCardType1").html("Non Priority Household Not Eligible for Kerosene Opted to draw Ration as per citizen request");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[2]")).attr("style", "width: 47.79px;height: 570px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]")).attr("style", "border: 1px solid #C8C4E7;padding: 0px;background-color: #C8C4E7;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr[1]/td[3]/table/tbody/tr[1]/td/table")).attr("style", "height: 100px;background-color:#6D87D2;color:white !important;border-radius:0px 0px 20px 20px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[4]/td/table")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[5]")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]")).attr("style", "width: 380.95px; height: 100%; padding-left: 20px;border: 1px solid #C8C4E7;padding: 5px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/table")).attr("style", "height: 431.69px; width: 331.63px;border: 5px double #C8C4E7;");
            $("#Table1").attr("style", "width: 360.63px; height: 110px; font-size: 8pt;background-color: #C8C4E7;color: #000;border-radius: 20px 20px 0px 0px;margin-top:30px");
        } else {
            $("<span id=\"Label16\" style=\"font-size:18pt;font-weight:bold;\">PHH</span><div style=\"height:1px; clear:both\"></div>").insertBefore("#lblAckNo");
            $("#tblRCard").attr("style", "font-family: Verdana; font-size: 8pt; height: 566.93px; vertical-align: top;padding-top: 20px;");
            $("#lblCardType1").html("Priority Household Not Eligible for Kerosene as per citizen request");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[2]")).attr("style", "width: 47.79px;height: 570px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]")).attr("style", "border: 1px solid #7eab74;padding: 0px;background-color: #aabd9d;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr[1]/td[3]/table/tbody/tr[1]/td/table")).attr("style", "height: 100px;background-color:#3f652a;color: white !important;border-radius:0px 0px 20px 20px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[4]/td/table")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[5]")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]")).attr("style", "width: 380.95px; height: 100%; padding-left: 20px;border: 1px solid #7eab74;padding: 5px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/table")).attr("style", "height: 431.69px; width: 331.63px;border: 5px double #7eab74;");
            $("#Table1").attr("style", "width: 360.63px; height: 110px; font-size: 8pt;background-color: #aabd9d;color: #000;border-radius: 20px 20px 0px 0px;margin-top:30px");
        }
        $(_x("/html/.//*[@id=\"Table3\"]/tbody/tr/td[1]")).attr("style", "width: 213px;");
        $("#lblPhNo").attr("style", "font-size: 8pt;");
    });

    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var w = window.open();
        w.document.write("<html><head><title>Print Ration Card</title>");
        w.document.write("<style>" + document.getElementById("style").innerHTML + "</style>");
        w.document.write("<style>@page { size: A4; margin: 2mm; } body { margin: 0; padding: 0; }</style>");
        w.document.write("</head><body><center>");
        w.document.write(printContents);
        w.document.write("</center></body></html>");
        w.document.close();
        w.focus();
        setTimeout(function() { w.print(); w.close(); }, 400);
    }
    </script>
    <style id="style" type="text/css">
        #tblRCard > tbody > tr > td > table > tbody > tr > td:nth-child(3) > table > tbody > tr:nth-child(1) > td > table { color: white !important; }
        #tblRCard > tbody > tr > td > table > tbody > tr > td:nth-child(3) > table > tbody > tr:nth-child(1) > td > table > tbody > tr:nth-child(1) > td > table { color: white !important; }
        #tblRCard > tbody > tr > td > table > tbody > tr > td:nth-child(3) > table > tbody > tr:nth-child(1) > td > table > tbody > tr:nth-child(2) > td > table > tbody > tr > td > table { color: white !important; }
    </style>
    <style type="text/css" media="print">
        @page { size: A4; margin: 2mm; }
        #print-toolbar { display: none !important; }
    </style>
    <div id="print-toolbar" style="margin: 25px 0; text-align: center; font-family: sans-serif;">
        <button onclick="printDiv(\'rc-container\')" style="background: #15803d; color: white; border: none; padding: 12px 28px; font-size: 16px; font-weight: bold; border-radius: 6px; cursor: pointer; margin-right: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);">🖨️ Print / Download PDF</button>
        <button onclick="window.location.href=\'?action=new_citizen\'" style="background: #475569; color: white; border: none; padding: 12px 22px; font-size: 16px; font-weight: bold; border-radius: 6px; cursor: pointer;">👤 New Citizen Request</button>
    </div>
    ';

    if (stripos($rawCardHtml, '</body>') !== false) {
        $rawCardHtml = str_ireplace('</body>', $bplPrintEngine . '</body>', $rawCardHtml);
    } else {
        $rawCardHtml .= $bplPrintEngine;
    }

    @file_put_contents(__DIR__ . '/BPL_Print.html', $rawCardHtml);
    echo $rawCardHtml;
    exit;
}

// =========================================================================
// STEP 5: SUBMIT CAPTCHA -> AUTO-CONSENT -> AUTO-AUTH TYPE (OTP)
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_captcha'])) {
    $captchaCode    = trim($_POST['captcha_code'] ?? '');
    $cookieFile     = $_SESSION['cookie_file'] ?? '';
    $tokens         = $_SESSION['tokens_captcha'] ?? [];
    $rcNo           = $_SESSION['rc_no'] ?? '';
    $selectedMember = $_SESSION['selected_member'] ?? '';
    $selectedLang   = $_SESSION['selected_lang'] ?? 'E';

    if (empty($captchaCode) || empty($cookieFile) || empty($tokens['vs'])) {
        renderUI("Session Expired", "<p>Citizen session context missing.</p><a href='?action=new_citizen' class='btn btn-secondary'>Start Over</a>", 4, "Session context missing.");
    }

    $postCaptcha = [
        '__EVENTTARGET'                         => '',
        '__EVENTARGUMENT'                       => '',
        '__LASTFOCUS'                           => '',
        '__VIEWSTATE'                           => $tokens['vs'],
        '__VIEWSTATEGENERATOR'                  => $tokens['vsg'],
        '__EVENTVALIDATION'                     => $tokens['ev'],
        'ctl00$ContentPlaceHolder1$hidBioInfo'  => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5' => '',
        'ctl00$ContentPlaceHolder1$txt_rc_no'   => $rcNo,
        'ctl00$ContentPlaceHolder1$ddl_mems_detls' => $selectedMember,
        'ctl00$ContentPlaceHolder1$rbl_lang'    => $selectedLang,
        'ctl00$ContentPlaceHolder1$txt_captcha' => $captchaCode,
        'ctl00$ContentPlaceHolder1$btn_captcha' => 'GO'
    ];

    $resConsentPage = sendHttpRequest($otpVerifyUrl, [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => http_build_query($postCaptcha),
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => $otpVerifyUrl,
        CURLOPT_HTTPHEADER => ['Origin: https://ahara.karnataka.gov.in', 'Content-Type: application/x-www-form-urlencoded']
    ]);

    $portalErr = detectPortalError($resConsentPage);
    $tokensConsent = extractAspNetTokens($resConsentPage);

    if (empty($tokensConsent['vs']) || ($portalErr && stripos($portalErr, 'captcha') !== false)) {
        renderUI("Invalid Captcha", "<p>" . htmlspecialchars($portalErr ?: "Invalid Captcha code entered.") . "</p><a href='?action=new_citizen' class='btn btn-secondary'>Try Again</a>", 4, "Captcha verification failed.");
    }

    $postConsent = [
        '__EVENTTARGET'                         => 'ctl00$ContentPlaceHolder1$rblAadhaarConsent$0',
        '__EVENTARGUMENT'                       => '',
        '__LASTFOCUS'                           => '',
        '__VIEWSTATE'                           => $tokensConsent['vs'],
        '__VIEWSTATEGENERATOR'                  => $tokensConsent['vsg'],
        '__EVENTVALIDATION'                     => $tokensConsent['ev'],
        'ctl00$ContentPlaceHolder1$hidBioInfo'  => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5' => '',
        'ctl00$ContentPlaceHolder1$txt_rc_no'   => $rcNo,
        'ctl00$ContentPlaceHolder1$ddl_mems_detls' => $selectedMember,
        'ctl00$ContentPlaceHolder1$rbl_lang'    => $selectedLang,
        'ctl00$ContentPlaceHolder1$txt_captcha' => '',
        'ctl00$ContentPlaceHolder1$rblAadhaarConsent' => 'Y'
    ];

    $resAuthTypePage = sendHttpRequest($otpVerifyUrl, [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => http_build_query($postConsent),
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => $otpVerifyUrl,
        CURLOPT_HTTPHEADER => ['Origin: https://ahara.karnataka.gov.in', 'Content-Type: application/x-www-form-urlencoded']
    ]);

    $tokensAuth = extractAspNetTokens($resAuthTypePage);

    $postAuth = [
        '__EVENTTARGET'                         => 'ctl00$ContentPlaceHolder1$rbl_auth_type$0',
        '__EVENTARGUMENT'                       => '',
        '__LASTFOCUS'                           => '',
        '__VIEWSTATE'                           => $tokensAuth['vs'],
        '__VIEWSTATEGENERATOR'                  => $tokensAuth['vsg'],
        '__EVENTVALIDATION'                     => $tokensAuth['ev'],
        'ctl00$ContentPlaceHolder1$hidBioInfo'  => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5' => '',
        'ctl00$ContentPlaceHolder1$txt_rc_no'   => $rcNo,
        'ctl00$ContentPlaceHolder1$ddl_mems_detls' => $selectedMember,
        'ctl00$ContentPlaceHolder1$rbl_lang'    => $selectedLang,
        'ctl00$ContentPlaceHolder1$txt_captcha' => '',
        'ctl00$ContentPlaceHolder1$rblAadhaarConsent' => 'Y',
        'ctl00$ContentPlaceHolder1$rbl_auth_type'     => 'O'
    ];

    $resOtpPage = sendHttpRequest($otpVerifyUrl, [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => http_build_query($postAuth),
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => $otpVerifyUrl,
        CURLOPT_HTTPHEADER => ['Origin: https://ahara.karnataka.gov.in', 'Content-Type: application/x-www-form-urlencoded']
    ]);

    $_SESSION['tokens_otp'] = extractAspNetTokens($resOtpPage);

    $html = '<form method="POST">
        <div style="background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; padding: 12px; border-radius: 6px; font-size: 14px; margin-bottom: 20px;">
            <b>OTP Dispatched:</b> An SMS OTP has been sent to the mobile number registered with the selected member\'s Aadhaar.
        </div>
        <div class="form-group">
            <label>Enter 6-Digit OTP / OTP ನಮೂದಿಸಿ:</label>
            <input type="text" name="otp_code" placeholder="000000" maxlength="6" pattern="[0-9]{6}" autofocus required autocomplete="off" style="text-align:center; font-size: 24px; letter-spacing: 4px;">
        </div>
        <button type="submit" name="submit_final_otp" class="btn btn-primary">Verify OTP & Retrieve Card</button>
        <a href="?action=new_citizen" class="btn btn-secondary">Cancel</a>
    </form>';

    renderUI("Citizen OTP Verification", $html, 5);
}

// =========================================================================
// STEP 4: SUBMIT LANGUAGE & FETCH CAPTCHA
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_lang'])) {
    $selectedLang   = trim($_POST['lang_val'] ?? 'E');
    $cookieFile     = $_SESSION['cookie_file'] ?? '';
    $tokens         = $_SESSION['tokens_lang'] ?? [];
    $selectedMember = $_SESSION['selected_member'] ?? '';
    $rcNo           = $_SESSION['rc_no'] ?? '';

    $_SESSION['selected_lang'] = $selectedLang;

    $eventTarget = ($selectedLang === 'K')
        ? 'ctl00$ContentPlaceHolder1$rbl_lang$1'
        : 'ctl00$ContentPlaceHolder1$rbl_lang$0';

    $postLang = [
        '__EVENTTARGET'                         => $eventTarget,
        '__EVENTARGUMENT'                       => '',
        '__LASTFOCUS'                           => '',
        '__VIEWSTATE'                           => $tokens['vs'],
        '__VIEWSTATEGENERATOR'                  => $tokens['vsg'],
        '__EVENTVALIDATION'                     => $tokens['ev'],
        'ctl00$ContentPlaceHolder1$hidBioInfo'  => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5' => '',
        'ctl00$ContentPlaceHolder1$txt_rc_no'   => $rcNo,
        'ctl00$ContentPlaceHolder1$ddl_mems_detls' => $selectedMember,
        'ctl00$ContentPlaceHolder1$rbl_lang'    => $selectedLang
    ];

    $resCaptchaPage = sendHttpRequest($otpVerifyUrl, [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => http_build_query($postLang),
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => $otpVerifyUrl,
        CURLOPT_HTTPHEADER => ['Origin: https://ahara.karnataka.gov.in', 'Content-Type: application/x-www-form-urlencoded']
    ]);

    $_SESSION['tokens_captcha'] = extractAspNetTokens($resCaptchaPage);

    $captchaBytes = sendHttpRequest($captchaImageUrl, [
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => $otpVerifyUrl
    ]);

    $captchaBase64 = base64_encode($captchaBytes);

    $html = '<form method="POST">
        <p style="font-size: 14px; color: var(--text-muted); margin-bottom: 12px;">Enter the verification code shown in the image:</p>
        <div class="captcha-box">
            <img src="data:image/jpeg;base64,' . $captchaBase64 . '" alt="Security Captcha" width="160">
        </div>
        <div class="form-group">
            <label>Security Code / ಕ್ಯಾಪ್ಚಾ ನಮೂದಿಸಿ:</label>
            <input type="text" name="captcha_code" placeholder="Enter Captcha" maxlength="6" autofocus required autocomplete="off" style="text-align: center; font-size: 20px; letter-spacing: 2px;">
        </div>
        <button type="submit" name="submit_captcha" class="btn btn-primary">Submit Captcha (GO)</button>
        <a href="?action=new_citizen" class="btn btn-secondary">New Citizen Request</a>
    </form>';

    renderUI("Enter Captcha", $html, 4);
}

// =========================================================================
// STEP 3: SUBMIT MEMBER (REVEALS LANGUAGE SELECTION)
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_member'])) {
    $selectedMemberVal = trim($_POST['member_val'] ?? '');
    $cookieFile        = $_SESSION['cookie_file'] ?? '';
    $tokens            = $_SESSION['tokens_member'] ?? [];
    $rcNo              = $_SESSION['rc_no'] ?? '';

    if (empty($selectedMemberVal) || empty($cookieFile) || empty($tokens['vs'])) {
        renderUI("Session Expired", "<p>Citizen session expired. Please restart the request.</p><a href='?action=new_citizen' class='btn btn-secondary'>Start Over</a>", 2, "Session values missing.");
    }

    $_SESSION['selected_member'] = $selectedMemberVal;

    $postMember = [
        '__EVENTTARGET'                         => '',
        '__EVENTARGUMENT'                       => '',
        '__LASTFOCUS'                           => '',
        '__VIEWSTATE'                           => $tokens['vs'],
        '__VIEWSTATEGENERATOR'                  => $tokens['vsg'],
        '__EVENTVALIDATION'                     => $tokens['ev'],
        'ctl00$ContentPlaceHolder1$hidBioInfo'  => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4' => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5' => '',
        'ctl00$ContentPlaceHolder1$txt_rc_no'   => $rcNo,
        'ctl00$ContentPlaceHolder1$ddl_mems_detls' => $selectedMemberVal,
        'ctl00$ContentPlaceHolder1$btn_mbrs'    => 'GO'
    ];

    $resLangPage = sendHttpRequest($otpVerifyUrl, [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => http_build_query($postMember),
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => $otpVerifyUrl,
        CURLOPT_HTTPHEADER => ['Origin: https://ahara.karnataka.gov.in', 'Content-Type: application/x-www-form-urlencoded']
    ]);

    $_SESSION['tokens_lang'] = extractAspNetTokens($resLangPage);

    $html = '<form method="POST">
        <p style="font-size: 14px; margin-bottom: 16px; color: var(--text-muted);">Choose card print language / ಭಾಷೆಯನ್ನು ಆಯ್ಕೆ ಮಾಡಿ:</p>
        <div class="form-group">
            <label class="radio-label">
                <input type="radio" name="lang_val" value="E" checked>
                <span><strong>English</strong> (Default)</span>
            </label>
            <label class="radio-label">
                <input type="radio" name="lang_val" value="K">
                <span><strong>Kannada (ಕನ್ನಡ)</strong></span>
            </label>
        </div>
        <button type="submit" name="submit_lang" class="btn btn-primary">Continue (ಮುಂದುವರಿಯಿರಿ)</button>
        <a href="?action=new_citizen" class="btn btn-secondary">New Citizen Request</a>
    </form>';

    renderUI("Choose Language", $html, 3);
}

// =========================================================================
// STEP 2: SUBMIT RC NUMBER & EXTRACT FAMILY MEMBERS WITH CARD PREVIEW
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_rc'])) {
    $rcNo       = strtoupper(trim(preg_replace('/[^A-Za-z0-9]/', '', $_POST['rc_no'] ?? '')));
    $cookieFile = $_SESSION['cookie_file'] ?? '';
    $tokens     = $_SESSION['tokens_step1'] ?? [];

    if (empty($rcNo) || empty($cookieFile) || empty($tokens['vs'])) {
        renderUI("Error", "<p>Missing session data for citizen. Please restart.</p><a href='?action=new_citizen' class='btn btn-secondary'>Start Over</a>", 1, "Session state invalid.");
    }

    $_SESSION['rc_no'] = $rcNo;

    $postRc = [
        '__EVENTTARGET'                            => '',
        '__EVENTARGUMENT'                          => '',
        '__LASTFOCUS'                              => '',
        '__VIEWSTATE'                              => $tokens['vs'],
        '__VIEWSTATEGENERATOR'                     => $tokens['vsg'],
        '__EVENTVALIDATION'                        => $tokens['ev'],
        'ctl00$ContentPlaceHolder1$hidBioInfo'     => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1'    => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2'    => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3'    => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4'    => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5'    => '',
        'ctl00$ContentPlaceHolder1$rbl_sel_ver_type' => 'WO',
        'ctl00$ContentPlaceHolder1$txt_rc_no'      => $rcNo,
        'ctl00$ContentPlaceHolder1$btn_rc'         => 'GO'
    ];

    $resMemberPage = sendHttpRequest($otpVerifyUrl, [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => http_build_query($postRc),
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => $otpVerifyUrl,
        CURLOPT_HTTPHEADER => ['Origin: https://ahara.karnataka.gov.in', 'Content-Type: application/x-www-form-urlencoded']
    ]);

    $_SESSION['tokens_member'] = extractAspNetTokens($resMemberPage);

    $dom = new DOMDocument();
    @$dom->loadHTML($resMemberPage);
    $xpath = new DOMXPath($dom);
    $options = $xpath->query("//select[contains(@id, 'ddl_mems_detls') or contains(@name, 'ddl_mems_detls')]/option");

    if ($options->length <= 1) {
        $errorMsg = detectPortalError($resMemberPage);

        // Check if migrated/renumbered
        if ($errorMsg && preg_match('/new\s*Ration\s*Card\s*Number\s*is\s*:\s*([0-9A-Za-z]+)/i', $errorMsg, $newRcMatch)) {
            $newRc = trim($newRcMatch[1]);
            purgeCitizenSession();
            session_destroy();
            $migrationHtml = '
            <div style="background: #f0fdf4; border: 1.5px solid #86efac; border-radius: 8px; padding: 18px; margin-bottom: 20px;">
                <h3 style="color: #166534; font-size: 16px; margin-bottom: 8px;">🔄 Card Renumbered by Government</h3>
                <p style="font-size: 14px; color: #1e293b; line-height: 1.5; margin-bottom: 14px;">
                    ' . htmlspecialchars($errorMsg) . '
                </p>
                <div style="background: #ffffff; padding: 14px; border-radius: 6px; border: 1px dashed #22c55e; text-align: center; margin-bottom: 18px;">
                    <span style="font-size: 13px; color: var(--text-muted); display: block; margin-bottom: 4px;">Your Official New Ration Card Number:</span>
                    <strong style="font-size: 22px; color: #15803d; letter-spacing: 2px;">' . htmlspecialchars($newRc) . '</strong>
                </div>
                <a href="?action=new_citizen&rc_no=' . urlencode($newRc) . '" class="btn btn-primary" style="font-size: 16px;">👉 Proceed With New Card (' . htmlspecialchars($newRc) . ')</a>
                <a href="?action=new_citizen" class="btn btn-secondary">Start Over</a>
            </div>';
            renderUI("Card Renumbered", $migrationHtml, 1, null);
        }

        $errorMsg = $errorMsg ?? "No family members found. The card may belong to a different division server (MSER / BSER / KSER) or is inactive.";
        $retryHtml = '
        <div style="margin-bottom: 20px;">
            <p style="color: var(--text-muted); font-size: 14px; margin-bottom: 12px;">Card Number: <b>' . htmlspecialchars($rcNo) . '</b></p>
            <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 20px;">Please verify that the Ration Card number belongs to the <b>' . strtoupper($selectedDiv) . '</b> district coverage, or select a different server division.</p>
            <a href="?action=new_citizen" class="btn btn-primary">Try Another Division / Re-enter Card</a>
        </div>';
        renderUI("Search Ration Card", $retryHtml, 1, $errorMsg);
    }

    $selectOptions = '';
    $parsedMembers = [];
    foreach ($options as $opt) {
        $val = $opt->getAttribute('value');
        $rawTxt = trim($opt->nodeValue);
        if (!empty($val) && $val !== '-2') {
            $selectOptions .= '<option value="' . htmlspecialchars($val) . '">' . htmlspecialchars($rawTxt) . '</option>';

            // Parse: Name(STATUS)[UID:....1234]
            $mName = $rawTxt;
            $mStatus = 'ACTIVE';
            $mUid = 'XXXX-XXXX';
            if (preg_match('/^(.*?)\s*(?:\(([^)]+)\))?\s*(?:\[UID:\.{2,4}(\d+)\])?$/i', $rawTxt, $pMatch)) {
                $mName   = trim($pMatch[1] ?? $rawTxt);
                $mStatus = trim($pMatch[2] ?? 'ACTIVE');
                $mUid    = !empty($pMatch[3]) ? 'XXXX-' . $pMatch[3] : 'XXXX-XXXX';
            }
            $parsedMembers[] = [
                'name'   => $mName,
                'status' => $mStatus,
                'uid'    => $mUid
            ];
        }
    }

    $_SESSION['members_preview'] = $parsedMembers;

    // Generate Ration Card Preview Box
    $previewCardHtml = buildRationCardPreviewHtml($rcNo, $parsedMembers, $DIVISIONS[$selectedDiv]['name']);

    $html = $previewCardHtml . '
    <form method="POST">
        <div class="form-group">
            <label>Select Citizen / Family Member for OTP (ಸದಸ್ಯರನ್ನು ಆಯ್ಕೆಮಾಡಿ):</label>
            <select name="member_val" required>
                <option value="">-- Choose Member for Aadhaar OTP --</option>
                ' . $selectOptions . '
            </select>
            <small style="color: #64748b; font-size: 12px; margin-top: 4px; display: block;">Select the member whose registered mobile is ready to receive the OTP.</small>
        </div>
        <button type="submit" name="submit_member" class="btn btn-primary">Continue to OTP Verification (ಮುಂದುವರಿಯಿರಿ)</button>
        <a href="?action=new_citizen" class="btn btn-secondary">New Citizen Request</a>
    </form>';

    renderUI("Ration Card Preview & Select Member", $html, 2);
}

// =========================================================================
// STEP 1: INITIALIZE NEW CITIZEN SESSION (WITH DIVISION SELECTOR)
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['init_citizen_session'])) {
    $chosenDiv = trim($_POST['division'] ?? 'mser');
    if (array_key_exists($chosenDiv, $DIVISIONS)) {
        $_SESSION['division'] = $chosenDiv;
        $selectedDiv          = $chosenDiv;
        $otpVerifyUrl         = "https://ahara.karnataka.gov.in/fcs_verify_{$selectedDiv}/OTP_VERIFY.aspx";
        $captchaImageUrl      = "https://ahara.karnataka.gov.in/fcs_verify_{$selectedDiv}/CImage.aspx";
        $verifyRcUrl          = "https://ahara.karnataka.gov.in/fcs_verify_{$selectedDiv}/verify_rationcard.aspx";
        $dupRcViewUrl         = "https://ahara.karnataka.gov.in/fcs_verify_{$selectedDiv}/ViewRC/dup_rc_view.aspx";
        $govtLogoUrl          = "https://ahara.karnataka.gov.in/fcs_verify_{$selectedDiv}/Images/govtlogo.jpg";
    }
}

purgeCitizenSession();
$cookieFile = tempnam(sys_get_temp_dir(), 'citizen_ck_');
$_SESSION['cookie_file'] = $cookieFile;
$_SESSION['division']    = $selectedDiv;

try {
    $resInit = sendHttpRequest($otpVerifyUrl, [
        CURLOPT_HTTPGET    => true,
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile
    ]);
    $tokensInit = extractAspNetTokens($resInit);

    $postWo = [
        '__EVENTTARGET'                            => 'ctl00$ContentPlaceHolder1$rbl_sel_ver_type$0',
        '__EVENTARGUMENT'                          => '',
        '__LASTFOCUS'                              => '',
        '__VIEWSTATE'                              => $tokensInit['vs'],
        '__VIEWSTATEGENERATOR'                     => $tokensInit['vsg'],
        '__EVENTVALIDATION'                        => $tokensInit['ev'],
        'ctl00$ContentPlaceHolder1$hidBioInfo'     => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1'    => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2'    => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3'    => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4'    => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5'    => '',
        'ctl00$ContentPlaceHolder1$rbl_sel_ver_type' => 'WO'
    ];

    $resVerifyPage = sendHttpRequest($otpVerifyUrl, [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => http_build_query($postWo),
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => $otpVerifyUrl,
        CURLOPT_HTTPHEADER => ['Origin: https://ahara.karnataka.gov.in', 'Content-Type: application/x-www-form-urlencoded']
    ]);

    $_SESSION['tokens_step1'] = extractAspNetTokens($resVerifyPage);

} catch (Exception $e) {
    renderUI("Server Connectivity Error", "<p>Unable to connect to the Government {$selectedDiv} portal: " . htmlspecialchars($e->getMessage()) . "</p><a href='?action=new_citizen' class='btn btn-secondary'>Retry</a>", 1, "Server communication failure.");
}

$prefillRc = htmlspecialchars($_GET['rc_no'] ?? '');

$divisionOptions = '';
foreach ($DIVISIONS as $key => $info) {
    $sel = ($key === $selectedDiv) ? 'selected' : '';
    $divisionOptions .= "<option value=\"{$key}\" {$sel}>{$info['name']}</option>";
}

$html = '
<form method="POST" style="margin-bottom: 20px; padding-bottom: 15px; border-bottom: 1px solid var(--border);">
    <div class="form-group">
        <label>Select Citizen District Region / ಸರ್ವರ್ ವಿಭಾಗ:</label>
        <select name="division" onchange="this.form.submit()">
            ' . $divisionOptions . '
        </select>
        <input type="hidden" name="init_citizen_session" value="1">
    </div>
    <div style="font-size: 11px; color: var(--text-muted); line-height: 1.4;">
        <b>Current District Coverage:</b> ' . htmlspecialchars($DIVISIONS[$selectedDiv]['districts']) . '
    </div>
</form>

<form method="POST">
    <div class="form-group">
        <label>Enter Ration Card Number / ಪಡಿತರ ಚೀಟಿ ಸಂಖ್ಯೆ:</label>
        <input type="text" name="rc_no" value="' . $prefillRc . '" placeholder="e.g. 540500361602" required maxlength="15" autocomplete="off" autofocus>
    </div>
    <button type="submit" name="submit_rc" class="btn btn-primary">Search & Preview Ration Card (GO)</button>
</form>';

renderUI("Search Ration Card", $html, 1);