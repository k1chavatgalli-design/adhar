<?php
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get JSON input from fetch
    $input = json_decode(file_get_contents('php://input'), true);
    
    $epic = trim($input['epic'] ?? '');
    $mobile = trim($input['mobile'] ?? '');

    if (empty($epic) || empty($mobile)) {
        echo json_encode(['status' => '400', 'message' => 'Missing EPIC or Mobile Number']);
        exit;
    }

    $apidomain = "https://www.apicentre.in";
    $api_key = "0998d9cc658c90d838ac89b28f9ab6c7dbf6469210377819ddfa1b97acd2"; // Your API key

    $url = "$apidomain/api/voter_link_instent?api_key=" . urlencode($api_key) . "&epic=" . urlencode($epic) . "&mobile=" . urlencode($mobile);

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_TIMEOUT => 30
    ]);

    $response = curl_exec($curl);
    $curl_error = curl_error($curl);
    curl_close($curl);

    if ($curl_error) {
        echo json_encode(['status' => '500', 'message' => 'cURL Error: ' . $curl_error]);
    } else {
        echo $response;
    }
} else {
    echo json_encode(['status' => '405', 'message' => 'Method Not Allowed']);
}