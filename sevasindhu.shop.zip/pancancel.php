<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Double PAN Card Cancellation Affidavit Generator</title>
  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- Google Fonts for Modern UI -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Lucide Icons -->
  <script src="https://unpkg.com/lucide@latest"></script>

  <style>
    :root {
      --affidavit-font-size: 14px;
    }

    body {
      font-family: 'Inter', sans-serif;
    }

    /* Legal Document Typography - Bookman Old Style */
    .legal-font {
      font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif;
    }

    .affidavit-title {
      font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif;
      letter-spacing: 0.15em;
    }

    /* Page container styling on screen */
    .page-sheet {
      width: 210mm;
      min-height: 297mm;
      height: 297mm;
      max-height: 297mm;
      background: #ffffff;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
      position: relative;
      box-sizing: border-box;
      overflow: hidden;
      font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif;
      font-size: var(--affidavit-font-size);
    }

    /* Strict A4 Print Specific Styling */
    @page {
      size: A4 portrait;
      margin: 0;
    }

    @media print {
      html, body {
        width: 210mm !important;
        height: 297mm !important;
        margin: 0 !important;
        padding: 0 !important;
        background: #ffffff !important;
        color: #000000 !important;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
        font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif !important;
      }

      .no-print {
        display: none !important;
      }

      main {
        padding: 0 !important;
        margin: 0 !important;
        max-width: 100% !important;
      }

      #preview-container {
        border: none !important;
        box-shadow: none !important;
        margin: 0 !important;
        padding: 0 !important;
        background: transparent !important;
        width: 210mm !important;
        display: block !important;
      }

      .page-sheet {
        box-shadow: none !important;
        border: none !important;
        width: 210mm !important;
        height: 297mm !important;
        max-height: 297mm !important;
        min-height: 297mm !important;
        margin: 0 !important;
        padding: 14mm 18mm !important;
        box-sizing: border-box !important;
        overflow: hidden !important;
        page-break-inside: avoid !important;
        break-inside: avoid !important;
        page-break-after: avoid !important;
        break-after: avoid !important;
        font-size: var(--affidavit-font-size) !important;
        font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif !important;
        transform: scale(var(--doc-scale, 0.96));
        transform-origin: top center;
        zoom: var(--doc-scale, 0.96);
      }

      .keep-together {
        page-break-inside: avoid !important;
        break-inside: avoid !important;
      }
    }
  </style>
</head>
<body class="bg-slate-100 min-h-screen text-slate-800 antialiased selection:bg-amber-100 selection:text-amber-900">

  <!-- Header Navigation (Non-printable) -->
  <header class="no-print bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-30 shadow-md">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3">
      <div class="flex items-center gap-3">
        <div class="p-2 bg-amber-500 text-slate-950 rounded-lg shadow-sm">
          <i data-lucide="scale" class="w-6 h-6"></i>
        </div>
        <div>
          <h1 class="text-base sm:text-lg font-bold tracking-tight">Double PAN Surrender Affidavit Generator</h1>
          <p class="text-xs text-slate-400">Income Tax Department Surrender & Cancellation Format</p>
        </div>
      </div>
      <div class="flex items-center gap-2">
        <button type="button" onclick="scrollToPreview()" class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition">
          <i data-lucide="eye" class="w-4 h-4"></i>
          <span>View Preview</span>
        </button>
        <button type="button" onclick="handlePrint()" class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-medium shadow-sm transition active:scale-95">
          <i data-lucide="printer" class="w-4 h-4"></i>
          <span>Print / Save PDF</span>
        </button>
      </div>
    </div>
  </header>

  <main class="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-8">

    <!-- DATA ENTRY FORM SECTION -->
    <section class="no-print bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      <div class="bg-slate-50 border-b border-slate-200 px-6 py-4 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 class="text-base font-bold text-slate-900 flex items-center gap-2">
            <i data-lucide="file-pen" class="w-4 h-4 text-amber-600"></i>
            Deponent & PAN Cancellation Particulars
          </h2>
          <p class="text-xs text-slate-500 mt-0.5">Edit form parameters to immediately update the affidavit document preview below.</p>
        </div>
        <div class="flex items-center gap-2">
          <button type="button" onclick="resetToDefaultData()" class="inline-flex items-center gap-1 px-3 py-1.5 text-xs text-slate-600 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg transition font-medium">
            <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
            Reset Initial Data
          </button>
        </div>
      </div>

      <form id="affidavit-form" class="p-6 space-y-6" onsubmit="event.preventDefault(); updateAffidavit();">

        <!-- Deponent Personal Details -->
        <div>
          <h3 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <i data-lucide="user" class="w-4 h-4"></i> 1. Deponent Identity
          </h3>
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Deponent Full Name</label>
              <input type="text" id="deponentName" value="MAHESH KORE" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white uppercase tracking-wide">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Aadhaar Number</label>
              <input type="text" id="aadhaarNumber" value="[Aadhaar Redacted]" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white font-mono">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Income Tax Jurisdiction / Division</label>
              <input type="text" id="jurisdiction" value="Belagavi" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div class="sm:col-span-2 md:col-span-3">
              <label class="block text-xs font-semibold text-slate-700 mb-1">Residential Address</label>
              <textarea id="deponentAddress" rows="2" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white" placeholder="Enter full residential address">Near Main Road, Tilakwadi, Belagavi, Karnataka 590006</textarea>
            </div>
          </div>
        </div>

        <hr class="border-slate-200">

        <!-- PAN Details -->
        <div>
          <h3 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <i data-lucide="credit-card" class="w-4 h-4"></i> 2. PAN Information (Retain vs. Surrender)
          </h3>
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div class="p-3 bg-emerald-50 border border-emerald-200 rounded-xl">
              <label class="block text-xs font-bold text-emerald-800 mb-1">PAN to be Retained (Active)</label>
              <input type="text" id="retainedPan" value="CPFPK4582K" maxlength="10" class="w-full text-sm px-3 py-2 bg-white border border-emerald-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 uppercase font-mono font-bold text-emerald-900 tracking-wider">
            </div>

            <div class="p-3 bg-rose-50 border border-rose-200 rounded-xl">
              <label class="block text-xs font-bold text-rose-800 mb-1">PAN to be Cancelled (Duplicate)</label>
              <input type="text" id="cancelledPan" value="KQDPK4500E" maxlength="10" class="w-full text-sm px-3 py-2 bg-white border border-rose-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-rose-500 uppercase font-mono font-bold text-rose-900 tracking-wider">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Execution Place</label>
              <input type="text" id="executionPlace" value="Belagavi" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Affidavit Date</label>
              <input type="text" id="affidavitDate" value="28/10/2026" placeholder="DD/MM/YYYY" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>
          </div>
        </div>

        <hr class="border-slate-200">

        <!-- Controls: Font Size, Stamp Paper Space & Scale -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <!-- Font Size Adjustment -->
          <div class="bg-indigo-50/60 p-4 rounded-xl border border-indigo-200/70 flex flex-col justify-between gap-3">
            <div>
              <label class="text-xs font-semibold text-slate-800 flex items-center justify-between">
                <span class="flex items-center gap-1.5"><i data-lucide="type" class="w-4 h-4 text-indigo-600"></i> Text Font Size:</span>
                <span id="fontSizeDisplay" class="text-indigo-800 font-bold font-mono text-xs bg-white px-2 py-0.5 rounded border border-indigo-200">14 px</span>
              </label>
              <p class="text-[11px] text-slate-500 mt-1">Increase or decrease text size to fill A4 sheet cleanly.</p>
            </div>
            <div class="flex items-center gap-2">
              <button type="button" onclick="adjustFontSize(-1)" class="flex-1 py-1.5 px-3 bg-white border border-indigo-300 rounded-lg hover:bg-indigo-100 text-indigo-950 font-bold text-xs transition flex items-center justify-center gap-1 active:scale-95 shadow-sm">
                <i data-lucide="minus" class="w-3.5 h-3.5"></i> A-
              </button>
              <button type="button" onclick="setFontSize(14)" class="py-1.5 px-2 text-[11px] bg-indigo-100 border border-indigo-300 rounded-lg hover:bg-indigo-200 text-indigo-900 font-semibold transition">
                Reset
              </button>
              <button type="button" onclick="adjustFontSize(1)" class="flex-1 py-1.5 px-3 bg-white border border-indigo-300 rounded-lg hover:bg-indigo-100 text-indigo-950 font-bold text-xs transition flex items-center justify-center gap-1 active:scale-95 shadow-sm">
                <i data-lucide="plus" class="w-3.5 h-3.5"></i> A+
              </button>
            </div>
          </div>

          <!-- Non-Judicial Stamp Paper Space Reserve -->
          <div class="bg-amber-50/50 p-4 rounded-xl border border-amber-200/60 flex flex-col justify-between gap-3">
            <div>
              <label for="topMarginSlider" class="text-xs font-semibold text-slate-800 flex items-center justify-between">
                <span class="flex items-center gap-1.5"><i data-lucide="file-text" class="w-4 h-4 text-amber-600"></i> Stamp Space:</span>
                <span id="topMarginValue" class="text-amber-800 font-mono text-xs bg-white px-1.5 py-0.5 rounded border border-amber-200">0 mm</span>
              </label>
              <p class="text-[11px] text-slate-500 mt-1">Set to 70mm - 90mm when printing on physical e-Stamp papers.</p>
            </div>
            <div class="flex items-center gap-2">
              <input type="range" id="topMarginSlider" min="0" max="90" step="5" value="0" oninput="updateTopMargin(this.value)" class="w-full accent-amber-600 cursor-pointer">
              <button type="button" onclick="setStampPreset(0)" class="px-2 py-1 text-[11px] bg-white border border-slate-300 rounded hover:bg-slate-100 whitespace-nowrap">0mm</button>
              <button type="button" onclick="setStampPreset(75)" class="px-2 py-1 text-[11px] bg-amber-100 border border-amber-300 text-amber-900 rounded hover:bg-amber-200 font-medium whitespace-nowrap">75mm</button>
            </div>
          </div>

          <!-- Page Scale Slider -->
          <div class="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-col justify-between gap-3">
            <div>
              <label for="scaleSlider" class="text-xs font-semibold text-slate-800 flex items-center justify-between">
                <span class="flex items-center gap-1.5"><i data-lucide="maximize-2" class="w-4 h-4 text-slate-600"></i> Page Scale:</span>
                <span id="scaleValue" class="text-slate-800 font-bold font-mono text-xs bg-white px-1.5 py-0.5 rounded border border-slate-300">96%</span>
              </label>
              <p class="text-[11px] text-slate-500 mt-1">Locks layout boundary strictly within standard A4.</p>
            </div>
            <div class="flex items-center gap-2">
              <input type="range" id="scaleSlider" min="85" max="105" step="1" value="96" oninput="updateDocumentScale(this.value)" class="w-full accent-slate-700 cursor-pointer">
              <button type="button" onclick="setDocumentScale(96)" class="px-2 py-1 text-[11px] bg-slate-200 border border-slate-300 text-slate-900 font-bold rounded hover:bg-slate-300">96%</button>
              <button type="button" onclick="setDocumentScale(100)" class="px-2 py-1 text-[11px] bg-white border border-slate-300 rounded hover:bg-slate-100">100%</button>
            </div>
          </div>
        </div>

        <div class="flex flex-wrap items-center justify-end gap-3 pt-2">
          <button type="button" onclick="updateAffidavit()" class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-900 text-white font-medium text-xs hover:bg-slate-800 shadow transition">
            <i data-lucide="refresh-cw" class="w-4 h-4"></i>
            Refresh Document Preview
          </button>
          <button type="button" onclick="handlePrint()" class="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition transform active:scale-95">
            <i data-lucide="printer" class="w-4 h-4"></i>
            Print / Save to PDF
          </button>
        </div>
      </form>
    </section>

    <!-- LIVE DOCUMENT PREVIEW SECTION -->
    <section class="space-y-4">
      <div class="no-print flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-slate-900 flex items-center gap-2">
            <i data-lucide="file-badge" class="w-4 h-4 text-amber-600"></i>
            Document Preview (Exact A4 Single-Sheet Output)
          </h2>
          <p class="text-xs text-slate-500">Bookman Old Style • Aligned strictly to A4 page dimensions</p>
        </div>
        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
          <span class="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
          Exact A4 Fitted
        </span>
      </div>

      <div id="preview-container" class="bg-slate-300/70 p-4 sm:p-8 rounded-2xl border border-slate-300 flex flex-col items-center gap-8 shadow-inner overflow-x-auto">
        
        <!-- A4 Page Sheet -->
        <div id="affidavit-sheet" class="page-sheet rounded-sm p-8 sm:p-12 md:p-14 legal-font leading-relaxed block">
          
          <!-- Stamp Paper Space Reserve -->
          <div id="stamp-space" class="transition-all duration-200" style="height: 0mm;"></div>

          <div class="keep-together">
            <!-- Header Title -->
            <div class="text-center mb-4">
              <h1 class="affidavit-title text-[1.45em] font-black underline tracking-widest uppercase">AFFIDAVIT</h1>
            </div>

            <!-- Preamble -->
            <div class="text-justify mb-4">
              I, <span id="out-deponentName" class="font-bold underline uppercase">MAHESH KORE</span>, residing at <span id="out-deponentAddress" class="font-medium">Near Main Road, Tilakwadi, Belagavi, Karnataka 590006</span>, do hereby solemnly affirm and declare on oath as under:
            </div>

            <!-- Numbered Clauses -->
            <div class="space-y-2.5 text-justify">
              <div class="flex items-start">
                <span class="font-bold min-w-[24px]">1.</span>
                <span>That I am a citizen of India and currently reside at the address mentioned above.</span>
              </div>

              <div class="flex items-start">
                <span class="font-bold min-w-[24px]">2.</span>
                <div>
                  That I was inadvertently issued/obtained two Permanent Account Numbers (PAN) by the Income Tax Department, the details of which are as follows:
                  <div class="ml-4 mt-1 space-y-0.5">
                    <div>- &nbsp;PAN to be Retained (Continuation PAN): <strong id="out-retainedPan" class="font-mono">CPFPK4582K</strong></div>
                    <div>- &nbsp;PAN to be Cancelled (Cancellation PAN): <strong id="out-cancelledPan" class="font-mono">KQDPK4500E</strong></div>
                  </div>
                </div>
              </div>

              <div class="flex items-start">
                <span class="font-bold min-w-[24px]">3.</span>
                <div>
                  That my demographic and identity details are as follows:
                  <div class="ml-4 mt-1 space-y-0.5">
                    <div>- &nbsp;Full Name: <strong id="out-demoName" class="uppercase">MAHESH KORE</strong></div>
                    <div>- &nbsp;Aadhaar Number: <strong id="out-aadhaarNumber" class="font-mono">[Aadhaar Redacted]</strong></div>
                    <div>- &nbsp;Jurisdiction / Division: <strong id="out-jurisdiction">Belagavi</strong></div>
                  </div>
                </div>
              </div>

              <div class="flex items-start">
                <span class="font-bold min-w-[24px]">4.</span>
                <span>That the PAN <strong id="out-retainedPan4" class="font-mono">CPFPK4582K</strong> is my active Permanent Account Number, which I intend to keep and use for all future tax computations, financial transactions, and official filings.</span>
              </div>

              <div class="flex items-start">
                <span class="font-bold min-w-[24px]">5.</span>
                <span>That I hereby surrender the duplicate PAN <strong id="out-cancelledPan5" class="font-mono">KQDPK4500E</strong> for immediate cancellation and deactivation in the records of the Income Tax Department.</span>
              </div>

              <div class="flex items-start">
                <span class="font-bold min-w-[24px]">6.</span>
                <span>That I have not suppressed any material facts and have not used the duplicate PAN (<strong id="out-cancelledPan6" class="font-mono">KQDPK4500E</strong>) for any fraudulent activity, tax evasion, or unlawful purpose.</span>
              </div>

              <div class="flex items-start">
                <span class="font-bold min-w-[24px]">7.</span>
                <span>That I request the Assessing Officer / Income Tax Department, <span id="out-jurisdiction7">Belagavi</span> Division, to kindly cancel/deactivate the duplicate PAN (<strong id="out-cancelledPan7" class="font-mono">KQDPK4500E</strong>) and link/retain PAN <strong id="out-retainedPan7" class="font-mono">CPFPK4582K</strong> as my sole active Permanent Account Number.</span>
              </div>
            </div>

            <!-- Signature and Footer Block (Positioned directly adjacent to end of clause 7) -->
            <div class="mt-6 pt-1">
              <div class="flex justify-between items-end">
                <div class="space-y-1 font-semibold text-[0.95em]">
                  <div>Place: <span id="out-place-footer">Belagavi</span></div>
                  <div>Date: <span id="out-date-footer">28/10/2026</span></div>
                </div>

                <div class="text-right">
                  <div class="h-8"></div>
                  <div class="font-bold tracking-wider uppercase text-[0.95em] border-t border-black pt-1 inline-block min-w-[170px] text-center">
                    DEPONENT<br>
                    <span id="out-deponentSignature" class="text-xs font-normal">(MAHESH KORE)</span>
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>

  </main>

  <footer class="no-print border-t border-slate-200 bg-white py-6 mt-12 text-center text-xs text-slate-500">
    <p>Double PAN Surrender Affidavit Generator • Income Tax Department Format • Single A4 Print Output</p>
  </footer>

  <script>
    let currentFontSize = 14; // default font size in pixels

    const defaultData = {
      deponentName: "MAHESH KORE",
      deponentAddress: "Near Main Road, Tilakwadi, Belagavi, Karnataka 590006",
      aadhaarNumber: "[Aadhaar Redacted]",
      jurisdiction: "Belagavi",
      retainedPan: "CPFPK4582K",
      cancelledPan: "KQDPK4500E",
      executionPlace: "Belagavi",
      affidavitDate: "28/10/2026"
    };

    // Font size controls
    function setFontSize(size) {
      currentFontSize = Math.min(22, Math.max(12, parseInt(size) || 14));
      document.documentElement.style.setProperty('--affidavit-font-size', `${currentFontSize}px`);
      
      const displayElem = document.getElementById('fontSizeDisplay');
      if (displayElem) {
        displayElem.innerText = `${currentFontSize} px`;
      }
    }

    function adjustFontSize(delta) {
      setFontSize(currentFontSize + delta);
    }

    function updateAffidavit() {
      const getVal = (id) => (document.getElementById(id) ? document.getElementById(id).value.trim() : '');

      const name = getVal('deponentName') || 'MAHESH KORE';
      const address = getVal('deponentAddress') || '____________________________________________________';
      const aadhaar = getVal('aadhaarNumber') || '[Aadhaar Redacted]';
      const jurisdiction = getVal('jurisdiction') || 'Belagavi';
      const retained = (getVal('retainedPan') || 'CPFPK4582K').toUpperCase();
      const cancelled = (getVal('cancelledPan') || 'KQDPK4500E').toUpperCase();
      const place = getVal('executionPlace') || 'Belagavi';
      const date = getVal('affidavitDate') || '28/10/2026';

      document.getElementById('out-deponentName').innerText = name;
      document.getElementById('out-deponentAddress').innerText = address;
      document.getElementById('out-demoName').innerText = name;
      document.getElementById('out-deponentSignature').innerText = `(${name})`;
      
      document.getElementById('out-aadhaarNumber').innerText = aadhaar;
      document.getElementById('out-jurisdiction').innerText = jurisdiction;
      document.getElementById('out-jurisdiction7').innerText = jurisdiction;

      document.getElementById('out-retainedPan').innerText = retained;
      document.getElementById('out-retainedPan4').innerText = retained;
      document.getElementById('out-retainedPan7').innerText = retained;

      document.getElementById('out-cancelledPan').innerText = cancelled;
      document.getElementById('out-cancelledPan5').innerText = cancelled;
      document.getElementById('out-cancelledPan6').innerText = cancelled;
      document.getElementById('out-cancelledPan7').innerText = cancelled;

      document.getElementById('out-place-footer').innerText = place;
      document.getElementById('out-date-footer').innerText = date;
    }

    function updateTopMargin(val) {
      const spacer = document.getElementById('stamp-space');
      const text = document.getElementById('topMarginValue');
      const numericVal = Math.min(90, Math.max(0, parseInt(val) || 0));

      if (spacer) spacer.style.height = `${numericVal}mm`;
      if (text) text.innerText = `${numericVal} mm`;
    }

    function setStampPreset(val) {
      const slider = document.getElementById('topMarginSlider');
      if (slider) slider.value = val;
      updateTopMargin(val);
    }

    function updateDocumentScale(val) {
      const numericVal = parseInt(val) || 96;
      const ratio = numericVal / 100;
      document.documentElement.style.setProperty('--doc-scale', ratio);
      
      const scaleValueElem = document.getElementById('scaleValue');
      if (scaleValueElem) scaleValueElem.innerText = `${numericVal}%`;

      const sheet = document.getElementById('affidavit-sheet');
      if (sheet) {
        sheet.style.transform = `scale(${ratio})`;
        sheet.style.transformOrigin = 'top center';
      }
    }

    function setDocumentScale(val) {
      const slider = document.getElementById('scaleSlider');
      if (slider) slider.value = val;
      updateDocumentScale(val);
    }

    function resetToDefaultData() {
      Object.keys(defaultData).forEach(key => {
        const el = document.getElementById(key);
        if (el) el.value = defaultData[key];
      });

      setStampPreset(0);
      setDocumentScale(96);
      setFontSize(14);
      updateAffidavit();
    }

    function scrollToPreview() {
      document.getElementById('preview-container').scrollIntoView({ behavior: 'smooth' });
    }

    function handlePrint() {
      updateAffidavit();
      window.print();
    }

    document.addEventListener('DOMContentLoaded', () => {
      if (window.lucide) {
        lucide.createIcons();
      }

      setFontSize(14);
      updateAffidavit();
      updateDocumentScale(96);

      const inputIds = [
        'deponentName', 'deponentAddress', 'aadhaarNumber', 'jurisdiction',
        'retainedPan', 'cancelledPan', 'executionPlace', 'affidavitDate'
      ];

      inputIds.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
          element.addEventListener('input', updateAffidavit);
        }
      });
    });
  </script>
</body>
</html>