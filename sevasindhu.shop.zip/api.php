<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

if ($action === 'voter_link') {
    $epic = trim($input['epic'] ?? '');
    $mobile = trim($input['mobile'] ?? '');

    if (empty($epic) || empty($mobile)) {
        echo json_encode(['status' => '400', 'message' => 'EPIC Number and Mobile Number are required.']);
        exit;
    }

    $apiKey = "b848a41feea7e111141f76500ada5ff756d2d882a3de1348747a8803398c";
    $url = "https://www.apicentre.in/api/voter_link_instent?api_key=" . urlencode($apiKey) . "&epic=" . urlencode($epic) . "&mobile=" . urlencode($mobile);

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_TIMEOUT => 30
    ]);
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        echo json_encode(['status' => '500', 'message' => 'cURL Error: ' . $error]);
    } else {
        echo $response;
    }
    exit;
}

if ($action === 'find_pan') {
    $aadhaarNo = trim($input['aadhaar_no'] ?? '');

    if (empty($aadhaarNo)) {
        echo json_encode(['status' => '400', 'message' => 'Aadhaar Number is required.']);
        exit;
    }

    $apiKey = "0998d9cc658c90d838ac89b28f9ab6c7dbf6469210377819ddfa1b97acd2";
    $url = "https://www.apicentre.in/api/aadhaar_to_pan?api_key=" . urlencode($apiKey) . "&aadhaar_no=" . urlencode($aadhaarNo);

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_CUSTOMREQUEST => "GET",
        CURLOPT_TIMEOUT => 30
    ]);
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        echo json_encode(['status' => '500', 'message' => 'cURL Error: ' . $error]);
    } else {
        echo $response;
    }
    exit;
}

echo json_encode(['status' => '400', 'message' => 'Invalid Request Action']);
exit;