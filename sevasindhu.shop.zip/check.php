<?php
/**
 * Karnataka Ahara Ration Card Verification & Print Generator
 * Optimized for Citizen Services (Seva Sindhu / Grama One / CSC)
 * Mode: "As per citizen request"
 * PHP 7.4 - 8.x | Requires: cURL, DOM, OpenSSL
 */

session_start();
error_reporting(E_ALL);
ini_set('display_errors', '0');

// =========================================================================
// CONFIGURATION
// =========================================================================
const BASE_URL          = "https://ahara.karnataka.gov.in/fcs_verify_mser/";
const OTP_VERIFY_URL    = "https://ahara.karnataka.gov.in/fcs_verify_mser/OTP_VERIFY.aspx";
const CAPTCHA_IMAGE_URL = "https://ahara.karnataka.gov.in/fcs_verify_mser/CImage.aspx";
const VERIFY_RC_URL     = "https://ahara.karnataka.gov.in/fcs_verify_mser/verify_rationcard.aspx";
const DUP_RC_VIEW_URL   = "https://ahara.karnataka.gov.in/fcs_verify_mser/ViewRC/dup_rc_view.aspx";
const GOVT_LOGO_URL     = "https://ahara.karnataka.gov.in/fcs_verify_mser/Images/govtlogo.jpg";
const DEFAULT_USER_AGENT= "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36";
const DEFAULT_VSG       = "58FA0D95";

// =========================================================================
// HELPER FUNCTIONS
// =========================================================================

function sendHttpRequest(string $url, array $options = []): string {
    $ch = curl_init();
    $defaults = [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_ENCODING       => "",
        CURLOPT_TIMEOUT        => 35,
        CURLOPT_USERAGENT      => DEFAULT_USER_AGENT
    ];

    curl_setopt_array($ch, $options + $defaults);
    $response = curl_exec($ch);
    $error = curl_error($ch);
    curl_close($ch);

    if ($response === false) {
        throw new RuntimeException("Portal Connection Failed: " . $error);
    }

    return (string)$response;
}

function extractAspNetTokens(string $html, string $fallbackVsg = DEFAULT_VSG): array {
    $dom = new DOMDocument();
    @$dom->loadHTML($html);
    $xpath = new DOMXPath($dom);

    $vs  = $xpath->query("//input[@id='__VIEWSTATE']")->item(0)?->getAttribute('value') ?? '';
    $vsg = $xpath->query("//input[@id='__VIEWSTATEGENERATOR']")->item(0)?->getAttribute('value') ?? '';
    $ev  = $xpath->query("//input[@id='__EVENTVALIDATION']")->item(0)?->getAttribute('value') ?? '';

    return [
        'vs'  => $vs,
        'vsg' => !empty($vsg) ? $vsg : $fallbackVsg,
        'ev'  => $ev
    ];
}

function detectPortalError(string $html): ?string {
    if (preg_match('/alert\([\'"]([^\'"]+)[\'"]\)/i', $html, $match)) {
        return trim($match[1]);
    }
    if (preg_match('/<span[^>]*id=["\'][^"\']*lbl(?:Msg|Error)[^"\']*["\'][^>]*>(.*?)<\/span>/is', $html, $match)) {
        $text = trim(strip_tags($match[1]));
        if (!empty($text)) return $text;
    }
    return null;
}

function cleanupCookie(): void {
    if (!empty($_SESSION['cookie_file']) && file_exists($_SESSION['cookie_file'])) {
        @unlink($_SESSION['cookie_file']);
    }
    unset($_SESSION['cookie_file']);
}

function renderUI(string $title, string $stepHtml, int $currentStep = 1, ?string $errorMessage = null): void {
    $steps = [
        1 => '1. Enter RC',
        2 => '2. Member',
        3 => '3. Language',
        4 => '4. Captcha',
        5 => '5. OTP',
        6 => '6. Print'
    ];

    header('Content-Type: text/html; charset=UTF-8');
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?= htmlspecialchars($title) ?> | Seva Sindhu Citizen Portal</title>
        <style>
            :root {
                --primary: #1e3a8a;
                --primary-hover: #172554;
                --bg: #f8fafc;
                --card-bg: #ffffff;
                --text-main: #0f172a;
                --text-muted: #64748b;
                --border: #e2e8f0;
                --error: #dc2626;
                --success: #16a34a;
            }
            * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; }
            body { background: var(--bg); color: var(--text-main); display: flex; flex-direction: column; align-items: center; min-height: 100vh; padding: 35px 16px; }
            .card { background: var(--card-bg); width: 100%; max-width: 520px; border-radius: 12px; border: 1px solid var(--border); box-shadow: 0 10px 25px -5px rgba(0,0,0,0.06); overflow: hidden; }
            .card-header { background: #0f172a; color: #fff; padding: 22px 20px; text-align: center; }
            .card-header h1 { font-size: 17px; font-weight: 700; letter-spacing: 0.5px; margin-bottom: 4px; }
            .card-header p { font-size: 13px; color: #94a3b8; }
            .step-bar { display: flex; border-bottom: 1px solid var(--border); background: #f1f5f9; padding: 8px 12px; gap: 4px; overflow-x: auto; }
            .step-item { font-size: 11px; font-weight: 600; padding: 4px 8px; border-radius: 4px; color: var(--text-muted); white-space: nowrap; }
            .step-item.active { background: var(--primary); color: #fff; }
            .card-body { padding: 26px 22px; }
            .alert-error { background: #fee2e2; border-left: 4px solid var(--error); color: #991b1b; padding: 12px; border-radius: 4px; font-size: 14px; margin-bottom: 20px; }
            .form-group { margin-bottom: 18px; }
            label { display: block; font-size: 14px; font-weight: 600; margin-bottom: 8px; color: #334155; }
            input[type="text"], select { width: 100%; padding: 12px 14px; font-size: 15px; border: 1.5px solid var(--border); border-radius: 6px; outline: none; }
            input[type="text"]:focus, select:focus { border-color: var(--primary); }
            .btn { width: 100%; padding: 13px 18px; font-size: 15px; font-weight: 600; border: none; border-radius: 6px; cursor: pointer; transition: background 0.2s; }
            .btn-primary { background: var(--primary); color: #fff; }
            .btn-primary:hover { background: var(--primary-hover); }
            .btn-secondary { background: #64748b; color: #fff; margin-top: 10px; text-decoration: none; display: inline-block; text-align: center; }
            .btn-secondary:hover { background: #475569; }
            .radio-label { display: flex; align-items: center; gap: 10px; padding: 10px; border: 1px solid var(--border); border-radius: 6px; margin-bottom: 8px; cursor: pointer; font-size: 14px; }
            .radio-label:hover { background: #f8fafc; }
            .captcha-box { text-align: center; margin: 15px 0; }
            .captcha-box img { border: 1px solid var(--border); border-radius: 6px; padding: 4px; background: #fff; }
            .nav-bar { display: flex; justify-content: space-between; align-items: center; font-size: 12px; color: var(--text-muted); margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px dashed var(--border); }
            .nav-bar a { color: var(--primary); text-decoration: none; font-weight: 600; }
        </style>
    </head>
    <body>
        <div class="card">
            <div class="card-header">
                <h1>KARNATAKA AHARA CITIZEN PORTAL</h1>
                <p>Public Distribution System - Citizen Verification</p>
            </div>
            <div class="step-bar">
                <?php foreach ($steps as $stepNum => $stepName): ?>
                    <span class="step-item <?= $stepNum === $currentStep ? 'active' : '' ?>"><?= $stepName ?></span>
                <?php endforeach; ?>
            </div>
            <div class="card-body">
                <div class="nav-bar">
                    <span>Server: <b>MSERVER (Ahara Karnataka)</b></span>
                    <a href="?action=restart">🔄 New Citizen Request</a>
                </div>
                <?php if ($errorMessage): ?>
                    <div class="alert-error">⚠️ <?= htmlspecialchars($errorMessage) ?></div>
                <?php endif; ?>
                <?= $stepHtml ?>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// Reset / New Citizen Request Handler
if (isset($_GET['action']) && in_array($_GET['action'], ['restart', 'new_citizen'])) {
    cleanupCookie();
    $_SESSION = [];
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
    }
    session_destroy();
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}

// =========================================================================
// STEP 6: VERIFY OTP -> RETRIEVE CARD -> GENERATE BPL_PRINT.HTML
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_final_otp'])) {
    $otpCode        = trim($_POST['otp_code'] ?? '');
    $cookieFile     = $_SESSION['cookie_file'] ?? '';
    $vs             = $_SESSION['vs_otp'] ?? '';
    $ev             = $_SESSION['ev_otp'] ?? '';
    $rcNo           = $_SESSION['rc_no'] ?? '';
    $selectedMember = $_SESSION['selected_member'] ?? '';
    $selectedLang   = $_SESSION['selected_lang'] ?? 'E';

    if (empty($otpCode) || empty($cookieFile) || empty($vs)) {
        renderUI("Session Expired", "<p>Citizen session expired. Please restart.</p><a href='?action=restart' class='btn btn-secondary'>Start Over</a>", 5, "Session expired.");
    }

    // 6.1: Submit OTP with exact browser signature
    $postOtp = [
        '__EVENTTARGET'                               => 'ctl00$ContentPlaceHolder1$btn_opt',
        '__EVENTARGUMENT'                             => '',
        '__LASTFOCUS'                                 => '',
        '__VIEWSTATE'                                 => $vs,
        '__VIEWSTATEGENERATOR'                        => DEFAULT_VSG,
        '__EVENTVALIDATION'                           => $ev,
        'ctl00$ContentPlaceHolder1$hidBioInfo'        => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo1'       => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo2'       => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo3'       => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo4'       => '',
        'ctl00$ContentPlaceHolder1$hidBioInfo5'       => '',
        'ctl00$ContentPlaceHolder1$ddl_mems_detls'    => $selectedMember,
        'ctl00$ContentPlaceHolder1$rbl_lang'          => $selectedLang,
        'ctl00$ContentPlaceHolder1$txt_captcha'       => '',
        'ctl00$ContentPlaceHolder1$rblAadhaarConsent' => 'Y',
        'ctl00$ContentPlaceHolder1$txt_otp'           => $otpCode
    ];

    $resOtpPage = sendHttpRequest(OTP_VERIFY_URL, [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => http_build_query($postOtp),
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => OTP_VERIFY_URL,
        CURLOPT_HTTPHEADER => ['Origin: https://ahara.karnataka.gov.in', 'Content-Type: application/x-www-form-urlencoded']
    ]);

    $portalError = detectPortalError($resOtpPage);
    if ($portalError && stripos($portalError, 'success') === false) {
        $tokensOtp = extractAspNetTokens($resOtpPage);
        if (!empty($tokensOtp['vs'])) {
            $_SESSION['vs_otp'] = $tokensOtp['vs'];
            $_SESSION['ev_otp'] = $tokensOtp['ev'];
        }
        $html = '<form method="POST">
            <div class="form-group">
                <label>Enter 6-Digit OTP / OTP ನಮೂದಿಸಿ:</label>
                <input type="text" name="otp_code" placeholder="000000" maxlength="6" pattern="[0-9]{6}" autofocus required autocomplete="off" style="text-align:center; font-size: 24px; letter-spacing: 4px;">
            </div>
            <button type="submit" name="submit_final_otp" class="btn btn-primary">Verify OTP (GO)</button>
            <a href="?action=restart" class="btn btn-secondary">Cancel & Restart</a>
        </form>';
        renderUI("Enter OTP", $html, 5, "Portal Error: " . $portalError);
    }

    // 6.2: Request verify_rationcard.aspx to establish landing state
    $verifyHtml = sendHttpRequest(VERIFY_RC_URL, [
        CURLOPT_HTTPGET    => true,
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => OTP_VERIFY_URL
    ]);

    $tokensVerify = extractAspNetTokens($verifyHtml, 'DE58201B');

    // 6.3: Postback for lnkRCDetails to bind session keys
    $postLnk = [
        '__EVENTTARGET'        => 'lnkRCDetails',
        '__EVENTARGUMENT'      => '',
        '__LASTFOCUS'          => '',
        '__VIEWSTATE'          => $tokensVerify['vs'],
        '__VIEWSTATEGENERATOR' => $tokensVerify['vsg'],
        '__EVENTVALIDATION'    => $tokensVerify['ev'],
        'txt_rc_no'            => $rcNo
    ];

    $resAfterLnk = sendHttpRequest(VERIFY_RC_URL, [
        CURLOPT_POST       => true,
        CURLOPT_POSTFIELDS => http_build_query($postLnk),
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => VERIFY_RC_URL,
        CURLOPT_HTTPHEADER => ['Origin: https://ahara.karnataka.gov.in', 'Content-Type: application/x-www-form-urlencoded']
    ]);

    // 6.4: Fetch final populated duplicate card
    $dupRcResponse = sendHttpRequest(DUP_RC_VIEW_URL, [
        CURLOPT_HTTPGET    => true,
        CURLOPT_COOKIEJAR  => $cookieFile,
        CURLOPT_COOKIEFILE => $cookieFile,
        CURLOPT_REFERER    => VERIFY_RC_URL
    ]);

    $hasPopulatedCard = (stripos($dupRcResponse, 'Incorrect RC!') === false && stripos($dupRcResponse, 'tblRCard') !== false);
    $rawCardHtml = $hasPopulatedCard ? $dupRcResponse : (stripos($resAfterLnk, 'tblRCard') !== false ? $resAfterLnk : null);

    if (!$rawCardHtml) {
        renderUI("Failed to Retrieve Card", "<p>Could not extract the Ration Card view. Please verify the card number.</p><a href='?action=restart' class='btn btn-secondary'>Start Over</a>", 6, "Card layout (tblRCard) not found.");
    }

    // 6.5: Strip watermark and specimen artifacts
    $rawCardHtml = preg_replace('/<div[^>]*>\s*<img[^>]*specimen\.png[^>]*>\s*<\/div>/is', '', $rawCardHtml);
    $rawCardHtml = preg_replace('/<img[^>]*specimen\.png[^>]*>/is', '', $rawCardHtml);
    $rawCardHtml = preg_replace('/<img[^>]*id=["\'](?:Img1|im)["\'][^>]*>/is', '', $rawCardHtml);

    // 6.6: Fetch & convert member images to base64 Data URIs
    if (preg_match_all('/src=["\'](get_rc_img\.aspx\?[^"\']+)["\']/i', $rawCardHtml, $imgMatches)) {
        $uniqueImgPaths = array_unique($imgMatches[1]);
        foreach ($uniqueImgPaths as $relImgPath) {
            $fullImgUrl = "https://ahara.karnataka.gov.in/fcs_verify_mser/ViewRC/" . html_entity_decode($relImgPath);
            try {
                $rawImgBytes = sendHttpRequest($fullImgUrl, [
                    CURLOPT_COOKIEFILE => $cookieFile,
                    CURLOPT_REFERER    => DUP_RC_VIEW_URL
                ]);
                if (!empty($rawImgBytes) && strlen($rawImgBytes) > 150) {
                    $base64Img = 'data:image/jpeg;base64,' . base64_encode($rawImgBytes);
                    $rawCardHtml = str_replace($relImgPath, $base64Img, $rawCardHtml);
                }
            } catch (Exception $e) {}
        }
    }

    // 6.7: Inline Karnataka Government emblem to base64
    $govtLogoRel = '../Images/govtlogo.jpg';
    if (strpos($rawCardHtml, $govtLogoRel) !== false) {
        try {
            $logoBytes = sendHttpRequest(GOVT_LOGO_URL);
            if (!empty($logoBytes)) {
                $base64Logo = 'data:image/jpeg;base64,' . base64_encode($logoBytes);
                $rawCardHtml = str_replace($govtLogoRel, $base64Logo, $rawCardHtml);
            }
        } catch (Exception $e) {}
    }

    // Clean up temporary cookies and session for this citizen
    cleanupCookie();
    session_destroy();

    // 6.8: Official Disclaimer Table
    $disclaimerTable = '<table style="margin-top: 15px;">
        <tbody><tr>
            <td align="center" style="width: 843.7px;font-size:8pt;font-family: Verdana;">Disclaimer: This Ration card is issued only for the purpose of drawing entitled quantity of Food grains from the Fair Price shop by the card holder. The Personal details of the card holder are based on self declaration of the card holder. The Department of Food, Civil Supplies and Consumer Affairs does not certify the correctness of the particulars furnished.</td>
        </tr></tbody>
    </table>';

    $rawCardHtml = preg_replace('/<table[^>]*>\s*<tr>\s*<td[^>]*align=["\']center["\'][^>]*>\s*<input[^>]*btnExit[^>]*>.*?<\/table>/is', $disclaimerTable, $rawCardHtml);

    if (stripos($rawCardHtml, '<div id="rc-container">') === false && stripos($rawCardHtml, '<table id="tblRCard"') !== false) {
        $rawCardHtml = preg_replace('/(<center>\s*)(<table id="tblRCard".*?<\/table>\s*<table.*?<\/table>)(\s*<\/center>)/is', '<div id="rc-container"><center>$2</center></div>', $rawCardHtml);
    }

    // 6.9: Inject Styling & "as per citizen request" text
    $bplPrintEngine = '
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    function _x(STR_XPATH) {
        var xresult = document.evaluate(STR_XPATH, document, null, XPathResult.ANY_TYPE, null);
        var xnodes = [];
        var xres;
        while (xres = xresult.iterateNext()) { xnodes.push(xres); }
        return xnodes;
    }

    $(document).ready(function() {
        var card_type = $("#lblCardType1").text();

        if (card_type.indexOf("Antyodaya") !== -1) {
            $("<span id=\"Label16\" style=\"font-size:18pt;font-weight:bold;\">AAY</span><div style=\"height:1px; clear:both\"></div>").insertBefore("#lblAckNo");
            $("#tblRCard").attr("style", "font-family: Verdana; font-size: 8pt; height: 566.93px; vertical-align: top;padding-top: 20px;");
            $("#lblCardType1").html("Antyodaya Anna Yojane Not Eligible for Kerosene as per citizen request");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[2]")).attr("style", "width: 47.79px;height: 570px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]")).attr("style", "border: 1px solid #F5A9A9;padding: 0px;background-color: #F5A9A9;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr[1]/td[3]/table/tbody/tr[1]/td/table")).attr("style", "height: 100px;background-color:#FA5858;color:white !important;border-radius:0px 0px 20px 20px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[4]/td/table")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[5]")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]")).attr("style", "width: 380.95px; height: 100%; padding-left: 20px;border: 1px solid #F5A9A9;padding: 5px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/table")).attr("style", "height: 431.69px; width: 331.63px;border: 5px double #F5A9A9;");
            $("#Table1").attr("style", "width: 360.63px; height: 110px; font-size: 8pt;background-color: #F5A9A9;color: #000;border-radius: 20px 20px 0px 0px;margin-top:30px");
        } else if (card_type.indexOf("Non-Priority") !== -1 || card_type.indexOf("NPHH") !== -1) {
            $("<span id=\"Label16\" style=\"font-size:18pt;font-weight:bold;\">NPHH</span><div style=\"height:1px; clear:both\"></div>").insertBefore("#lblAckNo");
            $("#tblRCard").attr("style", "font-family: Verdana; font-size: 8pt; height: 566.93px; vertical-align: top;padding-top: 20px;");
            $("#lblCardType1").html("Non Priority Household Not Eligible for Kerosene Opted to draw Ration as per citizen request");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[2]")).attr("style", "width: 47.79px;height: 570px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]")).attr("style", "border: 1px solid #C8C4E7;padding: 0px;background-color: #C8C4E7;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr[1]/td[3]/table/tbody/tr[1]/td/table")).attr("style", "height: 100px;background-color:#6D87D2;color:white !important;border-radius:0px 0px 20px 20px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[4]/td/table")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[5]")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]")).attr("style", "width: 380.95px; height: 100%; padding-left: 20px;border: 1px solid #C8C4E7;padding: 5px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/table")).attr("style", "height: 431.69px; width: 331.63px;border: 5px double #C8C4E7;");
            $("#Table1").attr("style", "width: 360.63px; height: 110px; font-size: 8pt;background-color: #C8C4E7;color: #000;border-radius: 20px 20px 0px 0px;margin-top:30px");
        } else {
            // Priority Household (Green Theme)
            $("<span id=\"Label16\" style=\"font-size:18pt;font-weight:bold;\">PHH</span><div style=\"height:1px; clear:both\"></div>").insertBefore("#lblAckNo");
            $("#tblRCard").attr("style", "font-family: Verdana; font-size: 8pt; height: 566.93px; vertical-align: top;padding-top: 20px;");
            $("#lblCardType1").html("Priority Household Not Eligible for Kerosene as per citizen request");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[2]")).attr("style", "width: 47.79px;height: 570px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]")).attr("style", "border: 1px solid #7eab74;padding: 0px;background-color: #aabd9d;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr[1]/td[3]/table/tbody/tr[1]/td/table")).attr("style", "height: 100px;background-color:#3f652a;color: white !important;border-radius:0px 0px 20px 20px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[4]/td/table")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[5]")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]")).attr("style", "width: 380.95px; height: 100%; padding-left: 20px;border: 1px solid #7eab74;padding: 5px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/table")).attr("style", "height: 431.69px; width: 331.63px;border: 5px double #7eab74;");
            $("#Table1").attr("style", "width: 360.63px; height: 110px; font-size: 8pt;background-color: #aabd9d;color: #000;border-radius: 20px 20px 0px 0px;margin-top:30px");
        }
        $(_x("/html/.//*[@id=\"Table3\"]/tbody/tr/td[1]")).attr("style", "width: 213px;");
        $("#lblPhNo").attr("style", "font-size: 8pt;");
    });

    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var w = window.open();
        w.document.write("<html><head><title>Print Ration Card</title>");
        w.document.write("<style>" + document.getElementById("style").innerHTML + "</style>");
        w.document.write("<style>@page { size: A4; margin: 2mm; } body { margin: 0; padding: 0; }</style>");
        w.document.write("</head><body><center>");
        w.document.write(printContents);
        w.document.write("</center></body></html>");
        w.document.close();
        w.focus();
        setTimeout(function() { w.print(); w.close(); }, 400);
    }
    </script>
    <style id="style" type="text/css">
        #tblRCard > tbody > tr > td > table > tbody > tr > td:nth-child(3) > table > tbody > tr:nth-child(1) > td > table { color: white !important; }
        #tblRCard > tbody > tr > td > table > tbody > tr > td:nth-child(3) > table > tbody > tr:nth-child(1) > td > table > tbody > tr:nth-child(1) > td > table { color: white !important; }
        #tblRCard > tbody > tr > td > table > tbody > tr > td:nth-child(3) > table > tbody > tr:nth-child(1) > td > table > tbody > tr:nth-child(2) > td > table > tbody > tr > td > table { color: white !important; }
    </style>
    <style type="text/css" media="print">
        @page { size: A4; margin: 2mm; }
        #print-toolbar { display: none !important; }
    </style>
    <div id="print-toolbar" style="margin: 25px 0; text-align: center; font-family: sans-serif;">
        <button onclick="printDiv(\'rc-container\')" style="background: #15803d; color: white; border: none; padding: 12px 28px; font-size: 16px; font-weight: bold; border-radius: 6px; cursor: pointer; margin-right: 12px;">🖨️ Print Ration Card</button>
        <button onclick="window.location.href=\'?action=restart\'" style="background: #475569; color: white; border: none; padding: 12px 22px; font-size: 16px; font-weight: bold; border-radius: 6px; cursor: pointer;">👤 New Citizen Request</button>