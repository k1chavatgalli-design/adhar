<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ESI / Dependent Affidavit Generator</title>
  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Lucide Icons -->
  <script src="https://unpkg.com/lucide@latest"></script>

  <style>
    body {
      font-family: 'Inter', sans-serif;
    }

    /* Legal Document Typography - Bookman Old Style */
    .legal-font {
      font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif;
    }

    .affidavit-title {
      font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif;
      letter-spacing: 0.15em;
    }

    /* Page container styling on screen */
    .page-sheet {
      width: 210mm;
      min-height: 297mm;
      height: 297mm;
      max-height: 297mm;
      background: #ffffff;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
      position: relative;
      box-sizing: border-box;
      overflow: hidden;
      font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif;
    }

    /* Strict A4 Print Specific Styling */
    @page {
      size: A4 portrait;
      margin: 0;
    }

    @media print {
      html, body {
        width: 210mm !important;
        height: 297mm !important;
        margin: 0 !important;
        padding: 0 !important;
        background: #ffffff !important;
        color: #000000 !important;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
        font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif !important;
      }

      .no-print {
        display: none !important;
      }

      main {
        padding: 0 !important;
        margin: 0 !important;
        max-width: 100% !important;
      }

      #preview-container {
        border: none !important;
        box-shadow: none !important;
        margin: 0 !important;
        padding: 0 !important;
        background: transparent !important;
        width: 210mm !important;
        display: block !important;
      }

      .page-sheet {
        box-shadow: none !important;
        border: none !important;
        width: 210mm !important;
        height: 297mm !important;
        max-height: 297mm !important;
        min-height: 297mm !important;
        margin: 0 !important;
        padding: 16mm 20mm !important;
        box-sizing: border-box !important;
        overflow: hidden !important;
        page-break-inside: avoid !important;
        break-inside: avoid !important;
        page-break-after: avoid !important;
        break-after: avoid !important;
        font-family: "Bookman Old Style", "Bookman", "URW Bookman L", "ITC Bookman", Georgia, serif !important;
        transform: scale(var(--doc-scale, 0.96));
        transform-origin: top center;
        zoom: var(--doc-scale, 0.96);
      }

      .keep-together {
        page-break-inside: avoid !important;
        break-inside: avoid !important;
      }
    }
  </style>
</head>
<body class="bg-slate-100 min-h-screen text-slate-800 antialiased selection:bg-amber-100 selection:text-amber-900">

  <!-- Header Navigation -->
  <header class="no-print bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-30 shadow-md">
    <div class="max-w-6xl mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3">
      <div class="flex items-center gap-3">
        <div class="p-2 bg-amber-500 text-slate-950 rounded-lg shadow-sm">
          <i data-lucide="scale" class="w-6 h-6"></i>
        </div>
        <div>
          <h1 class="text-base sm:text-lg font-bold tracking-tight">ESI Dependent Declaration Affidavit Generator</h1>
          <p class="text-xs text-slate-400">Mother / Dependent ESI Medical Claim Format</p>
        </div>
      </div>
      <div class="flex items-center gap-2">
        <button type="button" onclick="scrollToPreview()" class="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition">
          <i data-lucide="eye" class="w-4 h-4"></i>
          <span>View Preview</span>
        </button>
        <button type="button" onclick="handlePrint()" class="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-medium shadow-sm transition active:scale-95">
          <i data-lucide="printer" class="w-4 h-4"></i>
          <span>Print / Save PDF</span>
        </button>
      </div>
    </div>
  </header>

  <main class="max-w-6xl mx-auto px-4 sm:px-6 py-6 space-y-8">

    <!-- DATA ENTRY FORM SECTION -->
    <section class="no-print bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
      <div class="bg-slate-50 border-b border-slate-200 px-6 py-4 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 class="text-base font-bold text-slate-900 flex items-center gap-2">
            <i data-lucide="file-pen" class="w-4 h-4 text-amber-600"></i>
            Data Entry Details
          </h2>
          <p class="text-xs text-slate-500 mt-0.5">Edit form parameters to update the live preview below.</p>
        </div>
        <div class="flex items-center gap-2">
          <button type="button" onclick="resetToDefaultData()" class="inline-flex items-center gap-1 px-3 py-1.5 text-xs text-slate-600 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg transition font-medium">
            <i data-lucide="rotate-ccw" class="w-3.5 h-3.5"></i>
            Reset Initial Data
          </button>
        </div>
      </div>

      <form id="affidavit-form" class="p-6 space-y-6" onsubmit="event.preventDefault(); updateAffidavit();">

        <!-- Insured Person / Deponent Particulars -->
        <div>
          <h3 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <i data-lucide="user" class="w-4 h-4"></i> 1. Insured Person (Deponent) Particulars
          </h3>
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Deponent Name</label>
              <input type="text" id="deponentName" value="SUMEET VINAYAK MUTALIK DESAI" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white uppercase tracking-wide">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Age</label>
              <input type="text" id="deponentAge" value="31 Years" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Occupation / Designation</label>
              <input type="text" id="deponentOccupation" value="CLERK" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white uppercase">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Deponent Aadhaar</label>
              <input type="text" id="deponentAadhaar" value="[Aadhaar Redacted]" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white font-mono">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Insurance / I.P. No.</label>
              <input type="text" id="insuranceNo" value="5858599423" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white font-mono font-semibold">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Employer / Organization</label>
              <input type="text" id="employerName" value="THE BELGAUM URBAN CREDIT SOUHARD SAHAKARI SANGHA LTD" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white uppercase">
            </div>

            <div class="sm:col-span-2 md:col-span-3">
              <label class="block text-xs font-semibold text-slate-700 mb-1">Residential Address</label>
              <textarea id="deponentAddress" rows="2" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">367/B, Bazar Galli, Madhavpur, Vadagaon, Belagavi</textarea>
            </div>
          </div>
        </div>

        <hr class="border-slate-200">

        <!-- Dependent Person Details -->
        <div>
          <h3 class="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 flex items-center gap-1.5">
            <i data-lucide="users" class="w-4 h-4"></i> 2. Dependent Details
          </h3>
          <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div class="md:col-span-2">
              <label class="block text-xs font-semibold text-slate-700 mb-1">Dependent Full Name</label>
              <input type="text" id="dependentName" value="Smt. Kalavati Vinayak Mutalik Desai" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Dependent Age</label>
              <input type="text" id="dependentAge" value="51 Years" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Gender</label>
              <input type="text" id="dependentSex" value="Female" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Dependent Aadhaar</label>
              <input type="text" id="dependentAadhaar" value="[Aadhaar Redacted]" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white font-mono">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Relationship</label>
              <input type="text" id="dependentRelation" value="Mother" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Monthly Income</label>
              <input type="text" id="dependentIncome" value="Rs. NIL" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white font-semibold">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Affidavit Date</label>
              <input type="text" id="affidavitDate" value="15/09/2025" placeholder="DD/MM/YYYY" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>

            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Execution Place</label>
              <input type="text" id="executionPlace" value="Belagavi" class="w-full text-sm px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-amber-500 focus:bg-white">
            </div>
          </div>
        </div>

        <hr class="border-slate-200">

        <!-- Margin & Scale Controls -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div class="bg-amber-50/50 p-4 rounded-xl border border-amber-200/60 flex flex-col justify-between gap-3">
            <div>
              <label for="topMarginSlider" class="text-xs font-semibold text-slate-800 flex items-center gap-2">
                <i data-lucide="file-text" class="w-4 h-4 text-amber-600"></i>
                Non-Judicial Stamp Paper Space Reserve: <span id="topMarginValue" class="text-amber-800 font-mono">0 mm</span>
              </label>
              <p class="text-[11px] text-slate-500 mt-1">Set to 70mm - 85mm when printing directly on stamp paper.</p>
            </div>
            <div class="flex items-center gap-3">
              <input type="range" id="topMarginSlider" min="0" max="90" step="5" value="0" oninput="updateTopMargin(this.value)" class="w-full accent-amber-600 cursor-pointer">
              <div class="flex gap-1">
                <button type="button" onclick="setStampPreset(0)" class="px-2 py-1 text-[11px] bg-white border border-slate-300 rounded hover:bg-slate-100">0mm</button>
                <button type="button" onclick="setStampPreset(75)" class="px-2 py-1 text-[11px] bg-amber-100 border border-amber-300 text-amber-900 rounded hover:bg-amber-200 font-medium">75mm</button>
              </div>
            </div>
          </div>

          <div class="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-col justify-between gap-3">
            <div>
              <label for="scaleSlider" class="text-xs font-semibold text-slate-800 flex items-center gap-2">
                <i data-lucide="maximize-2" class="w-4 h-4 text-amber-600"></i>
                Print / Output Scale: <span id="scaleValue" class="text-amber-800 font-bold font-mono">96%</span>
              </label>
              <p class="text-[11px] text-slate-500 mt-1">Locked to 96% for single A4 page containment.</p>
            </div>
            <div class="flex items-center gap-3">
              <input type="range" id="scaleSlider" min="85" max="105" step="1" value="96" oninput="updateDocumentScale(this.value)" class="w-full accent-amber-600 cursor-pointer">
              <div class="flex gap-1">
                <button type="button" onclick="setDocumentScale(96)" class="px-2.5 py-1 text-[11px] bg-amber-100 border border-amber-300 text-amber-950 font-bold rounded hover:bg-amber-200">96%</button>
                <button type="button" onclick="setDocumentScale(100)" class="px-2 py-1 text-[11px] bg-white border border-slate-300 rounded hover:bg-slate-100">100%</button>
              </div>
            </div>
          </div>
        </div>

        <div class="flex flex-wrap items-center justify-end gap-3 pt-2">
          <button type="button" onclick="updateAffidavit()" class="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-slate-900 text-white font-medium text-xs hover:bg-slate-800 shadow transition">
            <i data-lucide="refresh-cw" class="w-4 h-4"></i>
            Refresh Document Preview
          </button>
          <button type="button" onclick="handlePrint()" class="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition transform active:scale-95">
            <i data-lucide="printer" class="w-4 h-4"></i>
            Print / Save to PDF
          </button>
        </div>
      </form>
    </section>

    <!-- LIVE PREVIEW SECTION -->
    <section class="space-y-4">
      <div class="no-print flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-slate-900 flex items-center gap-2">
            <i data-lucide="file-badge" class="w-4 h-4 text-amber-600"></i>
            Document Preview (Exact A4 Single-Sheet Output)
          </h2>
          <p class="text-xs text-slate-500">Bookman Old Style • Exact A4 Page Structure</p>
        </div>
        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
          <span class="w-1.5 h-1.5 rounded-full bg-emerald-600 animate-pulse"></span>
          Exact A4 Fitted
        </span>
      </div>

      <div id="preview-container" class="bg-slate-300/70 p-4 sm:p-8 rounded-2xl border border-slate-300 flex flex-col items-center gap-8 shadow-inner overflow-x-auto">
        
        <!-- A4 Page Sheet -->
        <div id="affidavit-sheet" class="page-sheet rounded-sm p-8 sm:p-12 md:p-14 legal-font text-[14.5px] leading-relaxed block">
          
          <!-- Stamp Space Spacer -->
          <div id="stamp-space" class="transition-all duration-200" style="height: 0mm;"></div>

          <div class="keep-together">
            <!-- Header Title -->
            <div class="text-center mb-6">
              <h1 class="affidavit-title text-2xl font-black underline tracking-widest uppercase">AFFIDAVIT</h1>
            </div>

            <!-- Introductory Paragraph -->
            <div class="text-justify indent-10 mb-4 leading-loose">
              I <span id="out-deponentName" class="font-bold underline uppercase">SUMEET VINAYAK MUTALIK DESAI</span>, 
              Aadhaar No. <span id="out-deponentAadhaar" class="font-mono font-semibold">[Aadhaar Redacted]</span>, 
              Age: <span id="out-deponentAge" class="font-semibold">31 Years</span>, 
              Occ : <span id="out-deponentOccupation" class="font-semibold uppercase">Staff</span>, 
              R/o: <span id="out-deponentAddress" class="font-medium">367/B, Bazar Galli, Madhavpur, Vadagaon, Belagavi</span>, 
              (I.P No. <span id="out-ipNo" class="font-mono font-semibold">5858599423</span>), 
              today at <span id="out-placeIntro" class="font-semibold">Belagavi</span> do hereby state on solemn affirmation and make the affidavit as under;
            </div>

            <!-- Declaration Statement -->
            <div class="text-justify indent-10 mb-4 leading-loose">
              I <span id="out-deponentName2" class="font-bold uppercase">SUMEET VINAYAK MUTALIK DESAI</span> declare that I am insured Person with Insurance No <span id="out-insuranceNo" class="font-mono font-bold">5858599423</span> working <span id="out-employerName" class="font-bold uppercase">THE BELGAUM URBAN CREDIT SOUHARD SAHAKARI SANGHA LTD</span>, working as <span id="out-designation" class="font-bold uppercase">CLERK</span>.
            </div>

            <!-- Numbered Points -->
            <div class="space-y-3.5 text-justify my-5">
              <div class="flex items-start">
                <span class="font-bold min-w-[28px]">1.</span>
                <span>
                  <strong id="out-dependentName" class="font-bold">Smt. Kalavati Vinayak Mutalik Desai</strong>, 
                  age: <span id="out-dependentAge">51 Years</span>, 
                  Sex: <span id="out-dependentSex">Female</span>, 
                  Aadhaar No: <span id="out-dependentAadhaar" class="font-mono font-semibold">[Aadhaar Redacted]</span>, 
                  my <span id="out-dependentRelation">Mother</span>.
                </span>
              </div>

              <div class="flex items-start">
                <span class="font-bold min-w-[28px]">2.</span>
                <span>
                  <strong id="out-dependentName2">Smt. Kalavati Vinayak Mutalik Desai</strong> is financially depending on me and she has no income.
                </span>
              </div>

              <div class="flex items-start">
                <span class="font-bold min-w-[28px]">3.</span>
                <span>
                  <strong id="out-dependentName3">Smt. Kalavati Vinayak Mutalik Desai</strong> her Monthly income of <span id="out-dependentIncome" class="font-bold">Rs. NIL</span>.
                </span>
              </div>
            </div>

            <!-- Vernacular Clause -->
            <div class="text-justify indent-10 mt-5 leading-loose">
              The contents of affidavit are all read over and explain to me in my vernacular and the same are true and correct to the best of my knowledge and belief.
            </div>

            <!-- Signature Block -->
            <div class="mt-8 pt-2">
              <div class="flex justify-between items-end">
                <div class="space-y-1 text-sm font-semibold">
                  <div>Place: <span id="out-placeFooter">Belagavi</span></div>
                  <div>Date: <span id="out-dateFooter">15/09/2025</span></div>
                </div>

                <div class="text-right">
                  <div class="h-10"></div>
                  <div class="font-bold tracking-wider uppercase text-sm border-t border-black pt-1 inline-block min-w-[170px] text-center">
                    DEPONENT<br>
                    <span id="out-deponentSignature" class="text-xs font-normal">(SUMEET VINAYAK MUTALIK DESAI)</span>
                  </div>
                </div>
              </div>
            </div>

          </div>

        </div>

      </div>
    </section>

  </main>

  <footer class="no-print border-t border-slate-200 bg-white py-6 mt-12 text-center text-xs text-slate-500">
    <p>ESI Dependent Affidavit Generator Form • Bookman Old Style Legal Output</p>
  </footer>

  <script>
    const defaultData = {
      deponentName: "SUMEET VINAYAK MUTALIK DESAI",
      deponentAge: "31 Years",
      deponentOccupation: "Staff",
      deponentAadhaar: "[Aadhaar Redacted]",
      insuranceNo: "5858599423",
      employerName: "THE BELGAUM URBAN CREDIT SOUHARD SAHAKARI SANGHA LTD",
      designation: "CLERK",
      deponentAddress: "367/B, Bazar Galli, Madhavpur, Vadagaon, Belagavi",
      dependentName: "Smt. Kalavati Vinayak Mutalik Desai",
      dependentAge: "51 Years",
      dependentSex: "Female",
      dependentAadhaar: "[Aadhaar Redacted]",
      dependentRelation: "Mother",
      dependentIncome: "Rs. NIL",
      executionPlace: "Belagavi",
      affidavitDate: "15/09/2025"
    };

    function updateAffidavit() {
      const getVal = (id) => (document.getElementById(id) ? document.getElementById(id).value.trim() : '');

      const name = getVal('deponentName') || defaultData.deponentName;
      const age = getVal('deponentAge') || defaultData.deponentAge;
      const occ = getVal('deponentOccupation') || defaultData.deponentOccupation;
      const depAadhaar = getVal('deponentAadhaar') || defaultData.deponentAadhaar;
      const insNo = getVal('insuranceNo') || defaultData.insuranceNo;
      const emp = getVal('employerName') || defaultData.employerName;
      const addr = getVal('deponentAddress') || defaultData.deponentAddress;

      const depName = getVal('dependentName') || defaultData.dependentName;
      const depAge = getVal('dependentAge') || defaultData.dependentAge;
      const depSex = getVal('dependentSex') || defaultData.dependentSex;
      const depAadhaarNo = getVal('dependentAadhaar') || defaultData.dependentAadhaar;
      const depRel = getVal('dependentRelation') || defaultData.dependentRelation;
      const depInc = getVal('dependentIncome') || defaultData.dependentIncome;

      const place = getVal('executionPlace') || defaultData.executionPlace;
      const date = getVal('affidavitDate') || defaultData.affidavitDate;

      // Outputs
      document.getElementById('out-deponentName').innerText = name;
      document.getElementById('out-deponentName2').innerText = name;
      document.getElementById('out-deponentSignature').innerText = `(${name})`;
      document.getElementById('out-deponentAge').innerText = age;
      document.getElementById('out-deponentOccupation').innerText = occ;
      document.getElementById('out-deponentAadhaar').innerText = depAadhaar;
      document.getElementById('out-ipNo').innerText = insNo;
      document.getElementById('out-insuranceNo').innerText = insNo;
      document.getElementById('out-employerName').innerText = emp;
      document.getElementById('out-designation').innerText = occ;
      document.getElementById('out-deponentAddress').innerText = addr;

      document.getElementById('out-dependentName').innerText = depName;
      document.getElementById('out-dependentName2').innerText = depName;
      document.getElementById('out-dependentName3').innerText = depName;
      document.getElementById('out-dependentAge').innerText = depAge;
      document.getElementById('out-dependentSex').innerText = depSex;
      document.getElementById('out-dependentAadhaar').innerText = depAadhaarNo;
      document.getElementById('out-dependentRelation').innerText = depRel;
      document.getElementById('out-dependentIncome').innerText = depInc;

      document.getElementById('out-placeIntro').innerText = place;
      document.getElementById('out-placeFooter').innerText = place;
      document.getElementById('out-dateFooter').innerText = date;
    }

    function updateTopMargin(val) {
      const spacer = document.getElementById('stamp-space');
      const text = document.getElementById('topMarginValue');
      const numericVal = Math.min(90, Math.max(0, parseInt(val) || 0));

      if (spacer) spacer.style.height = `${numericVal}mm`;
      if (text) text.innerText = `${numericVal} mm`;
    }

    function setStampPreset(val) {
      const slider = document.getElementById('topMarginSlider');
      if (slider) slider.value = val;
      updateTopMargin(val);
    }

    function updateDocumentScale(val) {
      const numericVal = parseInt(val) || 96;
      const ratio = numericVal / 100;
      document.documentElement.style.setProperty('--doc-scale', ratio);
      
      const scaleValueElem = document.getElementById('scaleValue');
      if (scaleValueElem) scaleValueElem.innerText = `${numericVal}%`;

      const sheet = document.getElementById('affidavit-sheet');
      if (sheet) {
        sheet.style.transform = `scale(${ratio})`;
        sheet.style.transformOrigin = 'top center';
      }
    }

    function setDocumentScale(val) {
      const slider = document.getElementById('scaleSlider');
      if (slider) slider.value = val;
      updateDocumentScale(val);
    }

    function resetToDefaultData() {
      Object.keys(defaultData).forEach(key => {
        const el = document.getElementById(key);
        if (el) el.value = defaultData[key];
      });

      setStampPreset(0);
      setDocumentScale(96);
      updateAffidavit();
    }

    function scrollToPreview() {
      document.getElementById('preview-container').scrollIntoView({ behavior: 'smooth' });
    }

    function handlePrint() {
      updateAffidavit();
      window.print();
    }

    document.addEventListener('DOMContentLoaded', () => {
      if (window.lucide) {
        lucide.createIcons();
      }

      updateAffidavit();
      updateDocumentScale(96);

      const inputIds = [
        'deponentName', 'deponentAge', 'deponentOccupation', 'deponentAadhaar',
        'insuranceNo', 'employerName', 'deponentAddress', 'dependentName',
        'dependentAge', 'dependentSex', 'dependentAadhaar', 'dependentRelation',
        'dependentIncome', 'executionPlace', 'affidavitDate'
      ];

      inputIds.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
          element.addEventListener('input', updateAffidavit);
        }
      });
    });
  </script>
</body>
</html>