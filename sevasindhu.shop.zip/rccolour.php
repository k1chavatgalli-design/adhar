<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// =========================================================================
// PROCESS FORM SUBMISSION
// =========================================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_preview'])) {
    $rcNo = trim($_POST['rc_no'] ?? '');

    // 1. Validate HTML file upload
    if (empty($_FILES['html_file']['tmp_name']) || $_FILES['html_file']['error'] !== UPLOAD_ERR_OK) {
        die("Error: Please upload a valid HTML file.");
    }

    $rawCardHtml = file_get_contents($_FILES['html_file']['tmp_name']);

    // 2. Process and map uploaded image files to Base64
    $uploadedImages = [];
    if (!empty($_FILES['img_files']['name'][0])) {
        foreach ($_FILES['img_files']['tmp_name'] as $key => $tmpPath) {
            if ($_FILES['img_files']['error'][$key] === UPLOAD_ERR_OK && is_uploaded_file($tmpPath)) {
                $origName = basename($_FILES['img_files']['name'][$key]);
                $mimeType = mime_content_type($tmpPath) ?: 'image/jpeg';
                $b64Data = base64_encode(file_get_contents($tmpPath));
                $uploadedImages[$origName] = "data:{$mimeType};base64,{$b64Data}";
            }
        }
    }

    // 3. Replace image references with Base64 data
    // Case A: Exact filename match in src
    foreach ($uploadedImages as $filename => $base64Uri) {
        $rawCardHtml = preg_replace('/src=["\'][^"\']*' . preg_quote($filename, '/') . '["\']/i', 'src="' . $base64Uri . '"', $rawCardHtml);
    }

    // Case B: Sequential replacement for get_rc_img.aspx calls if filenames are generic
    if (preg_match_all('/src=["\']([^"\']*get_rc_img\.aspx[^"\']*)["\']/i', $rawCardHtml, $matches)) {
        $imgList = array_values($uploadedImages);
        foreach ($matches[1] as $idx => $matchedSrc) {
            if (isset($imgList[$idx])) {
                $rawCardHtml = str_replace($matchedSrc, $imgList[$idx], $rawCardHtml);
            }
        }
    }

    // 4. Strip specimen watermarks
    $rawCardHtml = preg_replace('/<div[^>]*>\s*<img[^>]*specimen\.png[^>]*>\s*<\/div>/is', '', $rawCardHtml);
    $rawCardHtml = preg_replace('/<img[^>]*specimen\.png[^>]*>/is', '', $rawCardHtml);
    $rawCardHtml = preg_replace('/<img[^>]*id=["\'](?:Img1|im)["\'][^>]*>/is', '', $rawCardHtml);

    // 5. Replace exit button with official disclaimer
    $disclaimerTable = '<table style="margin-top: 15px; width: 100%;">
        <tbody><tr>
            <td align="center" style="font-size: 8pt; font-family: Verdana; color: #334155;">
                Disclaimer: This Ration card is issued only for the purpose of drawing entitled quantity of Food grains from the Fair Price shop by the card holder. The Personal details of the card holder are based on self declaration of the card holder. The department of Food, Civil Supplies and Consumer Affairs Department, does not certify the correctness of the particulars furnished.
            </td>
        </tr></tbody>
    </table>';

    $rawCardHtml = preg_replace('/<table[^>]*>\s*<tr>\s*<td[^>]*align=["\']center["\'][^>]*>\s*<input[^>]*btnExit[^>]*>.*?<\/table>/is', $disclaimerTable, $rawCardHtml);

    // 6. Wrap card container if missing
    if (stripos($rawCardHtml, '<div id="rc-container">') === false && stripos($rawCardHtml, 'tblRCard') !== false) {
        $rawCardHtml = preg_replace('/(<center>\s*)(<table id="tblRCard".*?<\/table>\s*<table.*?<\/table>)(\s*<\/center>)/is', '<div id="rc-container"><center>$2</center></div>', $rawCardHtml);
    }

    // 7. Embed styling, dynamic color engine (AAY / NPHH / PHH), and print script
    $bplPrintEngine = '
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    function _x(STR_XPATH) {
        var xresult = document.evaluate(STR_XPATH, document, null, XPathResult.ANY_TYPE, null);
        var xnodes = [];
        var xres;
        while (xres = xresult.iterateNext()) {
            xnodes.push(xres);
        }
        return xnodes;
    }

    $(document).ready(function() {
        var card_type = $("#lblCardType1").text();

        if (card_type.indexOf("Antyodaya") !== -1) {
            $("<span id=\"Label16\" style=\"font-size:18pt;font-weight:bold;\">AAY</span><div style=\"height:1px; clear:both\"></div>").insertBefore("#lblAckNo");
            $("#tblRCard").attr("style", "font-family: Verdana; font-size: 8pt; height: 566.93px; vertical-align: top; padding-top: 20px;");
            $("#lblCardType1").html("Antyodaya Anna Yojane Not Eligible for Kerosene");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[2]")).attr("style", "width: 47.79px; height: 570px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]")).attr("style", "border: 1px solid #F5A9A9; padding: 0px; background-color: #F5A9A9;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr[1]/td[3]/table/tbody/tr[1]/td/table")).attr("style", "height: 100px; background-color: #FA5858; color: white !important; border-radius: 0px 0px 20px 20px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[4]/td/table")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[5]")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]")).attr("style", "width: 380.95px; height: 100%; padding-left: 20px; border: 1px solid #F5A9A9; padding: 5px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/table")).attr("style", "height: 431.69px; width: 331.63px; border: 5px double #F5A9A9;");
            $("#Table1").attr("style", "width: 360.63px; height: 110px; font-size: 8pt; background-color: #F5A9A9; color: #000; border-radius: 20px 20px 0px 0px; margin-top: 30px");
        } else if (card_type.indexOf("Non-Priority") !== -1 || card_type.indexOf("NPHH") !== -1) {
            $("<span id=\"Label16\" style=\"font-size:18pt;font-weight:bold;\">NPHH</span><div style=\"height:1px; clear:both\"></div>").insertBefore("#lblAckNo");
            $("#tblRCard").attr("style", "font-family: Verdana; font-size: 8pt; height: 566.93px; vertical-align: top; padding-top: 20px;");
            $("#lblCardType1").html("Non Priority Household Not Eligible for Kerosene Opted to draw Ration");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[2]")).attr("style", "width: 47.79px; height: 570px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]")).attr("style", "border: 1px solid #C8C4E7; padding: 0px; background-color: #C8C4E7;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr[1]/td[3]/table/tbody/tr[1]/td/table")).attr("style", "height: 100px; background-color: #6D87D2; color: white !important; border-radius: 0px 0px 20px 20px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[4]/td/table")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[5]")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]")).attr("style", "width: 380.95px; height: 100%; padding-left: 20px; border: 1px solid #C8C4E7; padding: 5px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/table")).attr("style", "height: 431.69px; width: 331.63px; border: 5px double #C8C4E7;");
            $("#Table1").attr("style", "width: 360.63px; height: 110px; font-size: 8pt; background-color: #C8C4E7; color: #000; border-radius: 20px 20px 0px 0px; margin-top: 30px");
        } else {
            // Default PHH (Green theme)
            $("<span id=\"Label16\" style=\"font-size:18pt;font-weight:bold;\">PHH</span><div style=\"height:1px; clear:both\"></div>").insertBefore("#lblAckNo");
            $("#tblRCard").attr("style", "font-family: Verdana; font-size: 8pt; height: 566.93px; vertical-align: top; padding-top: 20px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[2]")).attr("style", "width: 47.79px; height: 570px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]")).attr("style", "border: 1px solid #7eab74; padding: 0px; background-color: #aabd9d;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr[1]/td[3]/table/tbody/tr[1]/td/table")).attr("style", "height: 100px; background-color: #3f652a; color: white !important; border-radius: 0px 0px 20px 20px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[4]/td/table")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[3]/table/tbody/tr[5]")).attr("style", "background-color: #fff;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]")).attr("style", "width: 380.95px; height: 100%; padding-left: 20px; border: 1px solid #7eab74; padding: 5px;");
            $(_x("/html/.//*[@id=\"tblRCard\"]/tbody/tr/td/table/tbody/tr/td[1]/table/tbody/tr[1]/td/table")).attr("style", "height: 431.69px; width: 331.63px; border: 5px double #7eab74;");
            $("#Table1").attr("style", "width: 360.63px; height: 110px; font-size: 8pt; background-color: #aabd9d; color: #000; border-radius: 20px 20px 0px 0px; margin-top: 30px");
        }

        $(_x("/html/.//*[@id=\"Table3\"]/tbody/tr/td[1]")).attr("style", "width: 213px;");
        $("#lblPhNo").attr("style", "font-size: 8pt;");
    });

    function triggerPrint() {
        window.print();
    }
    </script>
    <style>
        @page { size: A4 portrait; margin: 2mm; }
        @media print {
            .no-print-bar { display: none !important; }
            body { margin: 0; padding: 0; background: #fff !important; }
        }
        .no-print-bar {
            background: #0f172a;
            padding: 12px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-family: system-ui, -apple-system, sans-serif;
            margin-bottom: 20px;
        }
        .btn-action {
            padding: 10px 20px;
            font-size: 14px;
            font-weight: 600;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            text-decoration: none;
        }
    </style>
    <div class="no-print-bar">
        <span style="color:#fff; font-weight:600;">RC: ' . htmlspecialchars($rcNo) . ' — Print Ready</span>
        <div>
            <button onclick="triggerPrint()" class="btn-action" style="background:#16a34a; color:#fff; margin-right:10px;">🖨️ Print / Save PDF</button>
            <a href="' . strtok($_SERVER["REQUEST_URI"], '?') . '" class="btn-action" style="background:#334155; color:#fff;">← Back</a>
        </div>
    </div>';

    if (stripos($rawCardHtml, '</body>') !== false) {
        $rawCardHtml = str_ireplace('</body>', $bplPrintEngine . '</body>', $rawCardHtml);
    } else {
        $rawCardHtml = $bplPrintEngine . $rawCardHtml;
    }

    echo $rawCardHtml;
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ration Card Preview Generator</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background: #f1f5f9;
            color: #1e293b;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .card {
            background: #ffffff;
            border: 1px solid #cbd5e1;
            border-radius: 10px;
            padding: 30px;
            width: 100%;
            max-width: 580px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }
        .card-header {
            margin-bottom: 24px;
            border-bottom: 1px solid #e2e8f0;
            padding-bottom: 14px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .card-header h2 {
            font-size: 18px;
            font-weight: 700;
            color: #0f172a;
        }
        
        /* Action buttons layout container */
        .header-actions {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* How to download button styling */
        .btn-how-to {
            background-color: #059669;
            color: white;
            padding: 7px 14px;
            font-size: 13px;
            font-weight: 600;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 5px;
            transition: background 0.2s;
        }
        .btn-how-to:hover {
            background-color: #047857;
        }

        /* Dropdown styling */
        .dropdown {
            position: relative;
            display: inline-block;
        }
        .dropdown-btn {
            background-color: #0284c7;
            color: white;
            padding: 7px 14px;
            font-size: 13px;
            font-weight: 600;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 6px;
            transition: background 0.2s;
        }
        .dropdown-btn:hover {
            background-color: #0369a1;
        }
        .dropdown-menu {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            margin-top: 5px;
            background-color: #ffffff;
            min-width: 150px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.12);
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            z-index: 50;
            overflow: hidden;
        }
        .dropdown-menu a {
            color: #334155;
            padding: 10px 16px;
            text-decoration: none;
            display: block;
            font-size: 13px;
            font-weight: 500;
            transition: background 0.15s, color 0.15s;
        }
        .dropdown-menu a:hover {
            background-color: #f1f5f9;
            color: #0284c7;
        }
        .dropdown:hover .dropdown-menu {
            display: block;
        }

        /* Modal Overlay Styling */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 23, 42, 0.7);
            z-index: 1000;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .modal-content {
            background: #ffffff;
            border-radius: 10px;
            width: 100%;
            max-width: 650px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.2);
            overflow: hidden;
            animation: modalFadeIn 0.25s ease-out;
        }
        @keyframes modalFadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .modal-header {
            padding: 16px 20px;
            background: #0f172a;
            color: #ffffff;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .modal-header h3 {
            font-size: 16px;
            font-weight: 600;
        }
        .modal-close {
            background: transparent;
            border: none;
            color: #94a3b8;
            font-size: 20px;
            cursor: pointer;
            transition: color 0.2s;
        }
        .modal-close:hover {
            color: #ffffff;
        }
        .modal-body {
            padding: 20px;
        }
        .video-container {
            position: relative;
            width: 100%;
            padding-bottom: 56.25%; /* 16:9 Aspect Ratio */
            height: 0;
        }
        .video-container iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: 6px;
            border: none;
        }

        .form-row {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .form-label {
            width: 160px;
            font-size: 14px;
            font-weight: 700;
            color: #1e293b;
        }
        .form-label span.req {
            color: #dc2626;
        }
        .form-input {
            flex: 1;
        }
        input[type="text"] {
            width: 100%;
            padding: 9px 12px;
            font-size: 14px;
            border: 1px solid #cbd5e1;
            border-radius: 4px;
            outline: none;
        }
        input[type="text"]:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 2px rgba(37, 99, 235, 0.15);
        }
        input[type="file"] {
            font-size: 13px;
            color: #64748b;
        }
        .btn-submit {
            background: #2563eb;
            color: #ffffff;
            border: none;
            padding: 11px 20px;
            font-size: 14px;
            font-weight: 600;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
            transition: background 0.2s;
        }
        .btn-submit:hover {
            background: #1d4ed8;
        }
    </style>
</head>
<body>

<div class="card">
    <div class="card-header">
        <h2>Ration Card Print Generator</h2>

        <div class="header-actions">
            <!-- How to Download Button -->
            <button type="button" class="btn-how-to" onclick="openModal()">
                ▶ How to Download
            </button>

            <!-- HTML Download Dropdown -->
            <div class="dropdown">
                <button type="button" class="dropdown-btn">HTML Download &#9662;</button>
                <div class="dropdown-menu">
                    <a href="https://ahara.karnataka.gov.in/fcs_verify_mser/OTP_VERIFY.aspx" target="_blank" rel="noopener noreferrer">MSERVER</a>
                    <a href="https://ahara.karnataka.gov.in/fcs_verify_kser/OTP_VERIFY.aspx" target="_blank" rel="noopener noreferrer">KSERVER</a>
                    <a href="https://ahara.karnataka.gov.in/fcs_verify_bser/OTP_VERIFY.aspx" target="_blank" rel="noopener noreferrer">BSERVER</a>
                </div>
            </div>
        </div>
    </div>

    <form method="POST" enctype="multipart/form-data">
        <div class="form-row">
            <label class="form-label">Ration Card No<span class="req">*</span></label>
            <div class="form-input">
                <input type="text" name="rc_no" placeholder="Ration Card No" required autocomplete="off">
            </div>
        </div>

        <div class="form-row">
            <label class="form-label">Upload Html file<span class="req">*</span></label>
            <div class="form-input">
                <input type="file" name="html_file" accept=".html,.htm" required>
            </div>
        </div>

        <div class="form-row">
            <label class="form-label">Upload images file<span class="req">*</span></label>
            <div class="form-input">
                <input type="file" name="img_files[]" accept="image/*" multiple required>
            </div>
        </div>

        <button type="submit" name="generate_preview" class="btn-submit">
            Generate PDF Preview
        </button>
    </form>
</div>

<!-- How to Download Video Modal -->
<div id="videoModal" class="modal-overlay" onclick="handleModalClick(event)">
    <div class="modal-content">
        <div class="modal-header">
            <h3>How to Download Guide</h3>
            <button type="button" class="modal-close" onclick="closeModal()">&times;</button>
        </div>
        <div class="modal-body">
            <div class="video-container">
                <iframe id="youtubeVideo" src="" title="YouTube video player" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</div>

<script>
    const modal = document.getElementById('videoModal');
    const iframe = document.getElementById('youtubeVideo');
    const videoEmbedUrl = 'https://www.youtube.com/embed/GDdU26gTgEo';

    function openModal() {
        modal.style.display = 'flex';
        iframe.src = videoEmbedUrl + '?autoplay=1';
    }

    function closeModal() {
        modal.style.display = 'none';
        iframe.src = ''; // Stops video playback when closed
    }

    function handleModalClick(event) {
        if (event.target === modal) {
            closeModal();
        }
    }

    // Close modal on escape key
    document.addEventListener('keydown', function(event) {
        if (event.key === 'Escape') {
            closeModal();
        }
    });
</script>

</body>
</html>