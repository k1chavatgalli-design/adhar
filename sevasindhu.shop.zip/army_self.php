<?php
// Default values from user input
$service_no   = isset($_POST['service_no'])   ? htmlspecialchars($_POST['service_no'])   : '16113014W';
$rank         = isset($_POST['rank'])         ? htmlspecialchars($_POST['rank'])         : 'EX-HAV';
$name         = isset($_POST['name'])         ? htmlspecialchars($_POST['name'])         : 'GOVIND PATIL';
$academic_yr = isset($_POST['academic_yr']) ? htmlspecialchars($_POST['academic_yr']) : '2025-26';
$child_name   = isset($_POST['child_name'])   ? htmlspecialchars($_POST['child_name'])   : 'YUVARAJ PATIL';
$place        = isset($_POST['place'])        ? htmlspecialchars($_POST['place'])        : 'Belagavi';
$date         = isset($_POST['date'])         ? htmlspecialchars($_POST['date'])         : '24/10/2026';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Self Declaration Certificate Generator</title>
    <!-- Tailwind CSS for UI Layout -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        @media print {
            .no-print { display: none !important; }
            body { background: white !important; padding: 0 !important; }
            .print-page { 
                box-shadow: none !important; 
                border: none !important; 
                margin: 0 !important; 
                width: 100% !important;
                padding: 1.5in 1in 1in 1in !important;
            }
        }
        .a4-page {
            width: 210mm;
            min-height: 297mm;
            background: white;
            font-family: 'Times New Roman', Times, serif;
            color: #000;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen font-sans text-gray-800 pb-12">

    <!-- Top Header -->
    <header class="bg-indigo-700 text-white py-4 shadow-md no-print mb-8">
        <div class="max-w-7xl mx-auto px-4 flex justify-between items-center">
            <h1 class="text-xl font-bold tracking-wide">ARMY CEA SELF DECLARATION CERTIFICATE</h1>
            <button onclick="window.print()" class="bg-emerald-500 hover:bg-emerald-600 text-white font-semibold px-4 py-2 rounded shadow transition flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path></svg>
                Print / Save PDF
            </button>
        </div>
    </header>

    <div class="max-w-7xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        <!-- Data Entry Form Panel -->
        <div class="lg:col-span-5 bg-white p-6 rounded-lg shadow-md h-fit no-print">
            <h2 class="text-lg font-bold border-b pb-3 mb-4 text-indigo-700 flex items-center justify-between">
                <span>Data Entry Form</span>
                <span class="text-xs bg-indigo-100 text-indigo-800 px-2.5 py-1 rounded-full font-semibold">PHP Live Sync</span>
            </h2>

            <form method="POST" action="" id="certForm" class="space-y-4">
                <div>
                    <label class="block text-xs font-bold uppercase text-gray-600 mb-1">Service No</label>
                    <input type="text" name="service_no" id="in_service_no" value="<?php echo $service_no; ?>" class="w-full border rounded px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-bold uppercase text-gray-600 mb-1">Rank</label>
                        <input type="text" name="rank" id="in_rank" value="<?php echo $rank; ?>" class="w-full border rounded px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase text-gray-600 mb-1">Applicant Name</label>
                        <input type="text" name="name" id="in_name" value="<?php echo $name; ?>" class="w-full border rounded px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-bold uppercase text-gray-600 mb-1">Academic Year</label>
                        <input type="text" name="academic_yr" id="in_academic_yr" value="<?php echo $academic_yr; ?>" class="w-full border rounded px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase text-gray-600 mb-1">Child Name</label>
                        <input type="text" name="child_name" id="in_child_name" value="<?php echo $child_name; ?>" class="w-full border rounded px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-bold uppercase text-gray-600 mb-1">Place</label>
                        <input type="text" name="place" id="in_place" value="<?php echo $place; ?>" class="w-full border rounded px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase text-gray-600 mb-1">Date</label>
                        <input type="text" name="date" id="in_date" value="<?php echo $date; ?>" class="w-full border rounded px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none">
                    </div>
                </div>

                <div class="pt-2 flex gap-2">
                    <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded shadow transition text-sm">
                        Submit & Generate
                    </button>
                    <button type="button" onclick="copyDocumentText()" class="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded transition text-sm">
                        Copy Text
                    </button>
                </div>
            </form>
        </div>

        <!-- Word Document Preview Area -->
        <div class="lg:col-span-7 flex justify-center">
            <div class="a4-page print-page p-[1.5in_1in_1in_1in] shadow-2xl border border-gray-300 rounded-sm">
                
                <!-- Document Title -->
                <div class="text-center mb-10">
                    <h2 class="text-xl font-bold uppercase underline tracking-wide">SELF DECLARATION CERTIFICATE</h2>
                </div>

                <!-- Main Body Text -->
                <div class="text-justify leading-relaxed text-[17px] mb-12">
                    It is certified that No: <span id="out_service_no" class="font-bold underline"><?php echo $service_no; ?></span>, 
                    Rank: <span id="out_rank" class="font-bold underline"><?php echo $rank; ?></span>, 
                    Name: <span id="out_name" class="font-bold underline"><?php echo $name; ?></span>, 
                    I have not taken any money/grant from the State or present employer in form of scholarship grant for the academic year 
                    <span id="out_academic_yr" class="font-bold underline"><?php echo $academic_yr; ?></span> 
                    in respect of my CHILD <span id="out_child_name" class="font-bold underline"><?php echo $child_name; ?></span>.
                </div>

                <!-- Footer / Signature Block directly below body text -->
                <div class="pt-4 text-[16px] flex justify-between items-start">
                    <!-- Left: Place & Date -->
                    <div class="space-y-1">
                        <p><strong>Place:</strong> <span id="out_place"><?php echo $place; ?></span></p>
                        <p><strong>Date:</strong> <span id="out_date"><?php echo $date; ?></span></p>
                    </div>

                    <!-- Right: Signature -->
                    <div class="text-right space-y-1">
                        <p class="font-medium">Yours faithfully,</p>
                        <div class="h-16"></div> <!-- Signature gap -->
                        <p class="font-bold">
                            (No: <span id="out_sig_service_no"><?php echo $service_no; ?></span>, 
                            Rank: <span id="out_sig_rank"><?php echo $rank; ?></span>
                        </p>
                        <p class="font-bold uppercase" id="out_sig_name"><?php echo $name; ?></p>
                    </div>
                </div>

            </div>
        </div>

    </div>

    <!-- Realtime JavaScript Sync for client-side responsiveness -->
    <script>
        const fields = ['service_no', 'rank', 'name', 'academic_yr', 'child_name', 'place', 'date'];
        
        fields.forEach(field => {
            const input = document.getElementById('in_' + field);
            const output = document.getElementById('out_' + field);
            
            if (input && output) {
                input.addEventListener('input', () => {
                    output.textContent = input.value;
                    
                    // Sync signature block duplicates
                    if (field === 'service_no') document.getElementById('out_sig_service_no').textContent = input.value;
                    if (field === 'rank') document.getElementById('out_sig_rank').textContent = input.value;
                    if (field === 'name') document.getElementById('out_sig_name').textContent = input.value;
                });
            }
        });

        function copyDocumentText() {
            const text = `SELF DECLARATION CERTIFICATE\n\n` +
            `It is certified that No: ${document.getElementById('in_service_no').value}, Rank: ${document.getElementById('in_rank').value}, Name: ${document.getElementById('in_name').value}, I have not taken any money/grant from the State or present employer in form of scholarship grant for the academic year ${document.getElementById('in_academic_yr').value} in respect of my CHILD ${document.getElementById('in_child_name').value}.\n\n` +
            `Place: ${document.getElementById('in_place').value}\t\tYours faithfully,\n` +
            `Date: ${document.getElementById('in_date').value}\n\n` +
            `(${document.getElementById('in_service_no').value}, Rank: ${document.getElementById('in_rank').value}\n` +
            `${document.getElementById('in_name').value})`;

            navigator.clipboard.writeText(text).then(() => {
                alert('Certificate text copied to clipboard!');
            });
        }
    </script>
</body>
</html>