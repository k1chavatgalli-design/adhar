<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Aadhaar DoB Updation Affidavit Generator</title>

  <!-- Google Fonts: Bookman alternative (Crimson Pro / Serif fallback) -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bookman+Old+Style&family=Crimson+Pro:ital,wght@0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">

  <!-- docx.js & FileSaver.js for Client-Side Word Generation -->
  <script src="https://unpkg.com/docx@8.5.0/build/index.umd.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/FileSaver.js/2.0.5/FileSaver.min.js"></script>

  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: {
            bookman: ['"Bookman Old Style"', 'Bookman', '"Crimson Pro"', 'Georgia', 'serif']
          }
        }
      }
    }
  </script>

  <style>
    :root {
      --preview-font-size: 16px;
    }

    body {
      font-family: 'Bookman Old Style', Bookman, 'Crimson Pro', Georgia, serif;
    }
    
    /* Target ONLY the preview paper for font scaling */
    #printArea {
      font-size: var(--preview-font-size);
      font-family: 'Bookman Old Style', Bookman, 'Crimson Pro', Georgia, serif;
      color: #111827;
      line-height: 1.6;
    }

    .value-highlight {
      font-weight: 600;
      color: #0f172a;
    }

    /* Print specific styles */
    @media print {
      body * {
        visibility: hidden;
      }
      #printArea, #printArea * {
        visibility: visible;
      }
      #printArea {
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        margin: 0;
        padding: 0;
        box-shadow: none !important;
        border: none !important;
        background: #fff !important;
      }
      .no-print {
        display: none !important;
      }
      @page {
        size: A4;
        margin: 20mm;
      }
    }
  </style>
</head>
<body class="bg-slate-100 text-slate-800 min-h-screen font-bookman flex flex-col">

  <!-- Top Navigation Header -->
  <header class="bg-slate-900 text-white shadow-md no-print py-4 px-6 border-b border-slate-700">
    <div class="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-4">
      <div class="flex items-center space-x-3">
        <svg class="w-8 h-8 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
        </svg>
        <div>
          <h1 class="text-xl font-bold tracking-wide">Aadhaar DoB Updation Affidavit Generator</h1>
          <p class="text-xs text-slate-400">Annexure IA - For Children (Formatted in Bookman)</p>
        </div>
      </div>
      
      <!-- Top Quick Actions -->
      <div class="flex items-center gap-3">
        <button onclick="fillSampleData()" class="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold rounded transition shadow">
          ⚡ Fill Sample Data
        </button>
        <button onclick="clearForm()" class="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold rounded transition shadow">
          🗑️ Clear Form
        </button>
      </div>
    </div>
  </header>

  <!-- Main Container -->
  <main class="flex-grow max-w-7xl w-full mx-auto p-4 md:p-6 space-y-8">

    <!-- DATA ENTRY FORM (TOP SECTION) -->
    <section class="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden no-print">
      <div class="bg-slate-800 text-white px-6 py-4 flex justify-between items-center">
        <h2 class="text-lg font-bold flex items-center gap-2">
          <svg class="w-5 h-5 text-amber-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
          </svg>
          Data Entry Form
        </h2>
        <span class="text-xs bg-slate-700 text-slate-300 px-2.5 py-1 rounded-full">Step 1 of 2</span>
      </div>

      <form id="affidavitForm" class="p-6 space-y-6">
        
        <!-- SECTION 1: Deponent Details -->
        <div>
          <h3 class="text-sm font-bold uppercase tracking-wider text-slate-500 border-b pb-1 mb-4">
            1. Parent / Legal Guardian Details (Deponent)
          </h3>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Parent / Guardian Full Name</label>
              <input type="text" id="parentName" placeholder="e.g. Rajesh Kumar Sharma" class="w-full p-2.5 border border-slate-300 rounded text-sm focus:ring-2 focus:ring-slate-800 focus:outline-none" oninput="updatePreview()">
            </div>
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Relation Type & Relative Name</label>
              <div class="flex gap-2">
                <select id="relationType" class="p-2.5 border border-slate-300 rounded text-sm focus:ring-2 focus:ring-slate-800 focus:outline-none w-1/3" onchange="updatePreview()">
                  <option value="S/o">S/o</option>
                  <option value="D/o">D/o</option>
                  <option value="W/o">W/o</option>
                </select>
                <input type="text" id="relativeName" placeholder="e.g. Ramesh Sharma" class="w-full p-2.5 border border-slate-300 rounded text-sm focus:ring-2 focus:ring-slate-800 focus:outline-none" oninput="updatePreview()">
              </div>
            </div>
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Parent Aadhaar Number</label>
              <input type="text" id="parentAadhaar" maxlength="14" placeholder="XXXX XXXX XXXX" class="w-full p-2.5 border border-slate-300 rounded text-sm focus:ring-2 focus:ring-slate-800 focus:outline-none font-mono" oninput="formatAadhaar(this); updatePreview()">
            </div>
          </div>

          <div class="mt-4">
            <label class="block text-xs font-semibold text-slate-700 mb-1">Full Residential Address</label>
            <input type="text" id="parentAddress" placeholder="e.g. Flat No. 402, Green Valley Apartments, MG Road, New Delhi - 110001" class="w-full p-2.5 border border-slate-300 rounded text-sm focus:ring-2 focus:ring-slate-800 focus:outline-none" oninput="updatePreview()">
          </div>

          <div class="mt-4">
            <label class="block text-xs font-semibold text-slate-700 mb-1">Relationship to Minor</label>
            <select id="parentRole" class="w-full md:w-1/3 p-2.5 border border-slate-300 rounded text-sm focus:ring-2 focus:ring-slate-800 focus:outline-none" onchange="updatePreview()">
              <option value="parent">Parent</option>
              <option value="legal guardian">Legal Guardian</option>
            </select>
          </div>
        </div>

        <!-- SECTION 2: Minor / Child Details -->
        <div>
          <h3 class="text-sm font-bold uppercase tracking-wider text-slate-500 border-b pb-1 mb-4">
            2. Child / Ward Details
          </h3>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Child Full Name</label>
              <input type="text" id="childName" placeholder="e.g. Aarav Sharma" class="w-full p-2.5 border border-slate-300 rounded text-sm focus:ring-2 focus:ring-slate-800 focus:outline-none" oninput="updatePreview()">
            </div>
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Child Aadhaar Number</label>
              <input type="text" id="childAadhaar" maxlength="14" placeholder="XXXX XXXX XXXX" class="w-full p-2.5 border border-slate-300 rounded text-sm focus:ring-2 focus:ring-slate-800 focus:outline-none font-mono" oninput="formatAadhaar(this); updatePreview()">
            </div>
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Times Previously Updated</label>
              <select id="updateTimes" class="w-full p-2.5 border border-slate-300 rounded text-sm focus:ring-2 focus:ring-slate-800 focus:outline-none" onchange="updatePreview()">
                <option value="never">Never</option>
                <option value="once">Once</option>
                <option value="more than once">More than once</option>
              </select>
            </div>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Earlier Recorded Date of Birth (in Aadhaar)</label>
              <input type="date" id="oldDob" class="w-full p-2.5 border border-slate-300 rounded text-sm focus:ring-2 focus:ring-slate-800 focus:outline-none" onchange="updatePreview()">
            </div>
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Correct Date of Birth (To be Updated)</label>
              <input type="date" id="correctDob" class="w-full p-2.5 border border-slate-300 rounded text-sm focus:ring-2 focus:ring-slate-800 focus:outline-none" onchange="updatePreview()">
            </div>
          </div>
        </div>

        <!-- SECTION 3: Affidavit Signing Date -->
        <div>
          <h3 class="text-sm font-bold uppercase tracking-wider text-slate-500 border-b pb-1 mb-4">
            3. Date & Submission
          </h3>
          <div class="w-full md:w-1/3">
            <label class="block text-xs font-semibold text-slate-700 mb-1">Affidavit Execution Date</label>
            <input type="date" id="affidavitDate" class="w-full p-2.5 border border-slate-300 rounded text-sm focus:ring-2 focus:ring-slate-800 focus:outline-none" onchange="updatePreview()">
          </div>
        </div>

      </form>
    </section>

    <!-- ACTION BUTTON BAR (MIDDLE SECTION) -->
    <section class="no-print bg-slate-800 rounded-xl p-4 shadow-md text-white flex flex-col md:flex-row justify-between items-center gap-4">
      <div>
        <p class="text-sm font-medium">Ready to output your affidavit?</p>
        <p class="text-xs text-slate-400">Download as a Word document or print directly.</p>
      </div>

      <div class="flex flex-wrap items-center gap-3">
        <!-- Download Word Document Button -->
        <button onclick="downloadWordDoc()" class="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg shadow-md transition transform active:scale-95 text-xs md:text-sm">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
          </svg>
          Download Word (.docx)
        </button>

        <!-- Print Button -->
        <button onclick="triggerPrint()" class="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold rounded-lg shadow-md transition transform active:scale-95 text-xs md:text-sm">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path>
          </svg>
          Print
        </button>
      </div>
    </section>

    <!-- LIVE DOCUMENT PREVIEW (BOTTOM SECTION WITH FONT CONTROLS IN HEADER) -->
    <section class="bg-white rounded-xl shadow-md border border-slate-200 overflow-hidden">
      <div class="bg-slate-800 text-white px-6 py-4 flex flex-col sm:flex-row justify-between items-center gap-3 no-print">
        <h2 class="text-lg font-bold flex items-center gap-2">
          <svg class="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path>
          </svg>
          Live Document Preview
        </h2>

        <!-- PREVIEW ONLY FONT CONTROLS -->
        <div class="flex items-center gap-2">
          <div class="flex items-center bg-slate-700 rounded-lg p-1 border border-slate-600 shadow-inner">
            <span class="text-xs font-semibold text-slate-300 px-2 select-none">Preview Font:</span>
            <button onclick="changePreviewFontSize(-1)" title="Decrease Preview Font Size" class="px-2.5 py-1 bg-slate-800 hover:bg-slate-900 text-slate-200 font-bold text-xs rounded transition active:scale-95">
              A-
            </button>
            <button onclick="resetPreviewFontSize()" title="Reset Preview Font Size" class="px-2.5 py-1 bg-slate-800 hover:bg-slate-900 text-slate-200 font-semibold text-xs rounded transition active:scale-95 mx-1">
              A
            </button>
            <button onclick="changePreviewFontSize(1)" title="Increase Preview Font Size" class="px-2.5 py-1 bg-slate-800 hover:bg-slate-900 text-slate-200 font-bold text-xs rounded transition active:scale-95">
              A+
            </button>
          </div>
          <span class="text-xs bg-slate-700 text-slate-300 px-2.5 py-1.5 rounded-full">Step 2 of 2</span>
        </div>
      </div>

      <!-- Printable Document Paper Container -->
      <div class="p-4 md:p-12 bg-slate-200">
        <div id="printArea" class="max-w-[800px] mx-auto bg-white p-8 md:p-14 shadow-xl border border-slate-300 rounded-sm">
          
          <!-- Document Header with Annexure IA aligned top-right in small font -->
          <div class="mb-6">
            <div class="text-right text-xs md:text-sm font-semibold tracking-wide text-slate-800 mb-4">
              Annexure IA- For children
            </div>
            <div class="text-center">
              <h3 class="text-lg md:text-xl font-bold uppercase tracking-tight text-slate-800">
                Affidavit for date of birth updation
              </h3>
            </div>
          </div>

          <!-- Document Body -->
          <div class="space-y-4 text-justify text-slate-900 leading-relaxed">
            
            <!-- Point 1 -->
            <p>
              1. I, <span id="prev_parentName" class="value-highlight">[Parent Name]</span> 
              <span id="prev_relation" class="value-highlight">S/D/W/o [Relative Name]</span>, resident of 
              <span id="prev_address" class="value-highlight">[Address]</span> 
              holding Aadhaar number <span id="prev_parentAadhaar" class="value-highlight">[Parent Aadhaar]</span>, do hereby solemnly affirm and declare as under:-
            </p>

            <!-- Point 2 -->
            <p>
              2. That I am the resident of the above said address.
            </p>

            <!-- Sub-points i to viii -->
            <div class="pl-6 space-y-2">
              <p>
                i) That I am the resident of the above said address.
              </p>
              <p>
                ii) That I am <span id="prev_role" class="value-highlight">parent/legal guardian</span> of 
                <span id="prev_childName" class="value-highlight">[Child Name]</span> 
                holding Aadhaar number <span id="prev_childAadhaar" class="value-highlight">[Child Aadhaar]</span>.
              </p>
              <p>
                iii) That correct date of birth of my child/ward is <span id="prev_correctDob" class="value-highlight">[Correct DoB]</span>.
              </p>
              <p>
                iv) That the earlier recorded date of birth in Aadhaar of my child/ward is <span id="prev_oldDob" class="value-highlight">[Earlier DoB]</span>.
              </p>
              <p>
                v) That I have <span id="prev_updateTimes" class="value-highlight">[never/ once/ more than once]</span> updated my child/ward date of birth in Aadhaar.
              </p>
              <p>
                vi) That birth certificate of my child/ward is being provided in support of DoB update request.
              </p>
              <p>
                vii) That I wish to get my child/ward date of birth updated in the Aadhaar as <span id="prev_correctDob2" class="value-highlight">[Correct DoB]</span>, for which I am submitting his/her birth certificate as proof of date of birth.
              </p>
              <p>
                viii) That I further undertake that my child/ward shall not be eligible for any further updation of date of birth in Aadhaar.
              </p>
            </div>

            <!-- Point 3 -->
            <p class="pt-2">
              3. I undertake that if the document submitted as proof of date of birth is found to be fraudulent/false/forged/non-genuine or my child/ward was not entitled for the said document, the Aadhaar number of my child/ward may be deactivated as per Regulation 28 of the Aadhaar (Enrolment and Update) Regulations, 2016 and I shall be liable to be prosecuted under provisions of the applicable law.
            </p>

            <!-- Point 4 -->
            <p class="pt-2">
              4. I hereby declare that all the information mentioned above is true to the best of my knowledge. In case of any discrepancies, the undersigned will be held responsible.
            </p>

            <!-- Signatures Section -->
            <div class="pt-16 flex justify-between items-end">
              <div>
                <p class="font-semibold">Date: <span id="prev_date" class="font-normal">[Date]</span></p>
              </div>
              <div class="text-right">
                <div class="h-12"></div> <!-- Space for signature -->
                <p class="font-bold border-t border-slate-400 pt-1">
                  Name & Signature of Parent / Guardian of Minor (Deponent)
                </p>
              </div>
            </div>

          </div>
        </div>
      </div>
    </section>

  </main>

  <!-- Footer -->
  <footer class="bg-slate-900 text-slate-400 text-xs text-center py-4 no-print border-t border-slate-800">
    <p>Aadhaar Annexure IA Affidavit Formatter • Styled in Bookman • Formatted for Official Legal Printing</p>
  </footer>

  <!-- JavaScript Logic -->
  <script>
    // Preview-only font size management
    let previewFontSize = 16;
    const MIN_PREVIEW_SIZE = 12;
    const MAX_PREVIEW_SIZE = 26;

    function changePreviewFontSize(delta) {
      const newSize = previewFontSize + delta;
      if (newSize >= MIN_PREVIEW_SIZE && newSize <= MAX_PREVIEW_SIZE) {
        previewFontSize = newSize;
        document.documentElement.style.setProperty('--preview-font-size', `${previewFontSize}px`);
      }
    }

    function resetPreviewFontSize() {
      previewFontSize = 16;
      document.documentElement.style.setProperty('--preview-font-size', '16px');
    }

    // Format Aadhaar inputs with space every 4 digits
    function formatAadhaar(input) {
      let value = input.value.replace(/\D/g, '');
      if (value.length > 12) value = value.slice(0, 12);
      let formatted = '';
      for (let i = 0; i < value.length; i++) {
        if (i > 0 && i % 4 === 0) formatted += ' ';
        formatted += value[i];
      }
      input.value = formatted;
    }

    // Date formatter helper (DD/MM/YYYY)
    function formatDate(dateString) {
      if (!dateString) return null;
      const parts = dateString.split('-');
      if (parts.length === 3) {
        return `${parts[2]}/${parts[1]}/${parts[0]}`;
      }
      return dateString;
    }

    // Real-time Preview Binding
    function updatePreview() {
      const parentName = document.getElementById('parentName').value.trim();
      const relationType = document.getElementById('relationType').value;
      const relativeName = document.getElementById('relativeName').value.trim();
      const parentAddress = document.getElementById('parentAddress').value.trim();
      const parentAadhaar = document.getElementById('parentAadhaar').value.trim();
      const parentRole = document.getElementById('parentRole').value;

      const childName = document.getElementById('childName').value.trim();
      const childAadhaar = document.getElementById('childAadhaar').value.trim();
      const updateTimes = document.getElementById('updateTimes').value;
      const oldDob = formatDate(document.getElementById('oldDob').value);
      const correctDob = formatDate(document.getElementById('correctDob').value);
      const affidavitDate = formatDate(document.getElementById('affidavitDate').value);

      // Render into HTML
      document.getElementById('prev_parentName').innerText = parentName || '[Parent Name]';
      document.getElementById('prev_relation').innerText = relativeName ? `${relationType} ${relativeName}` : `${relationType} [Relative Name]`;
      document.getElementById('prev_address').innerText = parentAddress || '[Address]';
      document.getElementById('prev_parentAadhaar').innerText = parentAadhaar || '[Parent Aadhaar]';
      document.getElementById('prev_role').innerText = parentRole;

      document.getElementById('prev_childName').innerText = childName || '[Child Name]';
      document.getElementById('prev_childAadhaar').innerText = childAadhaar || '[Child Aadhaar]';
      document.getElementById('prev_updateTimes').innerText = updateTimes;
      document.getElementById('prev_oldDob').innerText = oldDob || '[Earlier DoB]';
      document.getElementById('prev_correctDob').innerText = correctDob || '[Correct DoB]';
      document.getElementById('prev_correctDob2').innerText = correctDob || '[Correct DoB]';
      document.getElementById('prev_date').innerText = affidavitDate || '[Date]';
    }

    // Sample Data Filler
    function fillSampleData() {
      document.getElementById('parentName').value = "Rajesh Kumar Sharma";
      document.getElementById('relationType').value = "S/o";
      document.getElementById('relativeName').value = "Ramesh Sharma";
      document.getElementById('parentAddress').value = "Flat No. 402, Green Valley Apartments, MG Road, New Delhi - 110001";
      document.getElementById('parentAadhaar').value = "9876 5432 1098";
      document.getElementById('parentRole').value = "parent";

      document.getElementById('childName').value = "Aarav Sharma";
      document.getElementById('childAadhaar').value = "1234 5678 9012";
      document.getElementById('updateTimes').value = "never";
      document.getElementById('oldDob').value = "2015-05-10";
      document.getElementById('correctDob').value = "2015-05-15";
      document.getElementById('affidavitDate').value = new Date().toISOString().split('T')[0];

      updatePreview();
    }

    // Clear Form
    function clearForm() {
      document.getElementById('affidavitForm').reset();
      updatePreview();
    }

    // Trigger Print Dialog
    function triggerPrint() {
      window.print();
    }

    // Generate & Download Word (.docx) Document
    function downloadWordDoc() {
      const { Document, Packer, Paragraph, TextRun, AlignmentType } = docx;

      const parentName = document.getElementById('parentName').value.trim() || "________________________";
      const relationType = document.getElementById('relationType').value;
      const relativeName = document.getElementById('relativeName').value.trim() || "___________________";
      const parentAddress = document.getElementById('parentAddress').value.trim() || "_______________________________________________________________";
      const parentAadhaar = document.getElementById('parentAadhaar').value.trim() || "____________________";
      const parentRole = document.getElementById('parentRole').value;

      const childName = document.getElementById('childName').value.trim() || "________________________";
      const childAadhaar = document.getElementById('childAadhaar').value.trim() || "____________________";
      const updateTimes = document.getElementById('updateTimes').value || "____________________";
      const oldDob = formatDate(document.getElementById('oldDob').value) || "____________________";
      const correctDob = formatDate(document.getElementById('correctDob').value) || "____________________";
      const affidavitDate = formatDate(document.getElementById('affidavitDate').value) || "____________________";

      const FONT_FAMILY = "Bookman Old Style";

      const doc = new Document({
        sections: [{
          properties: {
            page: {
              margin: {
                top: 1440,    // 1 inch
                bottom: 1440, // 1 inch
                left: 1440,   // 1 inch
                right: 1440   // 1 inch
              }
            }
          },
          children: [
            // Top Right Annexure Line (Small Font)
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              spacing: { after: 240 },
              children: [
                new TextRun({
                  text: "Annexure IA- For children",
                  bold: true,
                  size: 18, // 9pt
                  font: FONT_FAMILY
                })
              ]
            }),

            // Title Line
            new Paragraph({
              alignment: AlignmentType.CENTER,
              spacing: { after: 360 },
              children: [
                new TextRun({
                  text: "Affidavit for date of birth updation",
                  bold: true,
                  size: 32, // 16pt
                  font: FONT_FAMILY
                })
              ]
            }),

            // Point 1
            new Paragraph({
              alignment: AlignmentType.JUSTIFY,
              spacing: { after: 200, line: 300 },
              children: [
                new TextRun({ text: "1. I, ", font: FONT_FAMILY, size: 22 }),
                new TextRun({ text: parentName, bold: true, font: FONT_FAMILY, size: 22 }),
                new TextRun({ text: ` ${relationType} `, font: FONT_FAMILY, size: 22 }),
                new TextRun({ text: relativeName, bold: true, font: FONT_FAMILY, size: 22 }),
                new TextRun({ text: ", resident of ", font: FONT_FAMILY, size: 22 }),
                new TextRun({ text: parentAddress, bold: true, font: FONT_FAMILY, size: 22 }),
                new TextRun({ text: " holding Aadhaar number ", font: FONT_FAMILY, size: 22 }),
                new TextRun({ text: parentAadhaar, bold: true, font: FONT_FAMILY, size: 22 }),
                new TextRun({ text: ", do hereby solemnly affirm and declare as under:-", font: FONT_FAMILY, size: 22 })
              ]
            }),

            // Point 2
            new Paragraph({
              spacing: { after: 120, line: 300 },
              children: [
                new TextRun({ text: "2. That I am the resident of the above said address.", font: FONT_FAMILY, size: 22 })
              ]
            }),

            // Sub-points i to viii
            ...[
              `i) That I am the resident of the above said address.`,
              `ii) That I am ${parentRole} of ${childName} holding Aadhaar number ${childAadhaar}.`,
              `iii) That correct date of birth of my child/ward is ${correctDob}.`,
              `iv) That the earlier recorded date of birth in Aadhaar of my child/ward is ${oldDob}.`,
              `v) That I have ${updateTimes} updated my child/ward date of birth in Aadhaar.`,
              `vi) That birth certificate of my child/ward is being provided in support of DoB update request.`,
              `vii) That I wish to get my child/ward date of birth updated in the Aadhaar as ${correctDob}, for which I am submitting his/her birth certificate as proof of date of birth.`,
              `viii) That I further undertake that my child/ward shall not be eligible for any further updation of date of birth in Aadhaar.`
            ].map(subPtText => new Paragraph({
              indent: { left: 576 }, // Indent 0.4 inch
              spacing: { after: 120, line: 300 },
              children: [
                new TextRun({ text: subPtText, font: FONT_FAMILY, size: 22 })
              ]
            })),

            // Point 3
            new Paragraph({
              alignment: AlignmentType.JUSTIFY,
              spacing: { before: 200, after: 200, line: 300 },
              children: [
                new TextRun({
                  text: "3. I undertake that if the document submitted as proof of date of birth is found to be fraudulent/false/forged/non-genuine or my child/ward was not entitled for the said document, the Aadhaar number of my child/ward may be deactivated as per Regulation 28 of the Aadhaar (Enrolment and Update) Regulations, 2016 and I shall be liable to be prosecuted under provisions of the applicable law.",
                  font: FONT_FAMILY,
                  size: 22
                })
              ]
            }),

            // Point 4
            new Paragraph({
              alignment: AlignmentType.JUSTIFY,
              spacing: { after: 480, line: 300 },
              children: [
                new TextRun({
                  text: "4. I hereby declare that all the information mentioned above is true to the best of my knowledge. In case of any discrepancies, the undersigned will be held responsible.",
                  font: FONT_FAMILY,
                  size: 22
                })
              ]
            }),

            // Date & Signature Line
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              spacing: { before: 720, after: 120 },
              children: [
                new TextRun({ text: "Date: ", font: FONT_FAMILY, size: 22 }),
                new TextRun({ text: `${affidavitDate}\t\t\t`, font: FONT_FAMILY, size: 22 }),
                new TextRun({ text: "___________________________________", font: FONT_FAMILY, size: 22 })
              ]
            }),
            new Paragraph({
              alignment: AlignmentType.RIGHT,
              spacing: { after: 480 },
              children: [
                new TextRun({
                  text: "Name & Signature of Parent / Guardian of Minor (Deponent)",
                  bold: true,
                  font: FONT_FAMILY,
                  size: 22
                })
              ]
            })
          ]
        }]
      });

      // Save file
      Packer.toBlob(doc).then(blob => {
        saveAs(blob, "Annexure_IA_Affidavit_Child_DoB.docx");
      });
    }

    // Initial load sync
    document.addEventListener('DOMContentLoaded', updatePreview);
  </script>
</body>
</html>