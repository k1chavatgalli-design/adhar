<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Maharashtra Gazette Form - Background Overlay & Entry</title>
  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- PDF.js for rendering uploaded PDF as background canvas -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
  <script>
    // Configure PDF.js worker
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
  </script>

  <style>
    /* Exact A4 Standard in print and display */
    :root {
      --a4-w: 210mm;
      --a4-h: 297mm;
    }

    @page {
      size: A4 portrait;
      margin: 0;
    }

    @media print {
      body {
        background: transparent !important;
        margin: 0 !important;
        padding: 0 !important;
        -webkit-print-color-adjust: exact;
        print-color-adjust: exact;
      }
      .no-print {
        display: none !important;
      }
      #printWrapper {
        display: block !important;
        margin: 0 !important;
        padding: 0 !important;
        width: 100vw !important;
        height: 100vh !important;
      }
      .a4-sheet {
        box-shadow: none !important;
        border: none !important;
        margin: 0 !important;
        width: var(--a4-w) !important;
        height: var(--a4-h) !important;
        max-height: var(--a4-h) !important;
        page-break-after: avoid;
        page-break-inside: avoid;
      }
    }

    .a4-sheet {
      width: 794px; /* Standard 96 DPI pixel equivalent of 210mm */
      height: 1123px; /* 297mm @ 96 DPI */
      position: relative;
      background-color: #ffffff;
      overflow: hidden;
    }

    /* Draggable or positioned overlay labels - left aligned to sit right after colons */
    .field-overlay {
      position: absolute;
      transform: translateY(-50%);
      white-space: nowrap;
      user-select: none;
      cursor: move;
      border: 1px dashed rgba(59, 130, 246, 0.45);
      background: rgba(255, 255, 255, 0.65);
      backdrop-filter: blur(1px);
      padding: 1px 4px;
      line-height: 1.15;
      font-family: 'Courier New', Courier, monospace;
      font-weight: 700;
      color: #000000;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      transition: border-color 0.15s, background-color 0.15s;
    }

    .field-overlay.center-align {
      transform: translate(-50%, -50%);
      text-align: center;
    }

    .field-overlay:hover, .field-overlay.active-field {
      border: 1.5px solid #2563eb !important;
      background: rgba(219, 234, 254, 0.9) !important;
      z-index: 50;
    }

    @media print {
      .field-overlay {
        border: none !important;
        background: transparent !important;
        backdrop-filter: none !important;
        cursor: default;
      }
    }
  </style>
</head>
<body class="bg-slate-900 text-slate-100 min-h-screen flex flex-col font-sans">

  <!-- Top Navigation Header -->
  <header class="no-print bg-slate-800 border-b border-slate-700 px-6 py-3 flex flex-wrap items-center justify-between gap-4">
    <div class="flex items-center gap-3">
      <div class="bg-blue-600 text-white p-2 rounded-lg font-bold shadow">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.5L19 7.5V19a2 2 0 01-2 2z"></path>
        </svg>
      </div>
      <div>
        <h1 class="font-bold text-base md:text-lg text-white">Maharashtra Gazzette Request Form</h1>
        <p class="text-xs text-slate-400">Data Entry on Top &bull; A4 Document Preview on Bottom</p>
      </div>
    </div>

    <!-- Actions -->
    <div class="flex items-center gap-2">
      <button onclick="resetDefaultPositions()" class="text-xs bg-slate-700 hover:bg-slate-600 text-slate-200 px-3 py-1.5 rounded-md transition font-medium">
        Reset Positions
      </button>
      <button onclick="sampleDemoData()" class="text-xs bg-slate-700 hover:bg-slate-600 text-slate-200 px-3 py-1.5 rounded-md transition font-medium">
        Sample Data
      </button>
      <button onclick="clearData()" class="text-xs bg-rose-900/50 hover:bg-rose-800 text-rose-200 border border-rose-700 px-3 py-1.5 rounded-md transition font-medium">
        Clear
      </button>
      <button onclick="window.print()" class="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs md:text-sm px-4 py-1.5 rounded-md shadow-lg transition">
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"></path>
        </svg>
        Print / Save PDF
      </button>
    </div>
  </header>

  <!-- UPPER SECTION: Data Entry Panel (Top Side) -->
  <section class="no-print bg-slate-850 bg-slate-900/90 border-b border-slate-700/80 shadow-lg px-4 md:px-6 py-4">
    <div class="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">

      <!-- Column 1: Background Upload & Sizing -->
      <div class="bg-slate-800/80 border border-slate-700 rounded-lg p-3 space-y-2.5">
        <label class="block text-[11px] font-bold uppercase tracking-wider text-blue-400">
          1. Document Background
        </label>
        <input 
          id="fileInput" 
          type="file" 
          accept="image/*,application/pdf" 
          class="block w-full text-xs text-slate-400 file:mr-2 file:py-1 file:px-2.5 file:rounded file:border-0 file:text-[11px] file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-500 cursor-pointer"
          onchange="handleFileUpload(event)"
        />
        <div class="flex items-center justify-between text-[11px] text-slate-300">
          <span>Opacity: <strong id="opacityVal">100%</strong></span>
          <input type="range" min="20" max="100" value="100" class="w-24 accent-blue-500" oninput="changeBgOpacity(this.value)">
        </div>
        <div class="flex items-center justify-between text-[11px] text-slate-300">
          <span>Font: <strong id="fontSizeVal">13px</strong></span>
          <input type="range" id="globalFontSize" min="9" max="22" value="13" class="w-24 accent-blue-500" oninput="updateFontSize(this.value)">
        </div>
      </div>

      <!-- Column 2: Old & New Name Inputs -->
      <div class="bg-slate-800/80 border border-slate-700 rounded-lg p-3 space-y-2">
        <label class="block text-[11px] font-bold uppercase tracking-wider text-blue-400">
          2. Old Name (First / Middle / Surname)
        </label>
        <div class="grid grid-cols-3 gap-1.5">
          <input id="inOldFirst" type="text" placeholder="FIRST" class="w-full bg-slate-900 border border-slate-700 text-white rounded px-2 py-1 text-xs uppercase focus:ring-1 focus:ring-blue-500 focus:outline-none" oninput="syncData()">
          <input id="inOldMiddle" type="text" placeholder="MIDDLE" class="w-full bg-slate-900 border border-slate-700 text-white rounded px-2 py-1 text-xs uppercase focus:ring-1 focus:ring-blue-500 focus:outline-none" oninput="syncData()">
          <input id="inOldLast" type="text" placeholder="SURNAME" class="w-full bg-slate-900 border border-slate-700 text-white rounded px-2 py-1 text-xs uppercase focus:ring-1 focus:ring-blue-500 focus:outline-none" oninput="syncData()">
        </div>

        <label class="block text-[11px] font-bold uppercase tracking-wider text-blue-400 pt-1">
          3. New Name (First / Middle / Surname)
        </label>
        <div class="grid grid-cols-3 gap-1.5">
          <input id="inNewFirst" type="text" placeholder="FIRST" class="w-full bg-slate-900 border border-slate-700 text-white rounded px-2 py-1 text-xs uppercase focus:ring-1 focus:ring-blue-500 focus:outline-none" oninput="syncData()">
          <input id="inNewMiddle" type="text" placeholder="MIDDLE" class="w-full bg-slate-900 border border-slate-700 text-white rounded px-2 py-1 text-xs uppercase focus:ring-1 focus:ring-blue-500 focus:outline-none" oninput="syncData()">
          <input id="inNewLast" type="text" placeholder="SURNAME" class="w-full bg-slate-900 border border-slate-700 text-white rounded px-2 py-1 text-xs uppercase focus:ring-1 focus:ring-blue-500 focus:outline-none" oninput="syncData()">
        </div>
      </div>

      <!-- Column 3: Reason & Full Address Name -->
      <div class="bg-slate-800/80 border border-slate-700 rounded-lg p-3 space-y-2">
        <label class="block text-[11px] font-bold uppercase tracking-wider text-blue-400">
          4. Reason & Correspondence Name
        </label>
        <div>
          <span class="text-[10px] text-slate-400 block mb-0.5">Reason for change of Name</span>
          <select id="reasonSelect" class="w-full bg-slate-900 border border-slate-700 text-white rounded px-2 py-1 text-xs focus:ring-1 focus:ring-blue-500 focus:outline-none uppercase" onchange="handleReasonChange()">
            <option value="SPELLING MISTAKE">SPELLING MISTAKE</option>
            <option value="AFTER MARRIAGE">AFTER MARRIAGE</option>
            <option value="OWN REQUEST">OWN REQUEST</option>
            <option value="OTHERS">OTHERS</option>
          </select>
          <!-- Custom text input enabled when OTHERS is chosen -->
          <input id="inReasonCustom" type="text" placeholder="ENTER CUSTOM REASON" class="hidden w-full bg-slate-900 border border-blue-500 text-white rounded px-2 py-1 text-xs uppercase mt-1 focus:ring-1 focus:ring-blue-500 focus:outline-none" oninput="syncData()">
        </div>
        <div>
          <div class="flex items-center justify-between mb-0.5">
            <span class="text-[10px] text-slate-400">New Name Row</span>
            <div class="flex gap-1 text-[10px]">
              <button onclick="nudgeField('corrName', 0, -0.3)" class="bg-slate-700 hover:bg-slate-600 px-1 rounded text-white font-mono">▲</button>
              <button onclick="nudgeField('corrName', 0, 0.3)" class="bg-slate-700 hover:bg-slate-600 px-1 rounded text-white font-mono">▼</button>
            </div>
          </div>
          <input id="inCorrName" type="text" placeholder="Auto-generated or custom" class="w-full bg-slate-900 border border-slate-700 text-white rounded px-2 py-1 text-xs uppercase focus:ring-1 focus:ring-blue-500 focus:outline-none" oninput="syncData(true)">
        </div>
      </div>

      <!-- Column 4: Address, Pincode & Mobile -->
      <div class="bg-slate-800/80 border border-slate-700 rounded-lg p-3 space-y-2">
        <div class="flex items-center justify-between">
          <label class="text-[11px] font-bold uppercase tracking-wider text-blue-400">
            5. Address, Pin & Mobile
          </label>
          <div class="flex gap-1 text-[10px]">
            <span class="text-[10px] text-slate-400">Addr:</span>
            <button onclick="nudgeField('address', 0, -0.3)" class="bg-slate-700 hover:bg-slate-600 px-1 rounded text-white font-mono">▲</button>
            <button onclick="nudgeField('address', 0, 0.3)" class="bg-slate-700 hover:bg-slate-600 px-1 rounded text-white font-mono">▼</button>
          </div>
        </div>
        <input id="inAddress" type="text" value="KHANKHA GALLI, UDGIR, LATUR, MAHARASHTRA" placeholder="RESIDENTIAL ADDRESS" class="w-full bg-slate-900 border border-slate-700 text-white rounded px-2 py-1 text-xs uppercase focus:ring-1 focus:ring-blue-500 focus:outline-none" oninput="syncData()">
        
        <div class="grid grid-cols-2 gap-2">
          <div>
            <div class="flex items-center justify-between mb-0.5">
              <span class="text-[10px] text-slate-400">Pincode</span>
              <div class="flex gap-0.5 text-[9px]">
                <button onclick="nudgeField('pincode', 0, -0.3)" class="bg-slate-700 hover:bg-slate-600 px-1 rounded text-white font-mono">▲</button>
                <button onclick="nudgeField('pincode', 0, 0.3)" class="bg-slate-700 hover:bg-slate-600 px-1 rounded text-white font-mono">▼</button>
              </div>
            </div>
            <input id="inPincode" type="text" maxlength="10" value="413517" placeholder="PIN" class="w-full bg-slate-900 border border-slate-700 text-white rounded px-2 py-1 text-xs uppercase focus:ring-1 focus:ring-blue-500 focus:outline-none" oninput="syncData()">
          </div>

          <div>
            <div class="flex items-center justify-between mb-0.5">
              <span class="text-[10px] text-slate-400">Mobile</span>
              <div class="flex gap-0.5 text-[9px]">
                <button onclick="nudgeField('mobile', 0, -0.3)" class="bg-slate-700 hover:bg-slate-600 px-1 rounded text-white font-mono">▲</button>
                <button onclick="nudgeField('mobile', 0, 0.3)" class="bg-slate-700 hover:bg-slate-600 px-1 rounded text-white font-mono">▼</button>
              </div>
            </div>
            <input id="inMobile" type="text" maxlength="15" value="7676331399" placeholder="MOBILE" class="w-full bg-slate-900 border border-slate-700 text-white rounded px-2 py-1 text-xs uppercase focus:ring-1 focus:ring-blue-500 focus:outline-none" oninput="syncData()">
          </div>
        </div>
      </div>

    </div>
  </section>

  <!-- LOWER SECTION: A4 Form / PDF Preview (Down Side) -->
  <main class="flex-1 bg-slate-950 p-4 md:p-8 overflow-auto flex justify-center items-start">
    <div id="printWrapper" class="relative shadow-2xl rounded-sm">
      
      <!-- The A4 Sheet (794 x 1123 px standard) -->
      <div id="a4Canvas" class="a4-sheet" style="font-size: 13px;">
        
        <!-- Background Layer: PDF or Scanned Image -->
        <canvas id="pdfRenderCanvas" class="absolute inset-0 w-full h-full object-contain pointer-events-none z-0"></canvas>
        <img id="bgImg" class="absolute inset-0 w-full h-full object-contain pointer-events-none z-0 hidden" alt="Scanned Gazette Form" />

        <!-- Fallback placeholder when no BG is uploaded yet -->
        <div id="emptyBgHint" class="absolute inset-0 border-2 border-dashed border-slate-300 rounded flex flex-col items-center justify-center text-slate-400 p-8 text-center pointer-events-none z-0">
          <svg class="w-16 h-16 text-slate-300 mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
          </svg>
          <p class="font-bold text-slate-600 text-sm">NO BACKGROUND LOADED YET</p>
          <p class="text-xs text-slate-500 max-w-sm mt-1">
            Upload the original Gazette Form (PDF or JPG/PNG image) using the panel on the upper section. The document will display directly behind your entered text.
          </p>
        </div>

        <!-- OVERLAID INTERACTIVE DATA ELEMENTS -->
        <!-- 1. Old Name Row (Center aligned in table columns) -->
        <div id="ov_oldFirst" class="field-overlay center-align" data-key="oldFirst" title="Old First Name">OLD FIRST</div>
        <div id="ov_oldMiddle" class="field-overlay center-align" data-key="oldMiddle" title="Old Middle Name">OLD MIDDLE</div>
        <div id="ov_oldLast" class="field-overlay center-align" data-key="oldLast" title="Old Surname">OLD SURNAME</div>

        <!-- 2. New Name Row (Center aligned in table columns) -->
        <div id="ov_newFirst" class="field-overlay center-align" data-key="newFirst" title="New First Name">NEW FIRST</div>
        <div id="ov_newMiddle" class="field-overlay center-align" data-key="newMiddle" title="New Middle Name">NEW MIDDLE</div>
        <div id="ov_newLast" class="field-overlay center-align" data-key="newLast" title="New Surname">NEW SURNAME</div>

        <!-- 3. Reason for Change (Left aligned on dotted line) -->
        <div id="ov_reason" class="field-overlay" data-key="reason" title="Reason for Change">CHANGE OF NAME REASON</div>

        <!-- 4. Corresponding Details (Left-aligned immediately after colons matching sample screenshot) -->
        <div id="ov_corrName" class="field-overlay" data-key="corrName" title="New Name:">FULL NEW NAME</div>
        <div id="ov_address" class="field-overlay" data-key="address" title="Address:">RESIDENTIAL ADDRESS</div>
        <div id="ov_pincode" class="field-overlay" data-key="pincode" title="Pincode:">PINCODE</div>
        <div id="ov_mobile" class="field-overlay" data-key="mobile" title="Mobile No:">MOBILE</div>

      </div>
    </div>
  </main>

  <script>
    /**
     * Calibrated coordinates matching the scanned form layout and exact screenshot alignment
     */
    const DEFAULT_POSITIONS = {
      oldFirst:   { x: 35.5, y: 35.8 },
      oldMiddle:  { x: 54.0, y: 35.8 },
      oldLast:    { x: 73.0, y: 35.8 },
      
      newFirst:   { x: 35.5, y: 38.3 },
      newMiddle:  { x: 54.0, y: 38.3 },
      newLast:    { x: 73.0, y: 38.3 },

      reason:     { x: 32.5, y: 59.2 },

      /* Calibrated address rows: FULL NAME and ADDRESS shifted down */
      corrName:   { x: 26.5, y: 78.0 },
      address:    { x: 26.5, y: 79.5 },
      pincode:    { x: 26.5, y: 81.0 },
      mobile:     { x: 26.5, y: 82.5 }
    };

    // Current working coordinates
    let positions = JSON.parse(JSON.stringify(DEFAULT_POSITIONS));
    let manualCorrNameOverride = false;

    // Apply positions to overlay elements
    function applyPositions() {
      for (const [key, pos] of Object.entries(positions)) {
        const el = document.getElementById(`ov_${key}`);
        if (el) {
          el.style.left = `${pos.x}%`;
          el.style.top = `${pos.y}%`;
        }
      }
    }

    // Micro-nudge helper for quick alignment adjustments
    function nudgeField(key, dx, dy) {
      if (!positions[key]) return;
      positions[key].x = Number((positions[key].x + dx).toFixed(2));
      positions[key].y = Number((positions[key].y + dy).toFixed(2));
      const el = document.getElementById(`ov_${key}`);
      if (el) {
        el.style.left = `${positions[key].x}%`;
        el.style.top = `${positions[key].y}%`;
      }
    }

    function resetDefaultPositions() {
      positions = JSON.parse(JSON.stringify(DEFAULT_POSITIONS));
      applyPositions();
    }

    // Handle Dropdown Change for Reason
    function handleReasonChange() {
      const select = document.getElementById('reasonSelect');
      const customInput = document.getElementById('inReasonCustom');
      if (select.value === 'OTHERS') {
        customInput.classList.remove('hidden');
        customInput.focus();
      } else {
        customInput.classList.add('hidden');
      }
      syncData();
    }

    // Clear all inputs
    function clearData() {
      const ids = ['inOldFirst', 'inOldMiddle', 'inOldLast', 'inNewFirst', 'inNewMiddle', 'inNewLast', 'inReasonCustom', 'inCorrName', 'inAddress', 'inPincode', 'inMobile'];
      ids.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = '';
      });
      document.getElementById('reasonSelect').value = 'SPELLING MISTAKE';
      document.getElementById('inReasonCustom').classList.add('hidden');
      manualCorrNameOverride = false;
      syncData();
    }

    // Synchronize Input Fields with Overlaid Text
    function syncData(isManualCorr = false) {
      if (isManualCorr) {
        manualCorrNameOverride = true;
      }

      const getVal = (id) => {
        const el = document.getElementById(id);
        return el ? el.value.trim() : '';
      };

      const oF = getVal('inOldFirst') || 'OLD FIRST';
      const oM = getVal('inOldMiddle') || 'OLD MIDDLE';
      const oL = getVal('inOldLast') || 'OLD SURNAME';

      const nF = getVal('inNewFirst') || 'NEW FIRST';
      const nM = getVal('inNewMiddle') || 'NEW MIDDLE';
      const nL = getVal('inNewLast') || 'NEW SURNAME';

      // Read selected reason from dropdown or custom input
      const selectVal = document.getElementById('reasonSelect').value;
      let reasonText = selectVal;
      if (selectVal === 'OTHERS') {
        reasonText = getVal('inReasonCustom') || 'OTHERS';
      }
      
      // Auto-populate corresponding name unless manually overridden
      const autoFullName = [getVal('inNewFirst'), getVal('inNewMiddle'), getVal('inNewLast')].filter(Boolean).join(' ');
      if (!manualCorrNameOverride && autoFullName.length > 0) {
        document.getElementById('inCorrName').value = autoFullName;
      }
      const corrName = getVal('inCorrName') || autoFullName || 'FULL NEW NAME';
      
      const addr = getVal('inAddress') || 'RESIDENTIAL ADDRESS';
      const pin = getVal('inPincode') || 'PINCODE';
      const mob = getVal('inMobile') || 'MOBILE';

      // Update overlaid text
      document.getElementById('ov_oldFirst').innerText = oF;
      document.getElementById('ov_oldMiddle').innerText = oM;
      document.getElementById('ov_oldLast').innerText = oL;

      document.getElementById('ov_newFirst').innerText = nF;
      document.getElementById('ov_newMiddle').innerText = nM;
      document.getElementById('ov_newLast').innerText = nL;

      document.getElementById('ov_reason').innerText = reasonText;
      document.getElementById('ov_corrName').innerText = corrName;
      document.getElementById('ov_address').innerText = addr;
      document.getElementById('ov_pincode').innerText = pin;
      document.getElementById('ov_mobile').innerText = mob;
    }

    function sampleDemoData() {
      document.getElementById('inOldFirst').value = 'RAMESH';
      document.getElementById('inOldMiddle').value = 'PRAKASH';
      document.getElementById('inOldLast').value = 'SHARMA';

      document.getElementById('inNewFirst').value = 'AARAV';
      document.getElementById('inNewMiddle').value = 'PRAKASH';
      document.getElementById('inNewLast').value = 'SHARMA';

      document.getElementById('reasonSelect').value = 'AFTER MARRIAGE';
      document.getElementById('inReasonCustom').classList.add('hidden');
      document.getElementById('inAddress').value = 'KHANKHA GALLI, UDGIR, LATUR, MAHARASHTRA';
      document.getElementById('inPincode').value = '413517';
      document.getElementById('inMobile').value = '7676331399';
      manualCorrNameOverride = false;
      syncData();
    }

    function changeBgOpacity(val) {
      document.getElementById('opacityVal').innerText = `${val}%`;
      const op = val / 100;
      document.getElementById('pdfRenderCanvas').style.opacity = op;
      document.getElementById('bgImg').style.opacity = op;
    }

    function updateFontSize(val) {
      document.getElementById('fontSizeVal').innerText = `${val}px`;
      document.getElementById('a4Canvas').style.fontSize = `${val}px`;
    }

    /**
     * File Upload Handler (PDF or Image)
     */
    function handleFileUpload(e) {
      const file = e.target.files[0];
      if (!file) return;

      const emptyHint = document.getElementById('emptyBgHint');
      const canvas = document.getElementById('pdfRenderCanvas');
      const img = document.getElementById('bgImg');

      emptyHint.classList.add('hidden');

      if (file.type === 'application/pdf') {
        img.classList.add('hidden');
        canvas.classList.remove('hidden');

        const fileReader = new FileReader();
        fileReader.onload = function() {
          const typedarray = new Uint8Array(this.result);
          pdfjsLib.getDocument(typedarray).promise.then(pdf => {
            // Render 1st page
            pdf.getPage(1).then(page => {
              const viewport = page.getViewport({ scale: 2.0 });
              canvas.width = viewport.width;
              canvas.height = viewport.height;

              const renderContext = {
                canvasContext: canvas.getContext('2d'),
                viewport: viewport
              };
              page.render(renderContext);
            });
          }).catch(err => {
            console.error('PDF Render Error:', err);
          });
        };
        fileReader.readAsArrayBuffer(file);

      } else if (file.type.startsWith('image/')) {
        canvas.classList.add('hidden');
        img.classList.remove('hidden');

        const reader = new FileReader();
        reader.onload = function(evt) {
          img.src = evt.target.result;
        };
        reader.readAsDataURL(file);
      }
    }

    /**
     * Drag & Drop System for fine-tuning text alignment directly on the preview
     */
    let activeDragEl = null;
    let dragStartX = 0;
    let dragStartY = 0;
    let elementStartLeft = 0;
    let elementStartTop = 0;

    function initDraggables() {
      const overlays = document.querySelectorAll('.field-overlay');
      const container = document.getElementById('a4Canvas');

      overlays.forEach(el => {
        el.addEventListener('mousedown', (e) => {
          activeDragEl = el;
          el.classList.add('active-field');
          
          dragStartX = e.clientX;
          dragStartY = e.clientY;

          const key = el.dataset.key;
          elementStartLeft = positions[key].x;
          elementStartTop = positions[key].y;

          e.preventDefault();
        });
      });

      window.addEventListener('mousemove', (e) => {
        if (!activeDragEl) return;
        const container = document.getElementById('a4Canvas');
        const rect = container.getBoundingClientRect();

        const dxPx = e.clientX - dragStartX;
        const dyPx = e.clientY - dragStartY;

        const dxPercent = (dxPx / rect.width) * 100;
        const dyPercent = (dyPx / rect.height) * 100;

        let newX = Math.min(Math.max(elementStartLeft + dxPercent, 2), 98);
        let newY = Math.min(Math.max(elementStartTop + dyPercent, 2), 98);

        const key = activeDragEl.dataset.key;
        positions[key].x = Number(newX.toFixed(2));
        positions[key].y = Number(newY.toFixed(2));

        activeDragEl.style.left = `${positions[key].x}%`;
        activeDragEl.style.top = `${positions[key].y}%`;
      });

      window.addEventListener('mouseup', () => {
        if (activeDragEl) {
          activeDragEl.classList.remove('active-field');
          activeDragEl = null;
        }
      });
    }

    // Initialize upon window load
    window.onload = function() {
      applyPositions();
      initDraggables();
      syncData();
    };
  </script>
</body>
</html>