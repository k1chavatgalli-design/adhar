<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Annexure-I: Affidavit for Date of Birth Updation</title>
  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- FontAwesome Icons for UI -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Google Fonts: Inter & Noto Serif for Legal Print -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Inter:wght@300;400;500;600;700&family=Merriweather:ital,wght@0,300;0,400;0,700;1,400&display=swap" rel="stylesheet">

  <script>
    tailwind.config = {
      theme: {
        extend: {
          fontFamily: {
            sans: ['Inter', 'sans-serif'],
            serif: ['Merriweather', 'serif'],
            heading: ['Cinzel', 'serif']
          },
          colors: {
            primary: {
              50: '#f0f7ff',
              100: '#e0effe',
              600: '#1d4ed8',
              700: '#1e40af',
              800: '#1e3a8a'
            }
          }
        }
      }
    }
  </script>

  <style>
    /* Styling for A4 print-preview simulation */
    .a4-sheet {
      width: 210mm;
      min-height: 297mm;
      margin: 0 auto;
      background: #ffffff;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1);
      padding: 22mm 20mm 20mm 20mm;
      position: relative;
      box-sizing: border-box;
      color: #111827;
      line-height: 1.65;
    }

    /* Print specific styles */
    @media print {
      @page {
        size: A4 portrait;
        margin: 15mm 18mm 15mm 18mm;
      }
      body {
        background: #ffffff !important;
        color: #000000 !important;
        margin: 0 !important;
        padding: 0 !important;
      }
      .no-print {
        display: none !important;
      }
      .print-container {
        padding: 0 !important;
        margin: 0 !important;
        width: 100% !important;
        box-shadow: none !important;
      }
      .a4-sheet {
        box-shadow: none !important;
        border: none !important;
        width: 100% !important;
        min-height: auto !important;
        padding: 0 !important;
        margin: 0 !important;
        font-size: 11pt !important;
      }
      .print-border {
        border-color: #000000 !important;
      }
    }

    /* Watermark for official stamp feel */
    .legal-border {
      border: 1px solid #d1d5db;
      position: relative;
    }
    .custom-scrollbar::-webkit-scrollbar {
      width: 6px;
    }
    .custom-scrollbar::-webkit-scrollbar-track {
      background: #f1f5f9;
    }
    .custom-scrollbar::-webkit-scrollbar-thumb {
      background: #cbd5e1;
      border-radius: 4px;
    }
  </style>
</head>
<body class="bg-slate-100 min-h-screen text-slate-800 font-sans antialiased">

  <!-- Header Banner (Screen Only) -->
  <header class="no-print bg-slate-900 text-white border-b border-slate-800 shadow-md sticky top-0 z-30">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex flex-wrap justify-between items-center gap-3">
      <div class="flex items-center space-x-3">
        <div class="w-9 h-9 rounded-lg bg-blue-600 flex items-center justify-center text-white shadow-sm font-bold text-lg">
          <i class="fa-solid fa-file-contract"></i>
        </div>
        <div>
          <h1 class="text-base sm:text-lg font-bold leading-tight">UIDAI Annexure-I Generator</h1>
          <p class="text-xs text-slate-400">Adult Date of Birth Updation Affidavit Form</p>
        </div>
      </div>

      <!-- Quick Action Buttons -->
      <div class="flex items-center space-x-2">
        <button type="button" onclick="loadSampleData()" class="px-3 py-1.5 text-xs sm:text-sm font-medium rounded-md bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition flex items-center gap-1.5 cursor-pointer">
          <i class="fa-solid fa-wand-magic-sparkles text-amber-400"></i> Sample Data
        </button>
        <button type="button" onclick="resetForm()" class="px-3 py-1.5 text-xs sm:text-sm font-medium rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition flex items-center gap-1.5 cursor-pointer">
          <i class="fa-solid fa-rotate-left"></i> Clear
        </button>
        <button type="button" onclick="window.print()" class="px-4 py-1.5 text-xs sm:text-sm font-semibold rounded-md bg-blue-600 hover:bg-blue-500 text-white shadow-sm transition flex items-center gap-2 cursor-pointer">
          <i class="fa-solid fa-print"></i> Print Affidavit
        </button>
      </div>
    </div>
  </header>

  <!-- Main Container: Stacked Single Column -->
  <main class="max-w-5xl mx-auto p-4 sm:p-6 lg:p-8 space-y-10">

    <!-- Top Section: Interactive Form (Screen Only) -->
    <section class="no-print bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
      <div class="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
        <div class="flex items-center space-x-2">
          <span class="w-2.5 h-2.5 rounded-full bg-blue-600"></span>
          <h2 class="font-semibold text-slate-800 text-sm tracking-wide uppercase">Affidavit Data Entry</h2>
        </div>
        <span class="text-xs font-medium text-slate-500">Live Sync Enabled</span>
      </div>

      <form id="affidavitForm" class="p-5 sm:p-6 space-y-6 text-sm" onsubmit="event.preventDefault()">
        
        <!-- Personal Info Group -->
        <div class="space-y-4">
          <h3 class="text-xs font-bold text-slate-400 uppercase tracking-wider">1. Resident Identification</h3>
          
          <div>
            <label class="block text-xs font-semibold text-slate-700 mb-1">Full Name (as per ID/Applicant) *</label>
            <input type="text" id="inputFullName" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-slate-800 uppercase" placeholder="e.g. PALLAVI BASAVARAJ NAIKAR" oninput="updatePreview()">
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Relation Type</label>
              <select id="inputRelationType" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500" onchange="updatePreview()">
                <option value="D/o">D/o (Daughter of)</option>
                <option value="S/o">S/o (Son of)</option>
                <option value="W/o">W/o (Wife of)</option>
                <option value="C/o">C/o (Care of)</option>
              </select>
            </div>
            <div class="sm:col-span-2">
              <label class="block text-xs font-semibold text-slate-700 mb-1">Parent / Guardian Name *</label>
              <input type="text" id="inputParentName" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 text-slate-800 uppercase" placeholder="e.g. BASAVARAJ NAIKAR" oninput="updatePreview()">
            </div>
          </div>

          <div>
            <label class="block text-xs font-semibold text-slate-700 mb-1">Aadhaar Number (12 Digits) *</label>
            <input type="text" id="inputAadhaar" maxlength="14" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 font-mono" placeholder="XXXX - XXXX - XXXX" oninput="formatAadhaar(this); updatePreview()">
          </div>
        </div>

        <!-- Residential Address Group -->
        <div class="space-y-4 pt-4 border-t border-slate-200">
          <h3 class="text-xs font-bold text-slate-400 uppercase tracking-wider">2. Complete Residential Address</h3>

          <div>
            <label class="block text-xs font-semibold text-slate-700 mb-1">House / Street / Village *</label>
            <input type="text" id="inputVillage" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 uppercase" placeholder="e.g. MUDENAKOPPA" oninput="updatePreview()">
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Taluk / Tehsil *</label>
              <input type="text" id="inputTaluk" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 uppercase" placeholder="e.g. RAMADURG TALUK" oninput="updatePreview()">
            </div>
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">District *</label>
              <input type="text" id="inputDistrict" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 uppercase" placeholder="e.g. BELAGAVI" oninput="updatePreview()">
            </div>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">State *</label>
              <input type="text" id="inputState" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 uppercase" placeholder="e.g. KARNATAKA" oninput="updatePreview()">
            </div>
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">PIN Code *</label>
              <input type="text" id="inputPincode" maxlength="6" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 font-mono" placeholder="591126" oninput="updatePreview()">
            </div>
          </div>
        </div>

        <!-- DOB & Verification Details Group -->
        <div class="space-y-4 pt-4 border-t border-slate-200">
          <h3 class="text-xs font-bold text-slate-400 uppercase tracking-wider">3. Date of Birth Details</h3>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Correct Date of Birth (DD/MM/YYYY) *</label>
              <input type="text" id="inputCorrectDob" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 font-mono" placeholder="28/08/2008" oninput="updatePreview()">
            </div>
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Earlier Recorded DOB in Aadhaar *</label>
              <input type="text" id="inputEarlierDob" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 font-mono" placeholder="28/09/2008" oninput="updatePreview()">
            </div>
          </div>

          <div>
            <label class="block text-xs font-semibold text-slate-700 mb-1">Earlier Document Submitted (as proof in Aadhaar)</label>
            <input type="text" id="inputEarlierDoc" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 uppercase" placeholder="e.g. SCHOOL CERTIFICATE or leave blank for line" oninput="updatePreview()">
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Updation History *</label>
              <select id="inputUpdateHistory" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 font-medium" onchange="updatePreview()">
                <option value="NEVER">NEVER</option>
                <option value="ONCE">ONCE</option>
                <option value="MORE THAN ONCE">MORE THAN ONCE</option>
              </select>
            </div>
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Current Proof Document *</label>
              <input type="text" id="inputSubmittedDoc" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 uppercase" placeholder="ORIGINAL BIRTH CERTIFICATE" oninput="updatePreview()">
            </div>
          </div>

          <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Clause (v) Document Choice</label>
              <select id="inputClauseOption" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 text-xs" onchange="updatePreview()">
                <option value="birth_certificate">birth certificate</option>
                <option value="corrected_version">corrected version of earlier document</option>
              </select>
            </div>
            <div>
              <label class="block text-xs font-semibold text-slate-700 mb-1">Affidavit Execution Date *</label>
              <input type="text" id="inputAffidavitDate" class="w-full px-3 py-2 border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 font-mono" placeholder="DD/MM/YYYY" oninput="updatePreview()">
            </div>
          </div>
        </div>
      </form>
    </section>

    <!-- Bottom Section: Live A4 Document Sheet -->
    <section class="flex flex-col items-center print-container">
      <!-- Visual Print Notification Banner -->
      <div class="no-print w-full flex items-center justify-between bg-white px-4 py-2.5 rounded-lg border border-slate-200 mb-4 text-xs text-slate-600 shadow-sm">
        <span class="flex items-center gap-2">
          <i class="fa-regular fa-eye text-blue-600"></i> Standard A4 Legal Format Preview (Below Form)
        </span>
        <span class="text-slate-400">Standard Margin: 20mm</span>
      </div>

      <!-- The A4 Sheet Paper Document -->
      <div class="a4-sheet font-serif text-slate-900 border border-slate-300">
        
        <!-- Top Right Annexure Label -->
        <div class="text-right mb-4">
          <span class="text-xs sm:text-sm font-bold tracking-wide uppercase font-sans text-slate-800">
            Annexure-I - For Adults
          </span>
        </div>

        <!-- Header Title -->
        <div class="text-center mb-6">
          <h1 class="text-base sm:text-lg font-bold tracking-wide uppercase font-sans">
            Affidavit for date of birth updation
          </h1>
        </div>

        <!-- Deponent Introduction & Declaration -->
        <div class="text-justify text-[13.5px] leading-relaxed mb-4">
          <p>
            1. &nbsp; I, <span id="prevFullName" class="font-bold uppercase">PALLAVI BASAVARAJ NAIKAR</span> 
            <span id="prevRelation" class="font-medium">D/o</span> <span id="prevParentName" class="font-bold uppercase">BASAVARAJ NAIKAR</span> 
            resident of <span id="prevAddress" class="font-bold uppercase">MUDENAKOPPA, RAMADURG TALUK, MUDENKOPPA, BELAGAVI, KARNATAKA - 591126</span> 
            holding Aadhaar number <span id="prevAadhaar" class="font-bold tracking-wider">XXXX–XXXX–XXXX</span> 
            do hereby solemnly affirm and declare as under:-
          </p>
        </div>

        <!-- Clauses Ordered List -->
        <div class="space-y-2.5 text-[13px] leading-relaxed pl-2 text-justify">
          <div class="flex items-start">
            <span class="w-8 shrink-0 font-medium">i)</span>
            <div>That I am the resident of the above said address.</div>
          </div>

          <div class="flex items-start">
            <span class="w-8 shrink-0 font-medium">ii)</span>
            <div>That my correct date of birth is <span id="prevCorrectDob" class="font-bold">28/08/2008</span>.</div>
          </div>

          <div class="flex items-start">
            <span class="w-8 shrink-0 font-medium">iii)</span>
            <div>
              That the earlier recorded date of birth in Aadhaar is <span id="prevEarlierDob" class="font-bold">28/09/2008</span> 
              based on <span id="prevEarlierDoc" class="font-semibold">____________________________</span> document submitted by me.
            </div>
          </div>

          <div class="flex items-start">
            <span class="w-8 shrink-0 font-medium">iv)</span>
            <div>
              That I have <span id="prevHistory" class="font-bold uppercase tracking-wider px-1 bg-slate-100 print:bg-transparent">NEVER</span> 
              <span class="text-slate-600 print:text-black text-xs font-normal">(never/ once/ more than once)</span> updated my date of birth in Aadhaar.
            </div>
          </div>

          <div class="flex items-start">
            <span class="w-8 shrink-0 font-medium">v)</span>
            <div>
              That currently a <span id="prevClauseOption" class="font-semibold">birth certificate</span> 
              (choose as applicable: <em>corrected version of the same document as mentioned in (iii) above / birth certificate</em>) is being provided in support of DoB update request.
            </div>
          </div>

          <div class="flex items-start">
            <span class="w-8 shrink-0 font-medium">vi)</span>
            <div>
              That I wish to get my date of birth updated in the Aadhaar as <span id="prevCorrectDob2" class="font-bold">28/08/2008</span> 
              for which I am submitting <span id="prevSubmittedDoc" class="font-bold uppercase">ORIGINAL BIRTH CERTIFICATE</span> as proof of date of birth.
            </div>
          </div>

          <div class="flex items-start">
            <span class="w-8 shrink-0 font-medium">vii)</span>
            <div>
              That I further undertake that I shall not be eligible for any further updation of my date of birth in Aadhaar.
            </div>
          </div>
        </div>

        <!-- Undertakings -->
        <div class="mt-4 space-y-3 text-[13px] leading-relaxed text-justify">
          <p>
            2. &nbsp; I undertake that if the document submitted as proof of date of birth is found to be fraudulent/false/forged/non-genuine or I was not entitled for the said document, my Aadhaar number may be deactivated as per Regulation 28 of the Aadhaar (Enrolment and Update) Regulations, 2016 and I shall be liable to be prosecuted under provisions of the applicable law.
          </p>
          <p>
            3. &nbsp; I hereby declare that all the information mentioned above is true to the best of my Knowledge. In case of any discrepancies, the undersigned will be held responsible.
          </p>
        </div>

        <!-- Signatures & Date Footer -->
        <div class="mt-14 pt-4 flex justify-between items-end text-sm">
          <div class="space-y-1">
            <p><span class="font-bold">Date :</span> <span id="prevDate" class="font-mono font-medium">11/09/2026</span></p>
            <p><span class="font-bold">Place :</span> <span id="prevPlace" class="uppercase font-medium">BELAGAVI</span></p>
          </div>

          <div class="text-center min-w-[220px]">
            <div class="h-10 mb-2 border-b border-dashed border-slate-400"></div>
            <p class="font-semibold text-xs text-slate-500 uppercase tracking-widest">(Deponent)</p>
            <p class="font-bold text-xs uppercase mt-1 tracking-wider" id="prevSigName">(PALLAVI BASAVARAJ NAIKAR)</p>
          </div>
        </div>

      </div>
    </section>

  </main>

  <!-- Script for Auto-formatting & Syncing -->
  <script>
    // Format Aadhaar Input with dashes
    function formatAadhaar(input) {
      let val = input.value.replace(/\D/g, '');
      if (val.length > 12) val = val.substring(0, 12);
      let parts = [];
      for (let i = 0; i < val.length; i += 4) {
        parts.push(val.substring(i, i + 4));
      }
      input.value = parts.join('–');
    }

    // Set Default / Current Date
    function getTodayFormatted() {
      const today = new Date();
      const dd = String(today.getDate()).padStart(2, '0');
      const mm = String(today.getMonth() + 1).padStart(2, '0');
      const yyyy = today.getFullYear();
      return `${dd}/${mm}/${yyyy}`;
    }

    // Live sync function
    function updatePreview() {
      const fullName = document.getElementById('inputFullName').value.trim() || '____________________';
      const relType = document.getElementById('inputRelationType').value;
      const parentName = document.getElementById('inputParentName').value.trim() || '____________________';
      
      const village = document.getElementById('inputVillage').value.trim();
      const taluk = document.getElementById('inputTaluk').value.trim();
      const district = document.getElementById('inputDistrict').value.trim();
      const state = document.getElementById('inputState').value.trim();
      const pin = document.getElementById('inputPincode').value.trim();

      // Compile address
      const addrParts = [village, taluk, district, state].filter(Boolean);
      let addressString = addrParts.join(', ');
      if (pin) addressString += (addressString ? ' - ' : '') + pin;
      if (!addressString) addressString = '___________________________________________________________';

      const aadhaar = document.getElementById('inputAadhaar').value.trim() || 'XXXX–XXXX–XXXX';
      const correctDob = document.getElementById('inputCorrectDob').value.trim() || 'DD/MM/YYYY';
      const earlierDob = document.getElementById('inputEarlierDob').value.trim() || 'DD/MM/YYYY';
      const earlierDoc = document.getElementById('inputEarlierDoc').value.trim() || '____________________________';
      const historyChoice = document.getElementById('inputUpdateHistory').value;
      const clauseChoice = document.getElementById('inputClauseOption').value;
      const submittedDoc = document.getElementById('inputSubmittedDoc').value.trim() || 'ORIGINAL BIRTH CERTIFICATE';
      const affDate = document.getElementById('inputAffidavitDate').value.trim() || getTodayFormatted();

      // Update Preview Elements
      document.getElementById('prevFullName').textContent = fullName;
      document.getElementById('prevRelation').textContent = relType;
      document.getElementById('prevParentName').textContent = parentName;
      document.getElementById('prevAddress').textContent = addressString;
      document.getElementById('prevAadhaar').textContent = aadhaar;

      document.getElementById('prevCorrectDob').textContent = correctDob;
      document.getElementById('prevCorrectDob2').textContent = correctDob;
      document.getElementById('prevEarlierDob').textContent = earlierDob;
      document.getElementById('prevEarlierDoc').textContent = earlierDoc;
      document.getElementById('prevHistory').textContent = historyChoice;
      document.getElementById('prevSubmittedDoc').textContent = submittedDoc;
      document.getElementById('prevDate').textContent = affDate;
      document.getElementById('prevPlace').textContent = district || '_______________';
      document.getElementById('prevSigName').textContent = `(${fullName})`;

      // Clause v choice representation
      if (clauseChoice === 'birth_certificate') {
        document.getElementById('prevClauseOption').textContent = 'birth certificate';
      } else {
        document.getElementById('prevClauseOption').textContent = 'corrected version of the same document as mentioned in (iii) above';
      }
    }

    // Pre-populate with Sample Data
    function loadSampleData() {
      document.getElementById('inputFullName').value = 'PALLAVI BASAVARAJ NAIKAR';
      document.getElementById('inputRelationType').value = 'D/o';
      document.getElementById('inputParentName').value = 'BASAVARAJ NAIKAR';
      document.getElementById('inputVillage').value = 'MUDENAKOPPA';
      document.getElementById('inputTaluk').value = 'RAMADURG TALUK';
      document.getElementById('inputDistrict').value = 'BELAGAVI';
      document.getElementById('inputState').value = 'KARNATAKA';
      document.getElementById('inputPincode').value = '591126';
      document.getElementById('inputAadhaar').value = 'XXXX–XXXX–XXXX';
      document.getElementById('inputCorrectDob').value = '28/08/2008';
      document.getElementById('inputEarlierDob').value = '28/09/2008';
      document.getElementById('inputEarlierDoc').value = 'SCHOOL TRANSFER CERTIFICATE';
      document.getElementById('inputUpdateHistory').value = 'NEVER';
      document.getElementById('inputClauseOption').value = 'birth_certificate';
      document.getElementById('inputSubmittedDoc').value = 'ORIGINAL BIRTH CERTIFICATE';
      document.getElementById('inputAffidavitDate').value = '11/09/2026';
      updatePreview();
    }

    // Reset Form
    function resetForm() {
      document.getElementById('affidavitForm').reset();
      document.getElementById('inputAffidavitDate').value = getTodayFormatted();
      updatePreview();
    }

    // Initialize on window load
    window.onload = function() {
      loadSampleData();
    };
  </script>
</body>
</html>